<?php
ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

/* CSS fuer Skin 0 Privatraum */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, .rooms, input, select {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #343; /* die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */
}

html {overflow: hidden;padding:3px;}

body {
	font-size:85.01%;
	/* background: #f9f9f5; */
	background: transparent; /* der Op kann das leider nicht */
}



p, ul li {margin-bottom: 2px;}

ul { margin-left:1.3em}
* html ul { margin-left:1.5em}

li {line-height:1em;}


a {color: blue;}
a:link, a:visited {}
a:focus, a:hover {background:#eee;}

object,
img {max-width: 100%;  height:auto;   /* der IE kann das erst ab Version 7 - px fuer Fx 3! */
    }

fieldset {
	/*background: #fafaee;	*/	/* die Hintergrundfarbe fuer das Chatfenster */
	margin:0;
	padding:0;
	border:0;
}

object {margin: 5px;}

video {max-width:100%}
#addsmileys ul {margin: 15px 0 8px 1px;}
#addsmileys ul li {display:inline !important;}


/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* im folgenden wird die Anzeige einzelner Elemente ausgeblendet */
/* #addsmileys ul, */     /* diese Zeile entkommentieren um smileys abzuschalten */
h1, h2,h3,#opt, .rooms p, dtn, .dot, #user_pro_room, #f p span, .ip,
.dt, .uz, .tr, .stop, dfn, .av
        {display:none;}
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

.mp3 {text-decoration:none; color: #bbb;}
.mp3:hover {background:transparent;cursor:default;}
.mp3:after {text-decoration:none; color:red; content:" ... mp3 Player leider nur im Hauptchat :-("} 

img, video {max-height:150px}

#wall {
	height: calc(100vh - 12em);
	width: 99%;  
	background:#fff;		/* die Hintergrundfarbe fuer das Nachrichtenfenster */
	overflow: auto;
	overflow-x:hidden;
	margin: 0;
}


#line {width:85%;padding: 6px 5px;float:left !important;}
#file {border:0}

#wall p {
	padding:  .2em; line-height:1.4em;
      border-bottom:1px dashed #ccc;
}


/* .bg {background:#fafaee;} der Hintergrund fuer den Admin */
.hello {font-size: 1em; color: #888;}

/* Avatar */


input{
	background:#fff;
	font-size: 100%;	
	margin: 2px 0 0 0;
	border:1px solid #aaa;
	cursor:pointer;
}

button[type=submit] {
	border: none;
	background: transparent;
	cursor: pointer;
	font-size: 1.5em;
	opacity: .5;
	/* display: none; */
}


embed {width: 140px; height: 120px }





