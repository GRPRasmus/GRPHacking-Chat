<?php
header('Content-type: text/html; charset=utf-8');

$test = 1000;
if (isset($_REQUEST['test']) && is_numeric($_REQUEST['test'])) {
$temp = $_REQUEST['test'];
$test = time() - $temp;
}

// echo 'time: '.time().' - temp: '.$temp;


if ($test > 120 || $test < -60) {
   echo "Sie haben keine Berechtigung, diese Seite zu besuchen.";
   exit;
}   

include("chat_config.php");

if (isset($stil) && $stil <> 0) {
        $s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
	// $s = $default_skin;
	$s = 10; // auch mobil
}


// Sprache abfragen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
//	$lang = "de";
      $lang = $languages[0];
}

$lang_file = 'lang'.strtoupper($lang).'_inc.php';

//$in_regdb = false;

include ($lang_file);



$profile_file = "";
if (isset($_REQUEST["profil"])) $profile_file = htmlspecialchars($_REQUEST["profil"]);


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
<title>Profil von <?php echo $profile_file; ?></title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />
<link rel="stylesheet" type="text/css" media="screen" href="chatcss<?php echo $s; ?>.php" />

<style>
/*img {margin: .5em 0;}*/

#pb {
    margin: .5em 0;
    width: 200px !important;
    height: 200px;
/*	object-fit: cover;*/
}

img#fem, img#masc {height:32px;width:auto !important;}
body {min-width:auto;}
@media (prefers-color-scheme: dark) {
	html,img{filter:invert(1)}
}

</style>


<?php
if ($s == 11 || $s == 4 || $s == 9) {
echo '
<style type="text/css">

p {color:#fff !important; }
a {color:#aaf !important; }

</style>

';
}

?>



<!-- <script type="text/javascript" src="popbild.js"></script> -->

<script type="text/javascript">
	function kp(e){if (!e) e=window.event;if (e.keyCode==27){self.close();}}window.onkeypress=kp;		
</script>


</head>
<body onkeydown="kp()"; onload="focus()">
<p id="profil">

<?php

$zeile ="";


include("linker.php");


if(file_exists("profile/$profile_file")) {

    $lines = file("profile/$profile_file");

    $profiletime = filemtime("profile/$profile_file");
    $dt7 = date("(d.m.y H:i \U\h\\r) ", $profiletime);

    for($i=1;$i<count($lines);$i++) {
       // leere nicht anzeigen
       if (trim($lines[$i]) != "Hobbys:&nbsp;"
        && trim($lines[$i]) != "kein Bild &nbsp;"
        && trim($lines[$i]) != "&nbsp;"
        && trim($lines[$i]) != ""
        && trim($lines[$i]) != "Geschlecht:&nbsp;"
        && trim($lines[$i]) != "Alter:&nbsp;"
        && trim($lines[$i]) != "Wohnort:&nbsp;"
        && trim($lines[$i]) != "Sternzeichen:&nbsp;"
        && trim($lines[$i]) != "E-Mail:&nbsp;"
        && trim($lines[$i]) != "Bemerkung:&nbsp;"
        // && trim($lines[$i]) != "wei√ü nicht"
       ) {
           $zeile = $zeile."<br />".trim($lines[$i]);
       }
       $zeile = str_replace("E-Mail:&nbsp;","E-Mail: ",$zeile); // das ist noetig wg. auto-E-Mail
       $zeile = str_replace("männlich"," männlich ",$zeile); // das ist noetig wg. smiley_create
       $zeile = str_replace("weiblich"," weiblich ",$zeile); // das ist noetig wg. smiley_create
    }

    if ($zeile == "") {

	    $msg = $profile_file." hat kein Profil angelegt.";

          if(file_exists("profile/$profile_file")) {
//  erst wenn stabil l‰uft             unlink("profile/$profile_file");
          }

    } else {
          $msg = '<b>Profil von '.$profile_file.':</b> '.$dt7.$zeile;
    }

} else {
    $msg = $profile_file." hat kein Profil angelegt.";
}

$msg_explode[1] = linker($msg);

$msg_explode[1] = str_replace("https://  ","",$msg_explode[1]); // Paranoia
$msg_explode[1] = str_replace("img alt","img id='pb' alt",$msg_explode[1]);

if (file_exists("smiley_create.php")) include("smiley_create.php");

echo $msg_explode[1];

?>
</p>
<p style="margin-top: 1em; position:fixed; bottom:2em;">
<a style="font-size: 1em;" href="javascript:self.close()">Fenster&nbsp;schlie&szlig;en</a>
</p>
</body></html>
