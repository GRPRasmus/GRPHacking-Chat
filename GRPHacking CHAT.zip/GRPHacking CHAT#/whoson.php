<?php
session_start();
if (isset($_SESSION['textsize'])) {
	$size = $_SESSION['textsize'];
} else {
	$size = 1; // Standard-Schriftgröße, falls noch kein Session-Cookie gesetzt
}

if( isset( $_SERVER['HTTP_USER_AGENT'])){
	$u_agent = $_SERVER['HTTP_USER_AGENT'];
} else {
	$u_agent = '';
}


?>	
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<meta name="description" content="Ein kostenloser Chat - von webdesign weisshart. Whoson zeigt die anwesenden User, und spielt Sound-Mitteilungen." />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Chat whoson - by webdesign weisshart</title>


<style>
	html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img {
		font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
		border:0;
		margin:0;
		padding:0;
	}
	
	html {background: #fff;padding:1em;-webkit-text-size-adjust: 100%;}
	p, legend, ul {font-size: 100.01%;}
	h1 {	
		border: 0; 
		clip: rect(0 0 0 0); 
		clip-path: polygon(0px 0px, 0px 0px, 0px 0px);
		-webkit-clip-path: polygon(0px 0px, 0px 0px, 0px 0px);
		height: 1px; 
		margin: -1px;
		overflow: hidden;
		padding: 0;
		position: absolute;
		width: 1px;
		white-space: nowrap;
	}
	li {margin-left: 1.5em;line-height:1.4em;}
	li span {opacity:.7;}
	fieldset {
		padding:1em;
		display:inline-block;
		width: calc(100% - 2.5em);
		min-height: 4em;
		border:2px solid #aaa;
	}	
	#hinweis {display:none;text-align:center;cursor:pointer;}
	#hinweis b {border:2px solid;padding:.5em 1em;background:#ddd;display:block;margin-top:.5em;}
	
	#soundoff {border:2px solid;padding:.5em 1em;background:#ddd;display:block;margin-top:1em;text-align:center;font-weight:bold;cursor:pointer;}
	
	body {font-size:<?php echo $size; ?>em;max-width: 35em;margin:auto;}
	#styleswitcher {position:-webkit-sticky;position:sticky;top:0;text-align:right; z-index:5;margin:.3em .3em 1em 0;}
	#styleswitcher a {text-decoration:none;color:#000;background: #ddd; display:inline-block; padding:3px 5px;font-family:sans-serif;font-weight:bold;border:2px solid;}
	#styleswitcher a:focus, #styleswitcher a:hover {text-decoration:underline;filter:invert(1);}
	img {max-width:100%;height:auto;}
	
	
	#help {
	    transition: opacity 2s;
	}
	
	#output {
	    max-height: 15em;
	    overflow: auto;
	}
	
	#output::-webkit-scrollbar {
		-webkit-appearance: none;
		width: 6px;
		height:6px;
	}
	#output::-webkit-scrollbar-thumb {
		border-radius: 4px;
		background-color: rgba(0, 0, 0, .5);
	}
	#output::-webkit-scrollbar-corner {
		background-color:#ddd;
	}
	
	
	
	@media (prefers-color-scheme: dark) {
		html {filter:invert(1);}
	}
	
	/*Link zum Chat*/
	#chatlink {
		width:56px;
		position:relative;
		top:7px;
		left:91%;
		padding: 0;
		opacity:.7;
		background:transparent;
		margin-bottom:-3.5em;
		z-index:3;
	}

	@media screen and (max-width: 700px) {
		#chatlink {
			left:calc(100vw - 85px);
		}
	}

	#chatlink img {
		width:56px;
		border:none;
	}
	#chatlink a{
		text-decoration:none;color:#222;
	}
	#chatlink p {
		position: absolute;
		top: 50px;
		left: 10px;	
		font-family:sans-serif;
		font-size:1em;
	}
	
	
</style>

<?php
if($size > 2.5) {echo '<style>#bigger {display:none !important;}</style>';}
if($size < .9) {echo '<style>#smaller {display:none !important;}</style>';}
?>

</head>
<body>
	
<h1>Dynamische Anzeige der User im Chat</h1>	
<div id="styleswitcher">
<a id="smaller" href="resize.php?size=0.8" >A&minus;</a> <a id="bigger" href="resize.php?size=1.25">A+</a>
</div>
	
<fieldset>
	<legend> Wer ist im Chat? </legend>
	<div id="output"> <noscript><p>Die User-Online Anzeige erfordert Javascript.</p></noscript> </div>
</fieldset>

<p id="hinweis"><br>Zum Aktivieren des Sounds <a onclick="javascript:hide()"><b>➡︎&nbsp;hier klicken&nbsp;/ tippen</b></a></p>

<p id="soundoff">Erinnerungssound ausschalten</p>

<div id="chatlink" >
	<a href="login.php">
		<img src="img/icon-chat.png" alt="" title="Chat öffnen">
		<!-- <p >Chat</p> -->
	</a>
</div>	

<div id="help" style="margin-top:1em;font-size:.8em;opacity:.7">
<?php

// echo $u_agent;

if (strpos($u_agent,'Chrome/') !== false && strpos($u_agent,'Edg/') === false  ) {
	echo '

<p>Wenn du den Sound nicht hörst:</p>

<ul>
<li>Einstellungen </li>
<li>Datenschutz und Sicherheit </li>
<li>Website-Einstellungen </li>
<li>zusätzliche Inhaltseinstellungen </li>
<li>Ton </li>
<li>Websites dürfen Ton wiedergeben</li>
<li>oder: Dürfen Ton abspielen - Hinzufügen &#8220;Deine Website URL&#8221;</li>
</ul>
	';
}

if (strpos($u_agent,'Firefox/') !== false ) {
	echo '
		<p>Wenn du den Sound nicht hörst: <a target="_blank" href ="https://support.mozilla.org/de/kb/automatische-tonwiedergabe-erlauben-bzw-blockieren">Einstellungen</a></p>
	';
}

	
?>
</div>


<audio  id="audio-sprite"><source src="sounds/sprite3.mp3?<?php echo time(); ?>" type="audio/mpeg" /></audio>


<script>
	function hide() {
		document.getElementById('hinweis').style.display="none";
		document.getElementById('soundoff').style.display='block';
		repeat_sound_off = 1; 
	}
	
	function is_touch_device(){
		return !!('ontouchstart' in window);
	}
	
	// if (is_touch_device() == 1) {
		document.getElementById('hinweis').style.display="block";	
	// }
</script>	

<script src ="anwesend.js?<?php echo time(); ?>"></script>

</body>
</html>

