<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
if (!isset($user_hoehe)) $user_hoehe = 14;
?>

/* CSS fuer Skin 13 Messenger (basiert auf 10 Sky) */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, input, select {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	/* color: #303030; die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */
}


body {
      width: 95%; max-width: 65em;min-width:41em;
      margin: 10px auto;
}


html {
	background:#ddd; 	/* hier die Hintergrundfarbe fuer die Seite */
	background: url(img/pfeile2.png) repeat;
}


fieldset, #wall {border:0 !important;}

fieldset .rooms {margin-bottom:3em !important}

h1 {
	font-size:1.3em;
	line-height:125%;
	font-variant:small-caps;
	color:#747474;
}


h2 {
	font-size:.8em;
	line-height:125%;
	margin: 1em 0 .3em 0;
}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
	color:#747474;
}

p, ol li, #uo, #help tr, legend, select {
	font-size:.8em;
}

video {vertical-align:top}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
	/* position:relative; top:.15em; hm? */
}

#user_pro_room a {text-decoration:none}


#user_pro_room em:after { 
	content:" ✔︎";
}

#wrapper {margin-top:2em}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}

#mixed_content a {	color:#747474;font-size:80%}

ul {
	font-size:.8em;
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}

fieldset {
	clear: right;
	/* background: #fff;		 die Hintergrundfarbe fuer das Chatfenster */
	margin:0 0 0 0;
	border:none;
	padding: 2px 2px 0 2px;
}

fieldset fieldset {
       /* background: #fff;	 die Hintergrundfarbe fuer die Optionsfelder */
       /*background-image:url(bg_teaser.gif);
       background-repeat:repeat-x;
       */

	 padding: 2px 4px 4px 3px;
	 margin-bottom: 3px;
}
* html fieldset fieldset {
         float:right;
         width:20%;
}

/* Op und Safari hack (Op 9.1 kanns auch ohne): */
/* html:first-child>b\ody fieldset fieldset {
	 margin-left: 75%;
}
*/

.dt, .uz {
	font-size:.7em;
	color:#888;
/*	background: rgba(255,255,255,0.6); */
	display:contents;
}

/*
.bg .dt, .bg .uz {
	background: rgba(190, 202, 197, 0.6);
}
*/

.dt {
right: 5.5em;
padding-right: .7em;
}


.tr {
	display:none;
}

.av_link a {text-decoration:none;}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {
	width:71% !important;
	margin: 0 1em 2em 0;
}

#wall {
	height: calc(100vh - 22em) !important;
	overflow-y: scroll;
	margin: 0 0 15px 0;
	padding: 1%;
	line-height: 1.1em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
}
* html #wall {
      background-attachment:fixed;
}


.av {
	margin: 3px 5px 0 0;
	border:1px solid #888;
	border-radius:3em;
	/* max-height:3em; */
	width:32px !important;
	clip-path: circle(50% at center);
	object-fit: cover;
	float:left;
	background:#fff;
}

#wall p {
	position: relative;
	background: #fff;
	color: #333 !important;
	border-radius: 0 .7em .7em .7em;
	padding: 2px 7px 4px 7px;
	margin: 6px 0;
	margin-left:.3em;
	max-width: 84%;
	line-height: 1.5em;
	clear:left;
/*	display:flow-root; */
	display:table;
}



#wall p:before {
	content: ' ';
	position: absolute;
	width: 0;
	height: 0;
	right: 100%;
	top: 0;
	border: 5px solid;
	border-color: #fff #fff transparent transparent;
}


/* das sollte natürlich nicht .bb sein, sondern der schreibende User, also in chat? */
#wall p.bg {
	background: #c1ccc7;	
	position: relative;
	left: 2em;
	border-radius: 2em 0 .7em 2em;
	margin-left:0;
	padding:5px 5px 5px 46px;
}
#wall .bg .av {margin-left: -40px;margin-top:0;border-color:#fff} 

#wall p.bg:before {
	border:0;	
}

#wall p.bg:after {
	content: ' ';
	position: absolute;
	width: 0;
	height: 0;
	left: 100%;
	top: 0;
	border: 5px solid;
	border-color: #c1ccc7 transparent transparent #c1ccc7;
}

	
#wall img {
	vertical-align:text-top;
}

#wall .pop::after {
    bottom: -7px;
    right: 5px;
}

/*
.ip {
	display:flex;
    position: absolute;
    left: 13px;
    bottom: 0px;
}
*/

.ip {display:inline-block;}

#wall p.bg span:not(.ytb) {
	color: #666 !important;
}

#wall .nick, #wall .nk {
	font-weight:900;
	float:left; margin-right: 5px;	
}

#wall .whisper, #wall .at {color:red; background: yellow}

#wall::-webkit-scrollbar, #user_pro_room::-webkit-scrollbar, #uo::-webkit-scrollbar {
	-webkit-appearance: none;
	width: 6px;
	height:6px;
}
#wall::-webkit-scrollbar-thumb, #user_pro_room::-webkit-scrollbar-thumb, #uo::-webkit-scrollbar-thumb {
	border-radius: 4px;
	background-color: rgba(0, 0, 0, .5);
}
#wall::-webkit-scrollbar-corner, #user_pro_room::-webkit-scrollbar-corner, #uo::-webkit-scrollbar-corner {
	background-color:#ddd;
}

#line {
	width: 95% !important;
	min-width:95% !important;
	max-width: 95% !important;
	margin-left:0;
    border: 1px solid #aaa;
	border-radius:.2em;
    padding: 3px 7px !important;
	font-size:1em;
}
input#line {position:relative; top: -7px;}
input[type=text] {height:20px}
textarea {height:50px}

button[type=submit] {
	border: none;
	background: transparent;
	cursor: pointer;
	font-size: 1.5em;
	opacity: .5;
	
/*	display:none */
}

#op {margin:3px 0}

#ton {
	width: 0;
	height: 0;
}
/*
#user {
	max-width:14em;
	overflow:auto;
	resize:vertical;
}
*/
#uo{
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "min-height: 14em !important; max-height: 24em !important; /* overflow-y:auto; overflow-x:hidden */";
	} else {
		echo "line-height: 2em;";
	}
	?>
}
/* Opera Hack */
/* html:first-child>b\ody #uo { 
      overflow: auto;
} */

#user_pro_room{
	display:block; 
	min-height: <?php echo $anz_rooms; ?>em; 
	overflow-y:auto; overflow-x:hidden;
	max-height:7.45em
}

/* Opera Hack
html:first-child>b\ody #user_pro_room { 
      overflow: auto;
}
*/

#uo ul {background:#ddd; min-height:unset !important; display:block;}

#uo ul, #uo ul li {
	display: inline;
	<?php
	if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	}
	?>
	font-size:100%;
	margin: 0; 
	padding:0 .1em;
}
#uo ul, #user_pro_room ul {
	padding: .3em 0 .25em .2em;
	margin-top: .3em;
	line-height:1.45em;
	
}

#user_pro_room ul li {
	list-style-type:none;
	display:inline-block;
	border:1px solid #aaa;
	border-radius:1em;
	background: #eee;
	margin: 5px 0 0 0;
	padding:1px 8px 2px 8px;
}
#user_pro_room ul li:hover, #user_pro_room ul li:focus {
	background: #fff;
}
/* #user_pro_room ul {display:none;} */

#uo a, #user_pro_room a {text-decoration:none}

#addsmileys {
	float:left;
	margin: 0 !important;
}
object {margin: 5px;}

dfn, .dot, #sr {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


.bg {background:none;}  /* der Hintergrund fuer den Admin */


label,
select,
input {
cursor: pointer;
}

.button {padding:3px; top:-7px}

* html .button {padding:0;}
*+html .button {padding:0;}

.away {
    border-radius: 1em;
    padding:1px 6px 2px 6px;
    background-color: #747474;
    color: #fff;
}

label {margin:0 3px}


#line, #handle, #room {
	background:#fff;
	cursor:text;
}
#line {
	border: 2px solid transparent;
}

#line:focus, #line:hover {
	outline:none;
	border: 2px solid #aaa;
	border-radius:3px;
}



#menu1, #menu2, #room {width:50%}
* html #menu1, * html #menu2 {width:48%}

select {font-size: 100%}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
   echo '#menu2 {width: 100%}';
   echo '* html #menu3 {width:96%}';
}
?>

<?php
if ($stil != 0) {
   echo '#menu1 {width: 100%}';
   echo '* html #menu1 {width:96%}';
}
?>

#opt2 {clear:left; padding-top: 5px}
.opt {
     display:block;
     margin: 0 0 2px 0;
     padding: 0;
}
* html .opt {margin: 0 0 -4px 0;}
.uolist {display:none;}

#upload {
	clear:left;
	margin: -.5em 5px 3px 6em;
	min-height:6em !important;
}

#wrapper fieldset legend {
	font-size: .8em;
	position: relative;
	top: 1.8em;
	left: -8.5em;
}



/* #upload div img {margin-left:7px} */

@media screen and (-webkit-min-device-pixel-ratio:0) { /* nur Blink, also Chrome - und natürlich Opera */
	audio {
	border: 1px solid #ccc;
	border-radius: 40px;
	}
}

_::-webkit-full-page-media, _:future, :root audio { /*Safari*/
	border: 0;
}

#upload_2 {margin: 0 6px ;}
#addsmileys ul li a:visited span {color:#ddd}

/* #addsmileys {margin-left:3em;} */

#addsmileys               {opacity:.2;filter: grayscale(1);}
#addsmileys:hover         {opacity: 1;filter:grayscale(0)}
#addsmileys:focus-within  {opacity: 1;filter:grayscale(0)}  /* tut nicht in Edge – muss deshalb separate Deklaration sein */


#wdw_logo {filter: invert(.4);max-width:15em !important}

#logout, .logout, #einaus_ae {
	text-align:center;
	margin:7px 0;
	padding:5px 8px;
	border: 1px solid #ccc;
	border-radius:1em;
	background-color: #f1f3f4;
	cursor:pointer;
	display:block;
	max-width:15em
}
#logout:focus, #logout:hover, .logout:focus, .logout:hover, #einaus_ae:hover, #einaus_ae:focus {
	background-color:#fff
}

#logout a, .logout a {text-decoration:none; color:#555 !important}

.helplinks {
margin:0 10px;
position:relative;top:2px;
}
.helplinks p {color:transparent!important}

.helplinks p a:not(.flag) {
border: 1px solid;
border-radius:3px;
padding: 2px 4px;
background:#fff;

}
.helplinks a {color:#747474;text-decoration:none}
.helplinks a span.dot {display:none}

.flag {
margin-top: -2px !important;
}

input, select {
border: 1px dotted #666;
padding: 2px;
background:#fff;
}
input {
margin-right: 2px;
}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50% !important;
}

.hello {color: #747474; font-size: 80%; font-style:italic;}

fieldset #upload #file{border:0 none !important;} /* fuer Chrome */

a.stop {
color:#fff;
background: #747474 !important;
text-decoration:none;
font-size: 80%;
padding: 3px 6px;
border-radius: 1em;
}
#ae {margin-bottom:.5em;}
#einaus_ae {color:#555;min-height:17px}

#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
      border: 0;
      background: transparent;
}

#mp3 {display:block;}
#r_player ul, #player ul {background: #fff;}
#r_player a, #player a {color: #222;}

/* #webradio {color:#666;} */
#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

#topic, #topic_wdw {
color: #747474;
}

/* #nickname {display:inline-block; position:relative;bottom: 5px; margin-left: 6px; color:red;}*/
#nickname {
    display: inline-block;
    color: red;
    margin: .5em 0 1em 0;
}

.uhr {font-size:.7rem;color:#747474;margin-left:1em}


.more_smileys span {display:none}

.more_smileys img {
    border: 1px solid #747474;
    border-radius: 2em;
}

.yta {color:black;font-weight:bold; font-family:Arial narrow; font-size: 1.2em;}
.ytb {font-family:Arial narrow; background:red;color:white !important;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;margin-right:5px;}


#webradio {text-align:center;max-width:100%}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;border-radius:5px;}
input[type="image"]:hover, input[type="image"]:focus { background: #fff}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
#audio-controls {
	margin: .5em 0;
	padding-top: 10px;
	border-radius: 10px;
	background: #f1f3f4;
	border:1px solid #ccc;
	max-width:12.5em;
}



