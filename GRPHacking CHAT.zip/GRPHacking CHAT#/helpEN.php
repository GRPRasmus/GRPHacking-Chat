<?php
ob_start("ob_gzhandler");
header('Content-type: text/html; charset=utf-8');

include("chat_config.php");

if (isset($stil) && $stil <> 0) {
        $s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
        $s = $default_skin;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
<meta http-equiv="content-type" content="application/xhtml+xml;charset=utf-8" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<title>Der Chat von webdesign.weisshart.de</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" />
<link rel="stylesheet" type="text/css" title="handheld" media="handheld" href="chatcss7.php" />

<style type="text/css">
       ul {list-style-type: square; font-size: .8em;}
       ul ul {font-size:100%}
       li {margin: .3em 1.3em}
       ol li  {margin: 1.5em;}
	 h2 {margin-top: 3em;}
	 tr {color:#343;}

        td {
                border:1px solid #555;
                padding: 3px 5px;
                background:white;
        }
        #help, #sr {width:600px;margin:auto}
        #sr {
	          position:absolute;
	          left:-1000px;
	          top:-1000px;
	          width:0;
	          height:0;
	          overflow:hidden;
	          display:inline;
        }


</style>
<!--[if IE]>
<style type="text/css">
	#help {width:expression(document.body.clientWidth > 650? "600px": "95%" );}
</style>
<![endif]-->

<!--
Das folgende Script verhindert, dass der Chat von deinem Server in ein fremdes Frameset eingebunden wird.
Wenn du dies willst, musst du dieses Script entkommentieren (das // loeschen).
//-->

<script type="text/javascript">
// if (top != self) top.location = self.location;
</script>


<script type="text/javascript">
/* <![CDATA[ */
function playsound(typ) { // die standardkonforme Loesung fuer alle Browser
	document.getElementById("ton").innerHTML = '<object data="'+typ+'" type="application/x-shockwave-flash" width="0" height="0"><param name="movie" value="'+typ+'" /><param name="loop" value="false" /><\/object>';
}
/* ]]> */
</script>

</head>
<body>

<div id="help">
<!-- ######  You can adopt the following text  ###### -->
<h1><a name ="chathelp" id="chathelp"> Chat Help</a></h1>

<?php if ($new_win != "yes") echo ' <p style = "margin: 2em 0"><a href="chat.php" onclick="history.back()">back</a></p>'; ?>

<p style = "margin: 2em 0">There is no registration required to join a chatroom.
<br />It's up to you, whether you use your genuine name, or a nickname. If you prefer, you can remain completely anonymous.
<br />The more applies:
Please behave properly! <a href="http://en.wikipedia.org/wiki/Netiquette"><dfn>external link:</dfn>Wikipedia on Netikette</a></p>

<h3><strong>Notes:</strong></h3>
<p>The operator of the chat has no influence on the expressions of opinion in
the chatrooms, and therefore cannot be held responsible for contents.</p>
<p>Notes for the webmaster [german]: 
<br><a href="https://webdesign.weisshart.de/chat-faq.php"><abbr lang="en" title="frequently asked questions">FAQ</abbr></a></p>


<h2>
Keyboard instructions:</h2>
<p>The following codes can be used in the message input
field (some of them only by the admin):</p>

<table style = "border:0" >
	<tr>
		<td style="width:15em">/clear</td>
		<td>deletes content of private rooms (Admin: all rooms)</td>
	</tr>

	<tr>
		<td style="width:15em">/archiv</td>
		<td>(only Admin): deletes content of room and ads to archive.</td>
	</tr>

	<tr>
		<td>/pn @nick </td>
		<td>sends a private (hid) message (whispers) to nick</td>
	</tr>
	<tr>
		<td>raumname_pr</td>
		<td>produces a clickable link to a private room</td>
	</tr>
	<tr>
		<td>/color #000000</td>
		<td>Color for the own nick and message (Hexcode)</td>
	</tr>
	<tr>
		<td>/ignore nick</td>
		<td>hides all messages sent by nick from your sight. Max. 3 ignores are possible.</td>
	</tr>
	<tr>
		<td>/show</td>
		<td>Shows all messages from ignored nicks.</td>
	</tr>
	<tr>
		<td>/ban nick [min]</td>
		<td>(only Admins &amp; Mods): bannes nick for [min] minutes (use min without the square brackets)</td>
	</tr>
	<tr>
		<td>/kick nick</td>
		<td>(only Admins &amp; Mods): removes nick immediately from the chatroom and bannes for 24&nbsp;h</td>
	</tr>
	<tr>
		<td>/maulkorb nick [min]</td>
		<td>(only Admins &amp; Mods): same as /ban, but the "muzzled" can still read.</td>
	</tr>
	<tr>
		<td>/ghost</td>
		<td>(only Admins): Hides the Admin from the user online list.
                Sending a message (except whispering) terminates the ghost mode. </td>
	</tr>

	<tr>
		<td>/del room</td>
		<td>(only Admins): Deletes a room (without warning!).</td>
	</tr>
	<tr>
		<td>/erase <em>string</em></td>
		<td>(only Admins &amp; Mods): deletes (all) message(s) containing <em>string</em>.
                (in date/time, nick or message). </td>
	</tr>
	<tr>
		<td>/approve <em>Zeichenfolge</em></td>
		<td>(nur Admins): gibt (alle) moderierten Nachricht(en) frei, die <em>Zeichenfolge</em> enthalten.
                (auch im Datum oder Nick).
                <br />Alternativ und schneller: Nick der zu freizugebenden Nachricht anklicken. </td>
	</tr>

	<tr>
		<td>/add <em>URL</em></td>
		<td>(only Admins): tries zu insert gif-image <em>URL</em> into the popup "more smileys.</td>
	</tr>
	<tr>
		<td>/offline</td>
		<td>(nur Admin): Schaltet den Chat offline. Dazu wird ein Raum namens Offline erzeugt.
                <br />Wahlweise kann der Admin in diesen Raum weitere Erkl&auml;rungen zum offline status schreiben.
                Wieder online schalten: Raum Offline l&ouml;schen (mit /del Offline) </td>
	</tr>
</table>

<h2><a name="pn" id="pn">Private messages (whispering):</a></h2>
<p>To send a privat message (whisper), click any user in the user online list, and only you and the clicked user (the
receiver can read the message.</p>
<h3>And for whom rather uses the keyboard:</h3>
<p> /pn @nick (case sensitive) sends a private message.
<br />A private message could look thus as follows:
<br /><em>@Bill only the two of us can read this message /pn</em></p>
<p>It does not matter, in which position within the
private message the code /pn and the nick (with leading @) appear.
Even multiple receivers are possible.</p>
<h3><strong>Note:</strong></h3>
<p>Private messages are not <em>"secure".</em> There are various possibilities of reading private
messages. And, of course, the Admin can read all private messages.</p>
<p>Private messages are deleted after <?php echo $pnlivetime/60; ?> minutes (configurable).</p>


<div class="rooms">
<h2><a name="roomhelp" id="roomhelp">Rooms:</a></h2>


<p>If the standard room becomes too crowdy, you can select one of the public rooms by clicking a room in the list. </p>
<p>To enter public rooms type in the name and press "Enter", or select from the list.</p>

<h3>Creating new rooms</h3>

<p>Use a text editor to create a blank file with the name of the new room.
<br /><em>Caution!</em> The room name = file name must contain only letters, numbers and underscores,
 and must I begin a capital letter.
<br />Upload this file to the directory /rooms on the server.
<br /><em>Caution!</em> The file name must not have any extension such as .txt or the like. 
Some text editors automatically save files with a .txt extension. 
If necessary, delete the extension on the server using an FTP client.
</p>

<h3>Private rooms (whispering rooms):</h3> 
<p>If your topic is not intended for the public, you can create your own private room at any time.
Simply attach _ pr (underline +"pr") to any random room name  (without blanks).
Example: Muenchen_pr. Private rooms are not listed.</p>

<p>If you want to chat in a private room, you have to inform your partner about the name of the new room.
Obviously it's not a good idea to do so in a puplic chat room, but rather through a <a href="#pn">private message</a>, or by means of a hint, which only your partner is able to decipher.</p>

<p><br /><em>Hint:</em> It's a good idea to store the private room in your bookmarks. This way, your preferred display options (date, time, sounds on/off) will also be saved.</p>

<p><br />All public rooms are deleted after 30 days of inactivity (configurable).
<br />All private areas are deleted after 3 hours of inactivity (configurable).
<br />But you can easily create a private area at any time again, as described above.</p>
<h3><strong>Note:</strong></h3>
<p>Private rooms are not <em>"secure"!</em> Anyone who knows or guesses the name of a private room, can enter it.</p>

</div>

<h2>Insert images:</h2>
<p>Simply input an URL, e.g. www.example.com/image.jpg
<br />... sorry, you can't upload imgages.</p>

<h2>Delete messages:</h2>
<p>The admin can delete one ore more messages.
<br />Input /erase <em>string</em> deletes all messages containing <em>string</em> in date/time, nick or message.
<br />Right click on a nick in the message window copies /erase time into the input field.
<br />Warning! /erase is very powerful. E.g. /erase 05 deletes all messages sent in the month of may, even if date/time is not shown. </p>


<h2>Set the color for your nick and your message:</h2>
<p>Input /color #0000FF (hexadecimal color code), or select from the dropdown menu.
adjust.</p>

<h2><a name="datenschutz" id="datenschutz">Reference to privacy</a></h2>
<p>All messages are stored on the server, and can be read there by the server admin.<br />
Private rooms can be cleared by anyone: Just enter /clear. Cleared data are not stored on the server.</p>

<h2>Cookies:</h2>
<p>The script tries to save cookies on the users computer. If your browser accepts cookies
 your nick (and a possibly selected color and other settins) are saved, and reused when you rejoin the chat.
<br />The cookies are deleted automatically after 360 days.</p>
<p><a href="http://en.wikipedia.org/wiki/HTTP_cookie"><dfn>external link:&nbsp;</dfn>Cookie: what is that?
 - is it dangerous?</a></p>

<h2>Thanks: </h2>
<p>Background images by <a href="http://photocase.com/">photocase</a> and <a href="http://www.mandolux.com">mandolux</a>.</p>
<p>Special thanks to: Rainer for many ideas, Martin "the bugfinder", Slava for the utf-8 support,
<br /><a href="http://elmicoxcodes.blogspot.com/2007/03/asynchronous-upload-like-ajax-1.html">micox</a> for asynchronous upload,
<br /><a href="http://getid3.sourceforge.net/">getID3</a>, for checking of upoaded files,

<a style=" color:#222; background: transparent; text-decoration:none" title="Logout" href="chat.php" onclick='document.cookie="nick= ; expires=" + new Date().toGMTString();'>.</a></p>


<?php if ($new_win != "yes") echo ' <p style = "margin: 2em 0"><a href="chat.php" onclick="history.back()">back</a></p>'; ?>

</div>

<!-- ###### the following help notes for visually challanged were translated automatically from german, and are still to be edited ###### -->

<div id="sr" style ="margin-top:10em">
<h1><a name="srhelp" id="srhelp">Notes for blind users</a></h1>

<p style = "margin: 2em 0"><a href="javascript:history.back()">back</a></p>

<p>The experienced ones among you will clearly come 
also without this kurzanleitung, because the Chat is to a large extent barrier-free and
self-describing.</p>

<h3>General references</h3>

<p>If you should lose once orientation or stand at 
the side beginning, the following rule of thumb applies:<br />
Navigate to the first input field for the message. Over it
are directly the messages, among them the Button for mailing and the input field for the name.</p>

<ol>
<li>Support by <span xml:lang="en"  lang="en">sounds</span>: 
<br />Different sound signals announce changes on the side. In 
addition Flash must be
installed:
<br />a) With detailed messages the following sound signal 
sounds: <a href="javascript:playsound('eingang.swf')">Signal for entrance</a>
<br />b) When setting a message off the following
sound is to be heard: <a href="javascript:playsound('click.swf')">Signal for mailing</a>
<br />C) If a new visitor enters the area, or a 
guest with its own name announces itself for the first time, is the 
following sound to be heard: <a href="javascript:playsound('eingang2.swf')">Signal for new 
visitor</a>
<br />D) In the case of actualization of the side
by means of F5 as well as change of the area or change of the 
indicator options, also this is supported with its own sound signal: <a href="javascript:playsound('reload2.swf')">Signal for actualization</a>
<br />Notes: the clay/tone for detailed messages 
comes now and then to injustice, for example with the change of the 
area, or also when mailing own messages. This is a well-known 
error. In addition, the clay/tone comes, if a visitor enters the
area only briefly, and again leaves this immediately, without leaving 
a message.
<br />All tones come also with not active or minimized Browser window, which makes a
"acoustic observation possible" of
the Chats.
</li>

<li>Actualization:
<br />As soon as a message arrives, the side in the Browser is updated. This is
for users of screen readers however only then desirably, if someone waits for a
message, with the Mitlesen the current actualization rather disturbing
would affect itself. More about actualization gives it with the 
notes to the individual screen- and/or to Web readers.
</li>

<li>Messages:
<br />The messages are at the side beginning and thus before the form 
for input for the own message.
<br />Through navigate upward find you first the message written last;
older messages stand over it.
</li>
	
<li>Message write:
<br />The first input field on the side is that one for the message. 
The switch with the inscription "lot" and the input field for 
the name follows.
</li>

<li>Further options:
<br />These can be in and/or faded out by the offerer.
<br />Below the form for message and name there can be two further 
forms: 
<br />- in first you can change the area, 
<br />- in the second date and time out and again fade in, 
and the sound signals out and restart.
</li>
</ol>

<p>To these pre-setting kann's go loosely - bookmarken before
however still the page!</p>

<h3>Suggestions on navigating with screen readers</h3>
<h4>Jaws</h4>

<h5>During the first use:</h5>

<p>Reference (only for Jaws version 6.2):
<br />
First the page personalisieren with Jawskey (Einfg) + switch + V: "side update:
out "</p>

<h5>The first message write:</h5>

<p>After the structure of the side you are on the input field
for the message. If not: With f to the 1. Form.</p>
<p>register the message and this with tab in the input field 
for that.</p>
<p>enter with 2 times tab in the next input field and a name.</p>
<p>Enter sends the message.</p>

<h5>After the message is sent:</h5>

<p>It is advisable to only activate the
Jaws cursor if the clay/tone for a received
message were to be heard. 
<br />Reason: If the Jaws cursor is active, in the Browser is updated, Jaws >probably does not indicate this however
not.</p>

<p>You find not in an input field, kanns you with p and/or 
switch + p von Absatz to paragraph and thus from message to message 
jump. </p>
<p>With tab or F geht's back to the message field.</p>

<h4>Window Eyes</h4>

<h5>During the first use:</h5>

<p>After the structure of the side you are on the input field
for the message. If not: With f to the 1. Form.</p>
<p>with tab in the first input field, MSAA deactivate (switch
+ STRG + A) and the message registering.</p>
<p>enter times tab in the next input field and the name with 
2.</p>
<p>Enter sends the message.</p>

<h5>After the message is sent:</h5>

<p>It is meaningful to leave the MSAA mode deactivated until 
click for a message in-arrived comes, because otherwise the messages 
are not updated.</p>

<p>After receipt of a message and an announcement by 
clay/tone activate and read MSAA mode upward.
<br />Note: navigation between the individual messages with P 
and do not switch + P functioned in <span xml:lang="en" lang="en">Window 
Eyes</span> .
</p>

<p>f leads again back to the form or tab to the input field 
for serves message.</p>

<h4>Home Page reader 3.02</h4>

<h5>During the first use:</h5>

<p>Element read mode stop.</p>
<p>With o to the form.</p>
<p>with tab in the first input field and Enter press, message
a registering and with Enter the input field close.</p>
<p>with two times tab in the next input field and a name 
register and with Enter the input field close.</p>
<p>also switch + tab to the switch "lot" and with Enter the 
message send.</p>

<h5>After the message is sent:</h5>

<p>After click, which indicates the a-long to a new message, 
kanns you with cursor left for
last message navigates and/or you by the messages moves.</p> 
<p>With tab you arrive again into the input field for the 
message.</p>
<p>Note:<br />
- fading out date and time does not function in the Home Page reader 3,02. </p>

<h4>Home Page reader 3.04</h4>

<h5>During the first use:</h5>

<p>Element read mode stop</p>
<p>With o to the form.</p>
<p>with tab in the first input field and Enter press, message
register and the input field with Enter close.</p>
<p>with two times tab in the next input field and name 
register and the input field with Enter close.</p>
<p>also switch + tab to the switch "lot" and with Enter the 
message send.</p>

<p>If a message already comes in during the letter, you can 
close and with cursor left navigate the message field upward with Enter, in
order to read it. If you are however outside of the input field,
it can be that the following message appears: "the side changed.
Please F5 for updating press ". Afterwards you stand at 
the side beginning and must navigate to the last message, which goes 
with o (to the form), followed from cursor left fastest.</p>

<h4>WebFormator</h4>

<h5>During the first use:</h5>

<p>Reference<br />
In order to fade out date and time also in the 
Webformator, mussst you in the option dialogue (alto + o) on register 
register representation the check box "only really visible elements indicate" anhaken.</p>

<p>After the structure of the side you are on the input 
field. If not: Press with STRG + E to the input field for 
the message, Enter and the message register.</p>
<p>register Enter with 2 times tab or STRG + in the next 
input field and the name.</p>
<p>also switch + tab to the loose Button and with Enter send.</p>

<h5>After the message is sent:</h5>

<p>As soon as a message is enough, from which go to current 
position (message field) with the cursor keys upward.</p>
<p>Who would like to reread writing in peace, temporarily the
stop mode with STRG + S in and afterwards again should switch off.</p>
<p>With F5 side contents can again be developed at any time; 
you are thereafter again in the input field for the message.</p>


<h3>Thanks:</h3>
<p>Thanks to <a href="http://babelfish.altavista.com/babelfish/trurl_pagecontent?lp=de_en&amp;trurl=http%3a%2f%2fwww.wai-austria.at%2f">Eva Papst</a> for patiently testing the accessibility,
for many suggestions, and for the production of these references for blind users.</p>

<?php if ($new_win != "yes") echo ' <p style = "margin: 2em 0"><a href="chat.php" onclick="history.back()">back</a></p>'; ?>


</div>
<div id="ton"></div>

</body>
</html>
