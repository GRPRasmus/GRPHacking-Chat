<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

/* CSS fuer Skin 11 Invers */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol, span, form, li, fieldset, input {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #fff;
}


img {
	border:0;
	margin:0;
	padding:0;
}


body {
	padding: 10px 10px 0 10px;
	background:#004; 	/* hier die Hintergrundfarbe fuer die Seite */
}



h1 {
	font-size:1.4em;
	color:#ff8;		/* dies ist ein Beispiel fuer eine spezielle Schriftfarbe fuer die Ueberschrift */
	line-height:125%;
}
h1 span {color:#06AEFF}

h2 {
	font-size:.8em;
	line-height:125%;
}

.rooms h2 {margin-top:1em;}

/*.bg {background:#2a2a2a}*/

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #help tr, #upload input  {
	font-size:.8em;
}

fieldset fieldset a {text-decoration:none;}

a {color:#fff}
a:link, a:visited {}
a:focus, a:hover {background:#00f;}

:focus {
outline: 2px solid #ff7;
}


#addsmileys a:visited span{display:none !important}
#addsmileys a:hover {background:none}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
}

#user_pro_room em:after { /* das geht natuerlich im IE nicht */
	content:"\00A0\221A";
}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}


ul {
	font-size:.8em;
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}

hr {
	display:none;
}


fieldset {
	clear: right;
	margin:0 0 3px 0;
	padding: 3px;
	min-width: 8em;
}



/* Op hack: */
html:first-child>b\ody fieldset fieldset {
	 /* margin-left: 79%; */
}

#wall .whisper,#wall .at {color:#000 !important; background: #dd0 !important; font-weight:700}

@media screen and (min-color-index:0) and(-webkit-min-device-pixel-ratio:0) { @media {
#wall::-webkit-scrollbar { background:transparent;width:6px}
#wall::-webkit-scrollbar-thumb {background:#777;width:5px;border-radius:5px}
}}

#wrapper:after, #opt:after { /* der Konq braucht das 1., der Op das 2. */
	content : ".";		
	display : block; 
	height : 0; 
	clear : both; 
	visibility : hidden;
}


.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #aaa;
}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {
	margin: 0 3px 0 0;
}

#wall {
	height: <?php echo $hoehe?>em;
	background:#000;		/* die Hintergrundfarbe fuer das Nachrichtenfenster */
	overflow: auto;
	margin: 10px 10px 20px 10px;
	line-height: 1.1em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
	border: 1px solid #aaa; border-bottom: 1px solid #aaa;
}

#wall p {
	/* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 3.8em;
	text-indent: -3.4em;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#line {
	width: 80% !important;
	min-width:80% !important;
	max-width: 80% !important;
	font-size:1em;
}
input#line {position:relative; top: -7px;}




#ton {
	width: 0;
	height: 0;
}

/*
#uo {
	display: inline;
	margin-top: .3em;
	<?php
           if ($chat_light != "yes" && $anz_rooms != 1) {
              // das 23 in der folgenden Zeile beeinflusst die Hoehe der user online Anzeige
 	        echo "display:block; height: ".($hoehe - (23 - $user_hoehe))."em; overflow-y:auto; overflow-x:hidden";
           } else {
 		  echo "line-height: 2em;";
           }
      ?>
}
*/

html:first-child>b\ody #uo { /* Opera Hack */
      overflow: auto;
}

#uo ul, #uo ul li {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	} ?>
	font-size:100%;
}
#uo ul, #user_pro_room ul, #opt form p {
	padding: .2em 0 .25em 0;
}


#user_pro_room ul li {
        padding:0;
        line-height:1.3em;
}
* html #user_pro_room ul li {
        line-height:1.2em;
}

#addsmileys {
/*	float:left; */
	margin: 5px 0 0 15px;
}
object {margin: 5px;}


dfn, .dot {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


#f {margin-left:10px;}

#opt input[type=submit] {margin-top:3px}


/* so wills der IE */
#talk input, .rooms input {
       color:#fff;
       background:#333;
       border:1px solid #888;
}

input.button {
       cursor:pointer;
}

.away {margin-left:10px; border: 1px solid #999; background:#333; padding: 2px 4px;}


#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
      border: 0;
      background: transparent;
}

#line, #handle, #room {
       border: 1px solid #888;
       padding: 2px 0 2px 3px;
       color:#fff;
       background:#000;
       cursor:text;
}

label, select {
       cursor:pointer;
}
label {margin:0 3px}


#menu2 {width:60%;font-size: 1.2em}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
}
?>

.uolist {display:none;}
#upload {padding:3px 0 0 9px; margin-top: 10px; clear:left; background-color: #000; }

#logout, .logout {
        text-align:center;
        margin:4px 18px 4px 0;
        border: 2px outset #eee;
        background-color: #000;
}
#logout a, .logout a {
        display:block;
        text-decoration:none;
        padding:0 0 2px 0;
}

.button {padding: 10px; margin-left:3px; bottom:14px !important; background:#000; color:#fff}

/* die Einstellungen fuer high contrast */
#wrapper,
#wall,
.rooms
{background: #004}

/* p {color:#000} */

#wrapper p,
#wrapper p span,
legend,
#uo li,
#uo span,
#uo a,
#user_pro_room a
{color: #ff8 !important; line-height:1.5em;}


#wall p, #wall p span
{line-height: 1.8em !important;}

#uo,
#user_pro_room em,
#f p span {color:#f60 !important}

legend {padding:0}

h2 {font-size: .9em; margin-bottom: .3em;}
h2, h2 span {color: #ddd !important}


#wall p span span span,
#wall p span span
{color: #ff8 !important; background: #00f !important}

#form {display:none}


.bg {background: #006}

#file {
        background: transparent !important;
        border:2px solid transparent !important;
}
* html #file {border: 2px solid #004 !important}

fieldset #upload {
margin-left: 10px;
padding: 5px;
border: 1px solid #888;
}
* html fieldset #upload {margin-left: 5px;}
.helplinks p, .helplinks p a {background: black; color:white;}
.helplinks p a:focus,
.helplinks p a:hover,
.helplinks p a:active
 {background: #00a; text-decoration:none;}

#wall p span span {background-color: transparent !important}

select {
color:white;
background:black;
}

.helplinks p a{margin-bottom:1em;}

#mp3 {
margin: 0 .7em;
}

audio {
-webkit-filter: invert(1);
filter: invert(100%);
}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio_neg.gif);
background-repeat:no-repeat;
background-position: 0 50% ;
}

#ae {margin-bottom:.5em;}

#mp3 {display:block;}
#r_player, #player  {width: 92%;margin: 15px 0 !important}

#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

#topic, #topic_wdw {
padding: 0.4em 0.7em;
font-weight: bold;
color:#eee !important;
}

#nickname {color:red;}

.ip:before {
    content: " IP: ";
}
iframe {background:#aaa;} /* nur fuer Fehlermeldung chat_up_player erforderlich */

#webradio {text-align:center;}
#audio-controls {margin-top: .5em;}
#vol-control{filter: invert(.7);}

input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;}
input[type="image"]:hover, input[type="image"]:focus { background: #004}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
#popout_icon {filter:invert(1);}
