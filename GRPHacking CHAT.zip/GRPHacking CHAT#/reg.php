<?php
$path = '../wartung/sperren.php';
if (file_exists($path)) {require $path; }

// fastreg
header('Content-type: text/html; charset=utf-8');
include("chat_config.php");


// Sprache abfragen und lang-file includen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
      $lang = $languages[0];
}
$lang_file = 'lang'.strtoupper($lang).'_inc.php';
if (file_exists($lang_file)) {
	include ($lang_file);
}


if (!isset($mailmust)) $mailmust = false;

if (isset($stil) && $stil <> 0) {
        $s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
        $s = $default_skin;
}

if (isset($_COOKIE["schrift"])) {
	$schrift= $_COOKIE["schrift"];
}


$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname(htmlspecialchars($_SERVER['PHP_SELF'])), '/\\');
$extra = 'login.php';


$angemeldet = "user/user.txt";
$lines = file($angemeldet);
$meldung = 	_LOGIN_FORM; 
$meldung1 = _LOGIN_FORM1;

$closed = 0;


$alluser[0] = ""; // sollte jemand alle User löschen
// Prüfung ob Nick in der reg-DB:
foreach ($lines as $line_num => $line) {
     $user = explode("****",$line);
     $alluser[] = strtolower($user[0]);
}

if (file_exists("user_anw.txt")) {
	$user = file("user_anw.txt");
	$user1 = implode("",$user);

	if (isset($maxuser) && $user1 >= $maxuser) {
		echo "<p>Maximale Anzahl user erreicht - please try later</p>";
		exit;
	}
}




session_start();
$_SESSION['login'] = 0;

    
if (isset($_POST['anname'])) {  // wenn Registrierung abgeschickt
$anname = trim($_POST['anname']);
if (trim($_POST["wdwchatemail"]) != "") {
  echo "<p>Sie haben ein Feld ausgefüllt, das leer bleiben muss. Bitte gehen Sie mit der Zurück-Funktion Ihres Browsers zurück. Eventuell müssen Sie im Browser gespeicherte Passwörter löschen.</p>";
  exit;
}

if (isset($_POST['date']) && is_numeric($_POST['date'])) {
   $posted = intval($_POST['date']);
   $sendezeit = (time() - $posted);
   if ($sendezeit < 5 || $sendezeit > 300) {
   die("no bots here - take it easy");
 }
}

// keine Registrierung fuer gebannte User
if (file_exists("user/ban.txt")) {
	$banned = file("user/ban.txt");
	foreach ($banned as $c) {
		$part1 = explode("****",$c);
		$part2 = explode("++++",$part1[1]);
		if (strlen($c) > 1 && $part2[0] > time()) {
			$rip = $_SERVER['REMOTE_ADDR'];

			if ($part1[0] == $anname
                        || (trim($rip) == trim($part2[1]) )
                        )  {
				echo "You're banished";
				exit();
			}
		}
	}
}
// keine Registrierung fuer muzzled User
if (file_exists("user/maulkorb.txt")) {
	$banned = file("user/maulkorb.txt");
	foreach ($banned as $c) {
		$part1 = explode("****",$c);
		$part2 = explode("++++",$part1[1]);
		if (strlen($c) > 1 && $part2[0] > time()) {
			$rip = $_SERVER['REMOTE_ADDR'];

			if ($part1[0] == $anname
				|| (trim($rip) == trim($part2[1]) )
			)  {
				echo "You're muzzled";
				exit();
			}
		}
	}
}

if (isset($_POST['usermail'])) { 
   $usermail = htmlspecialchars($_POST['usermail']); 
} else {
   $usermail = "";
} 

$forbidden = false;
$regnick = strtolower($anname);
foreach ( $nicknotallowed as $key => $value ) {
	if (strpos($regnick,$value) !== false) {
		$forbidden = true;
		break;
 	}
}


// nur alle 300 Sek ein reg zulassen
$reg_closed = false;

if (file_exists("user/user_reg.txt")) {
	$prev_reg = file("user/user_reg.txt");
	foreach ($prev_reg as $c) {
		$part = explode("****",$c);
		$frei = time() - $part[0];

		//		echo $part[0].'---'.$part[1].'---'.$frei;
		if (strlen($c) > 1 && $frei < 300) {
			$rip = $_SERVER['REMOTE_ADDR'];
			
			$closed = ceil((300-$frei));


			if (trim($rip) == trim($part[1])) {
		        $meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM10.'<span aria-live="assertive" aria-relevant="all"  id="countdwn"></span></span>';

				$reg_closed = true;
			}
		}
	}
}
	



      
if (in_array(strtolower($anname), $alluser))  { // wenn Nick schon registriert
	$meldung1 = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM2.'</span>';

	//      } elseif (in_array(strtolower($anname), $nicknotallowed))  { // andere verbotene Nicks (chat_config.php)
		//            $meldung1 = "<span style='color:red;font-weight:bold;'>Dieser Nick ist nicht erlaubt!</span>";

	} elseif ($forbidden === true)  { // andere verbotene Nicks (chat_config.php) auch Substrings
		$meldung1 = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM3.'</span>';


		// nicht erlaubte Zeichen abweisen (mit chat_js abgleichen
	} elseif (preg_match("/:|;|,|\.|%|\"|<|>|\?|\/|&| |\+|\*|@|'|-/",$anname)) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM4.'</span>';

	} elseif (strlen($anname) < 1) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM.'</span>';

	} elseif (strlen($anname) < 3) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM1.'</span>';

	} elseif (trim($_POST['anpassword']) == trim($anname)) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM11.'</span>';

	} elseif (!isset($_POST['anpassword']) || strlen($_POST['anpassword']) < 1) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM2.'</span>';

	} elseif ($_POST['anpassword'] != $_POST['password2']) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM3.'</span>';



	}elseif (
	$mailmust &&
		!preg_match("/^([\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+\.)*[\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+@((((([a-z0-9]{1}[a-z0-9\-]{0,62}[a-z0-9]{1})|[a-z])\.)+[a-z]{2,6})|(\d{1,3}\.){3}\d{1,3}(\:\d{1,5})?)$/i", $usermail)
	){
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM4.'</span>';


	}elseif ($reg_closed == true) {
		// do nothing	        $meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM10.'</span>';

		

	} else {
		// user.txt schreiben:
		$fp = fopen($angemeldet, "a+");
		flock($fp,LOCK_EX);
		if (strlen($usermail)>1) { 
			fputs($fp, trim($anname) . "****" . md5($_POST['anpassword']).'****'.$usermail.'****'.date("d.m.Y H:i:s"). "\n");
		} else {
			fputs($fp, trim($anname) . "****" . md5($_POST['anpassword']).'****'.date("d.m.Y H:i:s"). "\n");
		}
		flock($fp,LOCK_UN);
		fclose($fp);

		$_SESSION['login'] = 1;
		$_SESSION['chatuser'] = $anname;
			
		// jetzt festhalten, wann und von welcher IP reg.php aufgerufen wird
		$regtime = time()."****".$_SERVER['REMOTE_ADDR']."\n";

		$file7 = 'user/user_reg.txt';
						
		$lines = file($file7);
		foreach ($lines as $line_num => $line) { // aelter als 1 h loeschen
			$part = explode("****",$line);
			if ((time() - $part[0]) < 60*60) {
				$regtime .= $line;
			}
		}
			
		$open7 = fopen($file7, "w");
		fwrite($open7,$regtime); 
		fclose($open7);
			

		// Redirect zum Chat:
		header("Location: //$host$uri/$extra");
		exit;
	}
}

// http://aktuell.de.selfhtml.org/artikel/css/mobile-endgeraete/
if(file_exists("check_mobile.php")) {
       require('check_mobile.php');
       if(check_mobile() === true) {
        	$s = 7;
        	echo '<style type="text/css">';
            echo 'img {display:none;]';
            echo '</style>';

       } elseif ($s == 7) {
                echo '<style type="text/css">';
                echo 'body {width: 23em;}';
                echo '</style>';
       }
}


?>



 <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">

<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="description" content="Der barrierefreie Chat von webdesign weisshart" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<meta name="viewport" content="width=320" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes" />

<title>Der Chat von webdesign weisshart - Registrierung</title>
<link rel="icon" href="favicon.ico" />
<!-- <link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" /> -->


<?php
if ($s != 7) {
echo '	 
<!-- <link rel="stylesheet" type="text/css" media="screen" href="helpcss'.$s.'.css" /> -->
';
}
?>

<link rel="stylesheet" type="text/css" media="screen" href="login.css" />

<script src="chat_js.php"></script>

<script>
// <![CDATA[

function fuehrendeNull(wert) {
  if (wert<10) return "0" + parseInt(wert);
  else return parseInt(wert);
}

function Sekundenumwandeln(Sekundenzahl) {
 Sekundenzahl = Math.abs(Sekundenzahl)
 return   fuehrendeNull((Sekundenzahl/60)%60) + ":" + fuehrendeNull(Sekundenzahl%60);
}



var zeit = <?php echo $closed; ?>;      

function ZeitAnzeigen() {
if (document.getElementById('countdwn')) {



	if (zeit >= 1) {
		document.getElementById('countdwn').innerHTML = 'in ' + Sekundenumwandeln(zeit);
		zeit = zeit - 1;
		setTimeout("ZeitAnzeigen()", 1000);
	}
	else {
		document.getElementById('countdwn').innerHTML = '';
	}
}
}


function laden() {
//    noshowWait();
	document.getElementById('anname').focus();
}

if (navigator.cookieEnabled == true) {
      window.onload=laden;
}
// ]]>
</script>


<style>
#wdw_logo {height: 50px !important;}
</style>


</head>
<body>


<!-- die folgende Zeile ist nur fuer die Demo, und kann ohne Folgen geloescht oder auch belassen werden: -->
<!-- Wer will, kann hier ein eigenes Logo einbinden -->
<?php if(file_exists("wdw_inc.php") && $s != 12 && $s != 7 ) {
	echo '<div id="logo" style="margin:auto; height:55px; max-width: 200px; padding: 5px 10px">';
	include ("wdw_inc.php"); 
	echo '</div>';
}
?>

<h1><?php echo _REG_H1; ?></h1>

<section role="main">


<?php if(file_exists("lang_switcher_inc.php")) {include("lang_switcher_inc.php");} ?>


<!-- fastreg: -->
<p class="stats">
<?php echo _TO_REG;
if (isset($create_profile) && $create_profile == "yes"){ echo ',<br />'._TO_REG2;} 
?>
.</p>

<p class="stats">
<?php echo _REG_HINWEIS; ?>
<br /><?php echo _REG_HINWEIS1; ?>
</p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" id="reg">
<fieldset>
<legend><?php echo $meldung1; ?></legend>
<label for="anname" class="left"><?php echo _LOGIN_GUEST2; ?></label>
<input type="text" size="20" id="anname" name="anname" maxlength="15" /><br />


<label for="anpassword" class="left"><?php echo _LOGIN_GUEST3; ?></label>
<input type="password" id="anpassword" name="anpassword"/><br />

<label for="password2" class="left"><?php echo _REG_FORM6; ?></label>
<input name="password2" id="password2" type="password" /><br />


<span style="display:none">
   <label for="wdwchatemail"><?php echo _REG_FORM5; ?></label>
   <input type="text" name="wdwchatemail" id="wdwchatemail" title=" dieses Feld muss leer bleiben " /><br />
</span>



<?php
if ($mailmust) {
echo '
<label for="usermail" class="left">'._REG_FORM7.'</label>
';
}else{
echo '
<label for="usermail" class="left">'._REG_FORM8.'</label>
';
}
?>

<input type="text" size="20" id="usermail" name="usermail" maxlength="50" /><br />

<?php
  echo '<p><input name="date" type="hidden" value="', time(), '" /></p>';
?>

<input type="submit" class="right" value="<?php echo _REG_FORM9; ?>" />
</fieldset>
</form>
<?php
$file = file("user/user.txt");
echo '<p  class="stats" style="clear:left">'.count($file).' '._REG_HINWEIS2.'</p>' ;
?>
<!-- end fastreg -->





<?php
if ($_SERVER['SERVER_NAME'] == "webdesign.weisshart.de") {
   echo '
   <p  class="stats">'._REG_HINWEIS3.'</p>
   ';
}
echo '<p class="lnk"><a href="http://webdesign.weisshart.de">Chat by webdesign weisshart</a></p>';
?>

<p><a href="login.php" style="font-weight:bold"><?php echo _TO_LOGIN; ?></a></p>

</section>


<script>
// http://ichwill.net/chapter4.html

function addEvent(obj, evType, fn){
 if (obj.addEventListener){
   obj.addEventListener(evType, fn, false);
   return true;
 } else if (obj.attachEvent){
   var r = obj.attachEvent("on"+evType, fn);
   return r;
 } else {
   return false;
 }
}
addEvent(window, 'load', ZeitAnzeigen);

</script>


</body>
</html>