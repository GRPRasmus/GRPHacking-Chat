<?php

// error_reporting(E_ALL);

// Abfrage, ob Admin:
$admintrue = false;
$modtrue = false;

//session_start(); // ist bereits in chat.php
$nickname= $_SESSION['chatuser'];


if(is_array($admins)){
	foreach($admins as $key => $val) {
		if (utf8_decode($nickname) == trim(utf8_decode($val))) {$admintrue = true;}
	}
}

if (file_exists("admin/interne.txt") && file_exists("admin/admin_interne.php")) {
	$interne = file("admin/interne.txt",FILE_IGNORE_NEW_LINES); 
}


if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != '') {
	$own_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$own_ip = $_SERVER['REMOTE_ADDR'];
}   


// $th_dir = "tn_upload/";

$directory = "";
if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
$abs_path = "http://".$_SERVER['SERVER_NAME'].$directory."/";


$superadmintrue = false;
if (isset($superadmin)) {
	if (in_array($nickname,$superadmin)) {$superadmintrue = true;}
}

if (!isset($ghostpic)) {$ghostpic = " (Ghost)";}

if (!isset($mod)) {$mod = "";}

if (!isset($mod_rooms)) {$mod_rooms = array("");}

if (!isset($vidallow)) {$vidallow = "";}

if (!isset($anz_msg)) {$anz_msg = 40;}
if ($anz_msg > 120) {$anz_msg = 120;}

if (!isset($refresh)) {$refresh = 1500;}
if ($refresh < 500) {$refresh = 500;}

if (!isset($maxwidth)) {$maxwidth = 250;}
if ($maxwidth > 400) {$maxwidth = 400;}

if (!isset($maxheight)) {$maxheight = 120;}
if ($maxheight > 200) {$maxheight = 200;}

if (!isset($show_x)) {$show_x = 800;}
if ($show_x > 1200) {$show_x = 1200;}

if (!isset($max_y)) {$max_y = 600;}
if ($max_y > 900) {$max_y = 900;}

if(!isset($blankrooms)) $blankrooms = "no";
if(!isset($blankroom)) $blankroom = array(' ');


// Abfrage ob registrierter User
if (file_exists("user/user.txt")) {
	$d1 = file("user/user.txt");
	foreach ($d1 as $c) {
		$part1 = explode("****",$c);
		if ($part1[0] == $nickname) {
			$in_regdb = true;
		}
	}
}

if (isset($mods)) {
	foreach($mods as $key => $val) {
		if (utf8_decode($nickname) == trim(utf8_decode($val)) && $in_regdb === true && $admintrue !== true) {$modtrue = true;}
	}
}



// wer hat ein Profil:
$prof_array[] = "";
$dir5 = 'profile/';
if ($handle = opendir($dir5)) {
	// $profil_kz = '';
	// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
	while (false !== ($file = readdir($handle))) {

		if($file != "."
			&& $file != ".."
				&& $file != ".htaccess"
					&& strpos($file,'.jpg') === false
						&& strpos($file,'.gif') === false
		){
			$prof_array[] = $file;
		}
	}
}

if(isset($_SERVER['HTTPS'])) {
	if ($_SERVER["HTTPS"] == "on") {
		$connection = 'https://';
	} 
} else {
	$connection = 'http://';
}

// in welchem Raum bin ich?
$room = "rooms/$standard";


if(isset($_GET['room'])) {
	if (strlen($_GET['room']) > 24) {echo "Achtung: Raumnamen d&uuml;rfen nicht l&auml;nger als 24 Zeichen sein!"; exit;}
	
	if (ctype_alpha (substr($_GET['room'],0,1)) !== true) {echo "Achtung: Raumnamen m&uuml;ssen mit einem Gro&szlig;buchstaben beginnen"; exit;}
	
	if ($_GET['room'] != "" && $_GET['room'] != "_pr" && !stristr($_GET['room'],$standard) ) {
		if (preg_match("=^[a-z\d_]+$=i",$_GET['room']) ) {
			$room = "rooms/".ucfirst(substr($_GET['room'],0,25));			
		}
	}
}


if(isset($_POST['room'])) {
	if (strlen($_POST['room']) > 25) {echo "Achtung: Raumnamen d&uuml;rfen nicht l&auml;nger als 25 Zeichen sein!"; exit;}

	if (ctype_alpha (substr($_POST['room'],0,1)) !== true) {echo "Achtung: Raumnamen m&uuml;ssen mit einem Gro&szlig;buchstaben beginnen"; exit;}

	if ($_POST['room'] != "" && $_POST['room'] != "_pr" && !stristr($_POST['room'],$standard) ) {
		if (preg_match("=^[a-z\d_]+$=i",$_POST['room']) ) {
			$room = "rooms/".ucfirst(substr($_POST['room'],0,25));
		}
	}
}


// den Raum fuer die Shoutbox festlegen:
//if (strpos($_SERVER['SCRIPT_NAME'],"chat_shoutbox.php") !== false  && $_SERVER['SERVER_NAME'] == "webdesign.weisshart.de") {$room="rooms/Demo";}


if(file_exists($room)) {
    $roomexists = true;
}

// damit auch kleine externe Bilder verpixelt werden, wenn pixelon:
if (is_file("jmstv.php") === true && $admintrue === false) {
$maxwidth = $maxheight = 115;		
}


$sav_msg = $anz_msg * 2;

$listen = false;
$showip = false;
$watch = false;
$stop = false;
if (isset($_COOKIE["listen"])) $listen = true;
if (isset($_COOKIE["showip"]) && $_COOKIE["showip"] == "on" ) $showip = true;
if (isset($_COOKIE["watch"])) $watch = true;
if (isset($_COOKIE["stop"]) && $_COOKIE["stop"] == "stop") $stop = true;
if (isset($_COOKIE["color"])) $setcolor = $_COOKIE["color"];
if (isset($_COOKIE["ignore"])) $ignore = $_COOKIE["ignore"];
if (isset($_COOKIE["Style"])) $style = $_COOKIE["Style"];
if($_SESSION['login']==1) $nickname = $_SESSION['chatuser'];





if(!isset($admin_mark)) $admin_mark = "[A]";
if(!isset($mod_mark)) $mod_mark = "[M]";

if (!isset($s)) $s = "";
// if(!isset($profil_mark) || $s==12) $profil_mark = "[P]";
if(!isset($max_length)) $max_length = 500;


// strripos f¸r PHP4: http://www.homepage-forum.de/showthread.php?p=156334
if(!function_exists('strripos')) {
	function strripos($text, $search) {
		$text = strtolower($text); $search = strtolower($search);
		if(strlen($search)==1) return strrpos($text,$search);
		$x = strpos($text, $search);
		do {
			$y = strpos($text, $search, $x+1); $x = ($y) ? $y : $x;
		}
		while ($y);
		return $x;
	}
}

//str_ireplace fuer PHP4: http://de.php.net/manual/de/function.str-ireplace.php
if(!function_exists('str_ireplace')) {
     function str_ireplace($search,$replace,$subject) {
              $search = preg_quote($search, "/");
              return preg_replace("/".$search."/i", $replace, $subject);
     }
}




// Raumliste:
function user_room() {
	global  $anz_rooms,
	$room,
	$standard,
	$roomexists,
	$datum,
	$uhr,
	$sound,
	$nickfarben,
	$lang,
	$nickname,
	$admintrue;

		if ($anz_rooms == 0) {
			if (strpos($room,"_pr") !== false) {
				// homelink fuer _pr
				return "<p><a href=\"chat.php?room=$standard\">"._BACKTOSTD." $standard</a></p>";
			}
			exit; 
		}
			

		$wo = trim(substr($room,6));
		$show_dir = 'rooms/';
		$log_dir=opendir($show_dir);


		$user_room = "<ul>";

		$a = 0;
		while (false !== ($raeume = readdir($log_dir))) {
	
			// Fehlermeldungen bei ungueltigen Raumnamen
			if (strpos($raeume,".") === false) {
				if(strpos($raeume," ") !== false) {echo "<p style='color:red'>"._ROOM_NAME1."</p>"; exit;}
				if (!preg_match( '/^[A-Z]+$/' , substr($raeume,0,1) )) {echo "<p style='color:red'>"._ROOM_NAME2."</p>";}
				if (!preg_match( '/^[a-zA-Z0-9_]+$/' , $raeume )) {echo "<p style='color:red'>"._ROOM_NAME3."</p>"; exit;} // nur Buchstaben, Ziffern und Unterstrich
			}

	
			if(
			(strpos($raeume,"_pr") === false || (isset($_COOKIE["listen"]) && $admintrue !== false))
				&& ($raeume != "Offline"  || $admintrue !== false)
					&& preg_match( '/^[a-zA-Z0-9_]+$/' , $raeume ) // nur Buchstaben, Ziffern und Unterstrich
						&& preg_match( '/^[A-Z]+$/' , substr($raeume,0,1)) // nicht einlesen falls doch ein lower case Raum erstellt wird 	
			){
				$files[] = $raeume;
				$a++;
			}
		}
		closedir($log_dir);

		 if (!isset($files)) {$files[0]="Standard";}
		 sort ($files);
		 // private Raeume ans Ende:
		 foreach($files as $oeftl) {
			 if (strpos($oeftl,"_pr") === false) $oeffentlich[] = $oeftl;
		 }
		 foreach($files as $prfile) {
			 if (strpos($prfile,"_pr") !== false) $privat[] = $prfile;
		 }
		 if (isset($privat)) {
			 $files = array_merge ($oeffentlich,$privat);
		 }




		$countall = 0;
		foreach($files as $file) {

			 // das ip file:
			 $ip_file = 'user/ip_'.$file.'.txt';

			 $c = false;
			 
			 // // file ggf erstellen:
			 // if (!file_exists($ip_file)) {
			 // 				 fopen($ip_file, "w");
			 // }
			 
			if (file_exists($ip_file)) { 
			 $filealter = time()-filemtime($ip_file);
			
			 if (false !== ($row=file($ip_file)) && $filealter <= 7) {
				 $fp = fopen($ip_file,"r"); 
				 $c=-1;
				 while (!feof($fp)) {
					 $zeile = fgets($fp, 150); //liest 150 zeichen aus ... zeile der datei
					 if (strpos($zeile,"ghost") === false) $c++; // damit Ghosts nicht kurzzeitig angezeigt werden:
					 }
				fclose($fp);
					
				$countall = $countall + $c;
				if ($c==0) $c = "";          // damit O user nicht angezeigt werden
			}
		} 

				 if ($c >= 1) $c = "<span style=\"color:red;font-weight:bold;\">[$c]</span>";

				 //        		$location = str_replace("_pr"," [pr]",$file); // wozu sollte das sein?
				 $location = $file;

				 if ($file == $wo) {
					 $user_room .= "<li><em><dfn>"._ACTROOM.": </dfn>$location</em></li>\n";
				 } elseif ($file == $standard) { // zum Standardraum ohne Raumname verlinken:
					 $user_room .= "<li><a href=\"".$_SERVER['PHP_SELF']."\">$location</a> $c</li>\n";
				 } else {
					 // hier auch die Optionen mitgeben
					 $user_room .= "<li><a href=\"".$_SERVER['PHP_SELF']."?room=$file\">$location</a> $c</li>\n";
				 }
			 }

			 $user_room = "$user_room</ul>";

			 // die Gesamtzahl anwesender user in ein file schreiben fuer externe Abfrage:
			 // nicht aktiv. Wer die Funktion will: die folgenden 4 Zeilen entkommentieren
			 // $file4 = 'user_anw.txt';
			 // $open4 = fopen($file4, "w");
			 // fwrite($open4,$countall);
			 // fclose($open4);

			 // wenn nur 1 Raum, keine Raumliste zeigen:
			 // wenn nur 1 Raum, und der gewaehlte Raum nicht existiert, dennoch Raumliste zeigen:
			 if ($a <= 1 && strpos($room,"_pr") === false && $roomexists !== false) $user_room = "";


			 return $user_room;
		 }


// die anwesenden user:
function user_online() {
	

	global  $room,
	$nickname,
	$admins,
	$mods,
	$s,
	$admins_no_mark,
	$superadmintrue,
	$ghostpic,
	$chat_light,
	$standard,
	$admin_mark,
	$mod_mark,
	$support_mark,
	$stop,
	$watch,
	$listen,
	$ignore,
	$admintrue,
	$superadmintrue,
	$watch,
	$reg_only_viewprof,
	$in_regdb,
	$prof_array,
	$own_ip,
	$profil_mark;

	$wo = trim(substr($room,6));
	
	
	// user pro Raum:
	$roomid = str_replace("rooms/","_",$room);

	//
	// // Lockfile löschen:
	// $lockfile = 'lock_fh.txt';
	// if (file_exists($lockfile)) {
	// 	unlink($lockfile);
	// }
	// // usleep(100000);
	//
	// $beginn = microtime(true);
	//
	if ($watch !== false && $admintrue === true) echo "<span lang=\"en\" style=\"color:#f30 !important; font-weight:bold;\">… ghost mode on </span><br />";
	if ($stop !== false) echo "<span lang=\"en\" style=\"color:#f30 !important; font-weight:bold;\">… reading mode on </span><br />";

	if (($listen === true && $admintrue === true  && $watch !== true) || ($listen === true && $superadmintrue===true) ) echo "<span lang=\"en\" style=\"color:#f30 !important; font-weight:bold;\">… u're Peeping-Tom! </span><br />";


	if (isset($ignore)) {
		$ign_usr = str_replace("----",", ",$ignore);
		echo "<span style=\"color:red !important; font-weight:bold;\">... ignoring $ign_usr</span><br />";
	}

	$show_online = "";
	$ghost ="";

	// Raeume in chat-light anzeigen:
	if ($chat_light != "no") echo _YOURINROOM." <span style = \"font-weight:bold; color:#f00\">$wo</span>&nbsp; ";

	$rip = $own_ip;


	$sd  = time();

	// $count initialisieren:
	$count = "";

	$rip_nick = $rip.$nickname;



	$file1 = 'user/ip'.$roomid.'.txt';

	$lines = array();


	if (!file_exists($file1)) {
		$my = "";
		

		$fh = fopen($file1, "a");
		fwrite($fh, $my);
		fclose($fh);

	} else {
		
		$fh1 = fopen($file1,"r");
		while(!feof($fh1)) {
			$lines[] = fgets($fh1,1024);
		}
		fclose($fh1);
		
		$fullcount = $count= count($lines) -1;

		$line2 = "";
		foreach ($lines as $line_num => $line) {
			if (strpos($line,"ghost") !== false) {$count = $count-1;}
			
			$fp = strpos($line,'****');
			$nam1 = substr($line,0,$fp);	// = IP
			
			$nam = $nam1;
			
			$sp = strpos($line,'++++');
			$val = intval(substr($line,$fp+4,$sp-($fp+4)));	// = timestamp

			$online = trim(substr($line,$sp+4));	// = nick
			
			
			$online2 = explode("####",$online);
			$online3 = $online2[0];
			// $online4 = $online2[1];
			$nam_online = $nam.$online3;	// = IP.nick
			
			$array[] = $online;	

			if ($online3 == "") $array_ghost[] = "";

			$diff = $sd-$val;
			if($diff < 20 && $nam_online != $rip_nick) { 
				//	if (strpos($line,"ghost") === false) {$count = $count+1;}
				//$count= $count+1;
				$line2 = $line2.$line;
			}
		}

		if ($admintrue !== true || $watch !== true) {
			
			if ($s == 7) {
				$my = $rip."****".$sd."++++".$nickname."####handy \n";
			} else {
				$my = $rip."****".$sd."++++".$nickname."#### \n";			
			}
		} else { 
			if ($s == 7) {
				$my = $rip."****".$sd."++++".$nickname."####ghost----handy \n"; // auch /ghost Admins schreiben, aber Anzeige nur wenn ...
			} else {
				$my = $rip."****".$sd."++++".$nickname."####ghost \n"; // auch /ghost Admins schreiben, aber Anzeige nur wenn ...				
			}
		}


		$line3 = $line2.$my;
		
		$fh2 = fopen($file1, "w");
		fwrite($fh2,$line3);
		fclose($fh2);


		$array = array_unique($array); // entfernt doppelte User
		natcasesort($array);


		if (isset($array_ghost)) {
			$arrcount = count($array_ghost) -1 ;
			if ($arrcount >= 1) {
				$hidden = $arrcount;
				if ($hidden > 1) {
					$ghost = "<li>...&nbsp;$hidden"._GUESTSLOGIN."</li>";
				} else {
					$ghost = "<li>...&nbsp;$hidden"._GUESTLOGIN."</li>";
				}

			}
		}


		foreach ($array as $key => $us) {
			if($us != "" && $us !=" ()") {

				$part_ip = explode(" (",$us);
				$us1 = $part_ip[0];				
				$temp = explode('####',$us);
				$us = $temp[0];
				$us_ghost= $temp[1];


				// gebannte user kennzeichnen:
				$bd="";
				if (file_exists("user/ban.txt") && filesize("user/ban.txt") > 0) {
					$banned = file("user/ban.txt");
					foreach ($banned as $c) {
						$part1 = explode("****",$c);
						$part2 = explode("++++",$part1[1]);
						// Rest Banzeit:
						$nochraw = ($part2[0] - time()) / 60 + 1; 
						$nochstunden = floor($nochraw /60);
						$nochminuten = floor(($nochraw - $nochstunden*60)) ;
						if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
						$noch = '&nbsp;'.$nochstunden.':'.$nochminuten.'&nbsp;h';
						if ($part1[0] == $us && $part2[0] > time()) $bd = ' [ban\'d&nbsp;'.$noch.']';
					}
				}
				// gemaulkorbte user kennzeichnen:
				// $bd="";
				if (file_exists("user/maulkorb.txt") && filesize("user/maulkorb.txt") > 0) {
					$banned = file("user/maulkorb.txt");
					foreach ($banned as $c) {
						$part1 = explode("****",$c);
						$part2 = explode("++++",$part1[1]);

						// Rest Banzeit:
						$nochraw = ($part2[0] - time()) / 60 + 1; 
						$nochstunden = floor($nochraw /60);
						$nochminuten = floor(($nochraw - $nochstunden*60)) ;
						if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
						$noch = ' '.$nochstunden.':'.$nochminuten.' h';
						if ($part1[0] == $us && $part2[0] > time()) $bd = ' :-X '.$noch;
					}
				}

				if (file_exists("profile/$us")) {	
					$test=time();
					if( strpos(file_get_contents("profile/$us"),'männlich') !== false) {
						$bd .= '&nbsp;<a href="popprof.php?test='.$test.'&amp;profil='.$us.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$us.' anschauen (Popup)"  ><img src="data:image/png;base64,'. base64_encode(file_get_contents("img/gender_masc.gif")) .'" alt="männlich"  height="14" ></a>';
					}
					elseif( strpos(file_get_contents("profile/$us"),'weiblich') !== false) {

						$bd .= '&nbsp;<a href="popprof.php?test='.$test.'&amp;profil='.$us.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$us.' anschauen (Popup)"  ><img src="data:image/png;base64,'. base64_encode(file_get_contents("img/gender_fem.gif")) .'" alt="weiblich"  height="14"  ></a>';

					}					
					else {

						$bd .= '&nbsp;<a href="popprof.php?test='.$test.'&amp;profil='.$us.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$us.' anschauen (Popup)"  ><img src="data:image/png;base64,'. base64_encode(file_get_contents("img/mensch.png")) .'" alt="Profil" title="Profil von '.$us.' anschauen (Popup)"  height="14" ></a>';

					}					
				}



				if (strpos($us_ghost,"handy") !== false) {
					$bd .= '&nbsp;<img src="data:image/png;base64,'. base64_encode(file_get_contents("img/handy.png")) .'" alt="📱" title="ist mit Handy online"  height="13"  >';
				}


				// den Mod in der Liste kennzeichnen:
				foreach($mods as $key => $val2) {
					if (utf8_decode($us) == trim(utf8_decode($val2)) && $us != ""   && (!isset($admins_no_mark) || in_array($us,$admins_no_mark) === false)) {
						$bd .= "&nbsp;$mod_mark";
					}
				}

				if ($us == "Support" || $us == "System" || $us == "Kastellan") {
					$bd .= "&nbsp;$support_mark";
				} else {

					// den Admin in der Liste kennzeichnen:
					foreach($admins as $key => $val) {
					
						if (utf8_decode($us) == trim(utf8_decode($val)) && $us != ""   && (!isset($admins_no_mark) || in_array($us,$admins_no_mark) === false)) {
							$bd .= "&nbsp;$admin_mark";
						}
					}
				}

				//if ($us_ghost == "ghost") {
				if (strpos($us_ghost,"ghost") !== false) {
					if ($superadmintrue !== false) {
						$bd .= $ghostpic;
					} else {
						$us = $bd = ""; 
					}
				} 



				// den nick anklickbar machen zum Absetzen einer PN:
				if ($us != $nickname) {

					// IP zeigen:		
					if ($admintrue !== false) {
						if (isset($part_ip[1]) && $part_ip[1] !="") {
							$ip_anzeige = " ($part_ip[1]";
						} else {
							$ip_anzeige="";
						}
						$bd = $bd.$ip_anzeige;
					}

					// zufaelligen Raumnamen erzeugen:
					$zeichen="abcdefghikmnopqrstuvwxyzABCDEFGHKLMNPQRSTUVWXYZ123456789";
					$stringlaenge = 6;

					$zufall = '';
					$zeichenlaenge = strlen($zeichen);
					// So oft ein zuf‰lliges Zeichen anhaengen bis $stringlaenge erreicht ist:
					for($i=0;$i<$stringlaenge;$i++) {
						$zufall.=substr($zeichen,mt_rand(0,$zeichenlaenge-1),1);
					}
					// $zufall = ucfirst($zufall);
					// ein X davor, damit _pr in der reader-Auswahlhilfe leichter zu finden sind:
					$zufall ='X'.$zufall;




					if ($us != "" && in_array($us,$prof_array) && (($reg_only_viewprof == true && $in_regdb == true) || $reg_only_viewprof != true) ) {
						// Profil als Popup, wenn [P] geklickt wird:
						// time() als URL Parameter dazu, damit die URL zum Popup nur befristet gilt.
							
						$test = time();
						$show_online = $show_online." <li> <a href=\"#\" onclick=\"ads('@".$us." /pn'); return false; \"  oncontextmenu=\"ads('".$zufall."_pr @".$us." /pn'); return false;  \"title=\""._WHISPERTO.$us." \">".$us."</a>".$bd." </li> ";


					} else {
						$show_online = $show_online." <li><a href=\"#\" onclick=\"ads('@".$us." /pn'); return false; \"  oncontextmenu=\"ads('".$zufall."_pr @".$us." /pn'); return false;  \"title=\""._WHISPERTO.$us." \">".$us."</a>$bd</li> ";
					}

				} else {
					if (in_array($us,$prof_array) && (($reg_only_viewprof == true && $in_regdb == true) || $reg_only_viewprof != true) ) {

						// Profil als Popup, wenn [P] geklickt wird:
						/* 	$test = time(); jetzt per JS */
						$show_online = $show_online." <li>".$us.$bd." </li> ";


					} else {
						$show_online = $show_online." <li>".$us.$bd." </li> ";
					}
				}
			}
		}

		// homelink fuer chat-light:
		if ($room != "rooms/$standard" && $chat_light == "yes") {
			$homelink = " [<a href=\"chat.php?room=$standard\">"._BACKTOSTD." $standard</a>]";
		} else {
			$homelink ="";
		}


		if ($count <= 1 && !$admintrue ) {
			$count = _ALONE." $homelink";		
		} elseif ($count == 0 && $admintrue ) {
			$count = _ALONE." <ul> $show_online$ghost</ul> $homelink";		
		} else {
			$count = "<span class=\"uo_head\" style=\"font-weight:bold\">"._INROOM.": </span> <ul> $show_online$ghost</ul> $homelink";
		}

	}

	//
	// $dauer = (microtime(true) - $beginn) * 1000;
	// $ms = number_format ($dauer,2 );
	// echo "<span id='reload_time' style='opacity:.2;font-size:9px'>";
	// echo $ms.' ms<br>';
	// echo "</span>";
	//
	//
	//
	// // Lockfile schreiben:
	// $lockfile = 'lock_fh.txt';
	// // if (!file_exists($lockfile)) {
	// 	$fh3 = fopen($lockfile, "w");
	// 	fwrite($fh3, "");
	// 	fclose($fh3);
	// // }
	//

	
	return $count;
	
}




function linker($link) {
	global $room,
	$uhr,
	$datum,
	$links,
	$anonymizer,
	$th_dir;
	$sound;
	    
		
	// $link = preg_replace( '#\:\d+#','' , $link );
		   
	$linkx = $link;	// Unterscheiden, ob URL oder PN umgewandelt wird


    if (strpos($link,":http://") === false) {   // wegen http://tbn0.google.com/images?q=tbn:Cg5amOzrpIob9M:http://www.cclonline.com/
	   $link = str_replace("http"," http",$link); // Leerzeichen vor dem URL erzwingen:
	}

	if (strpos($link,"https://") === false) {
		$link = str_replace("www."," www.",$link);
    	$link = str_replace("http:// www.","http://www.",$link);
	}

	$link = str_replace("http://www.","www.",$link);
	$link = str_replace("www.","http://www.",$link);

	$link = str_replace("https://http://","https://",$link);

    if (strpos($link,"?cid") !== false) {	
		$link = strtok($link, "?");
	}


	// wegen z.B. http://images.google.de/imgres?imgurl=http://www.enorma...:
	$link = str_replace("= http","=http",$link);
	
	if (strpos($link,"smileys") > 0) {
		$link = str_replace(".gif",".gif ",$link);
		$link = str_replace(".png",".png ",$link);
	}
	$link = str_replace(".jpg",".jpg ",$link);



	function shortlink2($matches) { 
		global $new_win,
		$nick,
		$admintrue,
		$imginclude,
		$th_dir,
		$links,
		$maxwidth,
		$maxheight,
		$show_x,
		$max_y,
		$connection,
		$directory,
		$abs_path,
		$is_fp;


		$matches[0] = str_replace("<","&lt;",$matches[0]);
		$matches[0] = str_replace(">","&gt;",$matches[0]);

		$nocache = false;
		if (strpos($matches[0],"profile") !== false) $nocache = true; // damit Profilbilder nicht gecacht werden

		$moresmileys = $matches[0]; // ermoeglicht more smileys auch mit imginclode no

		// // abs. Pfad in  relativen Pfad umwandeln, wg. allow_url_fopen
		// // HTTP / HTTPS bestimmen
		// if(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!='off' or $_SERVER['SERVER_PORT']==443) {
		// 	$protocol='https';
		// } else {
		// 	$protocol='http';
		// }
		// $abs_path = "$protocol://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF'])."/";
		//
		//     	$matches[0] = str_replace($abs_path,"",$matches[0]);
				
		

		// damit getimagesize nicht bei externen Links aufgerufen wird (wenn der Server das nicht erlaubt):
		if ($is_fp !== false || strpos($matches[0],"http") === false) {

			if ($imginclude == "yes" || $admintrue !== false || strpos($moresmileys,"/smileys") !== false) {
			$size = getimagesize (trim($matches[0]));


				if ($size[2] == 1 || $size[2] == 2 || $size[2] == 3) {
					$orgwidth = $size[0];
					$orgheight = $size[1];
					$width = $maxwidth;
					$height = $maxheight;

					$ratio = $orgwidth / $orgheight;
					if ($orgwidth >= $show_x) {$orgwidth = $show_x; $orgheight = $show_x / $ratio;} // Hochformat nicht beruecksichtigt

					// wg. Browser min Popup-width
					if ($orgwidth < 190) {
						$popheight = $orgheight * (190/$orgwidth);
						$popwidth  = $popheight * $ratio;
					} else {
						$popheight = $orgheight;
						$popwidth  = $orgwidth;
					}

					if (($orgheight / $height) > 1.5) {	// popup nur wenn > 150% von thumb	(nicht _pr)

						$th_dir = str_replace ('/upload/','/tn_upload/',$matches[0]);

						return ' <a class="pop" href="'.$matches[0].'" onclick="document.getElementById(\'line\').focus(); OpenNewWindow(this.href,'.$popwidth.','.$popheight.',\'\');return false;" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'"  onerror="this.style.display=\'none\'" src="'.$th_dir.'"   /></a> ';


					} else {
						$onklick = 'onclick="ads(\''.$matches[0].'\'); return false; "';						
						return ' <img oncontextmenu="max(this);return false;" '.$onklick.' style="cursor:pointer" alt="'._USERIMG.'"  onerror="this.style.display=\'none\'" src="'.$matches[0].'"  /> ';
					}

				}
			}
		}


		if ($new_win == "yes") {
			$linktarget = "target=\"_blank\" title=\"Link öffnet in neuem Tab/Fenster\"";
			$ext_hinweis = "<span class=\"dot\">"._LNKNEWWIN.": </span>";
		} else {
			$linktarget = "";
			$ext_hinweis = "";
		}


		if (isset($links) && $links == "no" && $admintrue === false) return _NOLINK;

		if (strlen($matches[0]) > 37 && strpos($matches[0],'/smileys4') === false ) {
		// if (strlen($matches[0]) > 37) {
			return $ext_hinweis.'<a href="'.$matches[0].'" rel="nofollow" '.$linktarget.'>'.substr($matches[0],0,30).' ...</a>';

		} else {
			return $ext_hinweis.'<a href="'.$matches[0].'" rel="nofollow" '.$linktarget.'>'.$matches[0].'</a>';

		}
	}

	$link = preg_replace("/([\S+\.\/]+\@(\[?)[\S+\.]+\.([a-zA-Z0-9]{2,6})(\]?))/i","<a href=\"mailto:$1\" rel=\"nofollow\">$1</a>",$link);

	$link = preg_replace_callback("/([\w]+:\/\/[\S+\.\/\@]+[\w\/])/i","shortlink2", $link);



	// Einladung in private R‰ume zum Link umwandeln:
	if ($link == $linkx && strpos($link,"/del") === false) {
			
		if (strpos($link,"/pn") === false) {
			$link = preg_replace("/(\b\w+_pr\b)/",_INVITEPR." <a href=\"chat.php?room=$1\" onclick=\"prbox(this.href); return false;\" >$1</a><br />"._INVITEADVISE."", $link);
		} else {
			$link = preg_replace("/(\b\w+_pr\b)/",_INVITEPR." <a href=\"chat.php?room=$1\" onclick=\"prbox(this.href); return false;\" >$1</a><br />", $link);
		}

	}

	return $link;

}

	
function colorify_ip($ip) {
	global $room,$d,$setcolor,$s;
	
	if ($setcolor != "") {
		$color = $setcolor;
	} else {
		
		// IPv6 zu IPv4-Format umwandeln:
		if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
		//if (strpos($ip,":") !== false) {
			$ipparts = explode(":",$ip);
			$z = count($ipparts);

			$ip = hexdec(substr($ipparts[$z-4],0,2)).'.'.
			hexdec(substr($ipparts[$z-3],0,2)).'.'.
			hexdec(substr($ipparts[$z-2],0,2)).'.'.
			hexdec(substr($ipparts[$z-1],0,2)).'.';
		}
		
	
	
	$parts = explode(".", $ip);
	
	// Dunkles Grau in Richtung Rot verschieben:
	if ($parts[1] < 10) {$parts[1] = $parts[1]+200;}
	if ($parts[1] < 100) {$parts[1] = $parts[1]+100;}

	$color = sprintf("%02s", dechex($parts[1])) .
			 sprintf("%02s", dechex($parts[2])) .
			 sprintf("%02s", dechex($parts[3]));

	}

	$color = str_replace("2","3",$color);		
	$color = str_replace("1","2",$color);
	$color = str_replace("0","2",$color);

	$color = str_replace("C","b",$color);
	$color = str_replace("c","b",$color);
	$color = str_replace("D","b",$color);
	$color = str_replace("d","b",$color);
	$color = str_replace("E","b",$color);
	$color = str_replace("e","b",$color);
	$color = str_replace("F","b",$color);
	$color = str_replace("f","b",$color);	
	

	return $color;
}


function textWrap($text) {
	$new_text = '';
	$text_1 = explode('>',$text);
	$sizeof = sizeof($text_1);
	for ($i=0; $i<$sizeof; ++$i) {
		$text_2 = explode('<',$text_1[$i]);
		if (!empty($text_2[0])) {
			$new_text .= preg_replace('#([^\n\r ]{35})#i', '\\1<wbr>', $text_2[0]);  // auch ..... umbrechen
		}
		if (!empty($text_2[1])) {
			$new_text .= '<' . $text_2[1] . '>';
		}
	}
	return $new_text;
}


function add_line($msg) {
	global $room,
	$roomexists,
	$smileys,
	$admintrue,
	$superadmintrue,
	$modtrue,
	$nickname,
	$flood,
	$closepr,
	$shoutbox,
	$mods,
	$mod_rooms,
	$watch,
	$ignore,
	$maxwidth,
	$time_offset,
	$prof_array,
	$in_regdb,
	$anonymizer,
	$bis_offen,
	$ab_offen,
	$imginclude,
	$ip_write,
	$links,
	$showip,
	$reg_only_viewprof,
	$logfile,
	$topic_scroll,
	$own_ip,
	$abs_path,
	$gema,
	$usercolor,
	$setcolor,
	$vidallow,
	$interne,
	$smiley_dirs,
	$max_length;

	$Gueltigkeit = time()+86400*360;	// cookie gilt 360 Tage




	$wo = trim(substr($room,6));
	if (strlen($msg)> $max_length+20) {exit;} // weil maxlength ueberlistet werden kann.


	if ($wo == "Intern") {
		if (!in_array($nickname,$interne) && $admintrue === false ) {
			exit();
		}
	}


	// Chat nicht zeigen, wenn offline: ACHTUNG! Ausnahmen auch in function refresh()
	if ((file_exists("rooms/Offline")
		&& $room != "rooms/Info"
			&& $room != "rooms/Buglist"
				&& $admintrue === false)
					&& (strpos($room,"_pr") === false
						|| (strpos($room,"_pr") !== false && $closepr != "no"))
							)
	{
		exit();
	}

	// Admin darf loeschen, und jedermann in privaten Raeumen:

	if(($admintrue !== false && (!isset($logfile) || $logfile != "on")) || (strpos($wo,"_pr") !== false  && (!isset($logfile) || $logfile != "on" ))) {
		if(strpos($msg," /clear") !== false) {
			$fd = fopen("$room", "w+");
			fclose($fd);
		}
	}

	// aktuellen Inhalt zur Archivdatei hinzufuegen:
	if(($admintrue !== false && strpos($msg," /archiv") !== false || (strpos($msg," /clear") !== false && isset($logfile) && $logfile == "on" )) || (isset($logfile) && $logfile == "on" && strpos($wo,"_pr") === false && strpos($msg," /archiv") !== false || (strpos($msg," /clear") !== false)) ) {

		$handle = fopen ($room, "r");
		$contents = fread ($handle, filesize ($room));
		fclose ($handle);
		$lines = explode("\n",$contents);

		foreach($lines as $oeftl) {
			// if (strpos($oeftl,"approve") === false && strpos($oeftl,"Chatbot") === false) $tolog[] = $oeftl;
			$tolog[] = $oeftl;
		}

		$contents = implode("\n",$tolog);

		// jetzt rel. img Pfade fuers Archiv anpassen:
		$contents = str_replace("smileys/","../smileys/",$contents);
		$contents = str_replace("smileys2/","../smileys2/",$contents);
		$contents = str_replace("smileys3/","../smileys3/",$contents);
		$contents = str_replace("upload/","../upload/",$contents);
		$contents = str_replace("profile/","../profile/",$contents);
		$contents = str_replace("img/","../img/",$contents);
		$contents = str_replace("wmk.php?pic=","",$contents);

		$contents = str_replace("tn_../upload/","../tn_upload/",$contents);
		$contents = str_replace("popprof.php","../popprof.php",$contents);
				  


		// IPv4:
		$contents = preg_replace('~(\d+)\.(\d+)\.(\d+)\.(\d+)~', "$1.$2.$3.x", $contents);

		// IPv6 (alle Formen):
		if (strpos($contents,"::") !== false) {
			$contents = preg_replace('~([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*)~', "$1:$2:$3:$4:$5:x:x", $contents);
		} else {
			$contents = preg_replace('~([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*)~', "$1:$2:$3:$4:$5:$6:x:x", $contents);
		}


		$fprot = fopen("logs/".$wo."_log", "a");
		flock($fprot,LOCK_EX);
		fwrite($fprot, $contents);
		fflush($fprot);
		flock($fprot,LOCK_UN);
		fclose($fprot);
        		
		// um doppeltes Archivieren zu vermeiden, wird auch noch gecleared:
		$fd = fopen("$room", "w+");
		fclose($fd);

	}


	//	if (file_exists("ban_inc.php")) include("ban_inc.php");
	if (file_exists("user/ban.txt")) {
		$banned = file("user/ban.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);
			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  {
					exit();
				}
			}
		}
	}

	if (file_exists("user/maulkorb.txt")) {
		$banned = file("user/maulkorb.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);

			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  {
					exit;
				}
			}
		}
	}





	// nur Admin darf Raeume loeschen:
	if (strpos($msg,"/del ") && $admintrue !== false) {
		
		if (strpos($msg,"offline")) {$msg = str_replace("offline","Offline",$msg);}
		$del_file = explode("/del ",$msg);

		if(file_exists("rooms/$del_file[1]")) {
			unlink("rooms/$del_file[1]");
		}
		$msg = $msg." /pn";	// /del wird immer /pn, und damit nur fuer den Admin sichtbar
	}

	if (strpos($msg,"/alarm ") && $admintrue !== false) {
		$msg = $msg." /pn";	// /alarm wird immer /pn
	}

	$msg = $msg." ";       // damit die Abfragen nach ganzen Woertern funktionieren


	// hier wird bei Bedarf die Systemzeit geaendert
	$time_off = 0;
	if(isset($time_offset)) $time_off = $time_offset * 3600;


	$dt0 = date("d.m.", time() + $time_off);
	$dt = "<span class=\"dt\">$dt0</span>";
	
        

	$uhr0 = date("H:i:s", time() + $time_off);
	$uhr = "<span class=\"uz\">$uhr0</span>";


	$msg = str_replace("<","&lt;",$msg);
	$msg = str_replace(">","&gt;",$msg);
	$msg = strip_tags(stripslashes($msg));


	$msg = str_replace("("._MESSAGE.")","",$msg); // falls das stehen bleibt, z.B. bei drag & drop
	$msg = str_replace(_MESSAGE,"",$msg); // falls das stehen bleibt, z.B. bei drag & drop





	$msg_explode = explode(":",$msg,2);

	$msg_explode[0] = $nickname;


	// Profile:
	if (strpos($msg_explode[1],"/profil ") || strpos($msg_explode[1],"/profile ")) {
	

		if ($in_regdb !== true && $reg_only_viewprof === true ) {
			$msg_explode[1] = _SHOW_PROFIL.' /pn';
		} else {
			if (strpos($msg_explode[1],"/profile")) $msg_explode[1] = str_replace("/profile","/profil",$msg_explode[1]);

			$profile_file = trim(str_replace("/profil ","",$msg_explode[1]));

			// Text hinter /profil wegmachen
			$temp = explode(" ",$profile_file,2);
			$profile_file = $temp[0];


			if(file_exists("profile/$profile_file")) {
				$lines = file("profile/$profile_file");

				$profiletime = filemtime("profile/$profile_file");
				$dt7 = date("(d.m.y H:i \U\h\\r) ", $profiletime);

				for($i=1;$i<count($lines);$i++) {
					// leere nicht anzeigen
					if (trim($lines[$i]) != "Hobbys:&nbsp;"
					&& trim($lines[$i]) != "kein Bild &nbsp;"
					&& trim($lines[$i]) != "&nbsp;"
					&& trim($lines[$i]) != ""
					&& trim($lines[$i]) != "Geschlecht:&nbsp;"
					&& trim($lines[$i]) != "Alter:&nbsp;"
					&& trim($lines[$i]) != "Wohnort:&nbsp;"
					&& trim($lines[$i]) != "Sternzeichen:&nbsp;"
					&& trim($lines[$i]) != "E-Mail:&nbsp;"
					&& trim($lines[$i]) != "Bemerkung:&nbsp;"
					&& trim($lines[$i]) != "wei&szlig; nicht"
					) {
						$zeile = $zeile."<br />".trim($lines[$i]);
					}
					$zeile = str_replace("E-Mail:&nbsp;","E-Mail: ",$zeile); // das ist noetig wg. auto-E-Mail
					$zeile = str_replace("@","(at)",$zeile); // weil sonst die Profilanzeige gefluester wird
				}

				if ($zeile == "") {
					$msg_explode[1] = str_replace("/profil ","",$msg_explode[1]);

					$msg_explode[1] = $msg_explode[1]." hat kein Profil angelegt. /pn";

					if(file_exists("profile/$profile_file")) {
						unlink("profile/$profile_file");
					}

				} else {
					$msg_explode[1] = ':br:<b>Profil von '.$profile_file.':</b> '.$dt7.$zeile.' /pn'; // /profile wird immer /pn, und damit nur fuer den Absender sichtbar
				}

			} else {
				$msg_explode[1] = str_replace("/profil ","",$msg_explode[1]);
				$msg_explode[1] = $msg_explode[1]." hat kein Profil angelegt. /pn";
			}
		}
	}


	// alle Profile auflisten (nur Admin):
	if (strpos($msg_explode[1],"/showprofil") && $admintrue !== false) {
		$zeile = "<b> Alle User mit Profil:</b>:br:";

		natcasesort($prof_array);
		$prof_array = array_values($prof_array);

		// jpg und gif nicht zeigen:
		for($i=0;$i<count($prof_array);$i++) {
			if (strpos($prof_array[$i],"jpg") === false && strpos($prof_array[$i],"gif") === false) {

				$prof_link = "<a href=\"#\" onclick=\"ads('/profil ".$prof_array[$i]."'); return false; \">".$prof_array[$i]."</a><br>  ";
				$all_prof = $all_prof.$prof_link;
			}
		}

		$msg_explode[1] = $zeile.$all_prof.' /pn';
	}

	// alle Videos auflisten (nur Admin):
	if (strpos($msg_explode[1],"/showvideo") && ($admintrue !== false || $vidallow = "alle")) {
		  
		$vid_array[] = "";
		$dir6 = 'upload/';
		if ($handle = opendir($dir6)) {
			// $profil_kz = '';
			// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
			while (false !== ($file = readdir($handle))) {

				if($file != "."
					&& $file != ".."
						&& $file != ".htaccess"
				){
					$vid_array[] = $file;
				}
			}
		}


		$zeile = "<b> Alle Videos:</b><br>";

		for($i=0;$i<count($vid_array);$i++) {
			if (strpos($vid_array[$i],"mp4") !== false || strpos($vid_array[$i],"m4v") !== false || strpos($vid_array[$i],"mov") !== false || strpos($vid_array[$i],"MOV") !== false) { $vid_link .= "<a href=\"upload\/$vid_array[$i]\" onclick=\"ads('upload\/".$vid_array[$i]."'); return false; \">".$vid_array[$i]."</a><br>  ";}
		}
		$msg_explode[1] = $zeile.$vid_link.' /pn';
	}


  // if (strpos($msg_explode[1],"/kick ")) {
  // 	  $kicked = true;
  // } else {
  // 	  $kicked = false;
  // }


	 // // /kick user x -> /ban user x /erase user
	 // if (strpos($msg_explode[1],"/kick ") && ($admintrue !== false || $modtrue !== false)) {
	 // 		 $to_kick = explode("/kick ",$msg_explode[1]);
	 // 		 $kick = explode(" ",trim($to_kick[1]));
	 // 		 $del_user = str_replace('@','',$kick[0]);
	 //
	 // 		 // $msg_explode[1] = ' /kick '.$kick[0].' '.$kick[1].' /erase '.$del_user.':';
	 // 		 $msg_explode[1] = $kick[0]." you've been kicked";
	 // }
	 
	 
	//
	// // /maul user x -> /maulkorb user x /erase user
	// if (strpos($msg_explode[1],"/maul ") && ($admintrue !== false  || $modtrue !== false)) {
	// 	$to_kick = explode("/maul ",trim($msg_explode[1]));
	// 	$kick = explode(" ",trim($to_kick[1]));
	// 	$del_user = str_replace('@','',$kick[0]);
	//
	// 	$msg_explode[1] = ' /maulkorb '.$kick[0].' '.$kick[1].' /erase '.$del_user.':';
	// }

	// smileys löschen:
	// nur Admin darf das:
	if (strpos($msg_explode[1],"/del_smiley ") && (strpos($msg_explode[1],".gif ") || strpos($msg_explode[1],".png ") || strpos($msg_explode[1],".mp3 ") || strpos($msg_explode[1],".mp4 ")) && strpos($msg_explode[1],"/smiley") && $admintrue !== false) {
		$url = str_replace("/del_smiley "," ",$msg_explode[1]);

		$path = pathinfo($url);
		$datei = $path['basename'];
		$verz = explode('/', $path['dirname']);
		$verz = end($verz);
		$smil_datei = $verz.'/'.$datei;
		$smil_datei = trim($smil_datei);
				
		if (file_exists($smil_datei) === true) {
			if (unlink($smil_datei) === true ) {
				if (strpos($smil_datei,'.mp4') !== false ) {
					$msg_explode[1] = " Das Video wurde gelöscht. /pn";			
				} elseif (strpos($smil_datei,'.mp3') !== false ) {
						$msg_explode[1] = " Das Audio wurde gelöscht. /pn";			
				} else {
					$msg_explode[1] = " Das Smiley  <img src='$smil_datei' > wurde gelöscht. /pn";
				}
			} else {
				$msg_explode[1] = ' Das Smiley  konnte nicht gelöscht werden! /pn';
			}
		} else {
			$msg_explode[1] = ' Das Smiley ist nicht vorhanden! /pn';
		}

	}

	function add_smiley($a,$b) {
	
		$file_to_copy = trim($a);
		

		if (strpos($file_to_copy,'.mp4') !== false || strpos($file_to_copy,'.mp3') !== false ) {
			$fp = fopen($file_to_copy,"r");
			while(!feof($fp)) {
				$contents .= fread ($fp, 1000);
			}
			$filename = 'smileys'.$b.'/'.basename($file_to_copy);
			if (!$handle = fopen($filename, "w+")) {$a = " Kann die Datei nicht &ouml;ffnen";}
			if (!fwrite($handle, $contents)) {$a = " Kann in die Datei  nicht schreiben";}
			$a = " Fertig, Audio/Video wurde eingef&uuml;gt.";

			fclose($handle);
			fclose($fp);

		} else {

			// testen ob gif oder png:
			$istBild= getimagesize($file_to_copy);
			if ($istBild) {
				if ($istBild[2] == 1 || $istBild[2] == 3 ) {
					$fp = fopen($file_to_copy,"r");
					while(!feof($fp)) {
						$contents .= fread ($fp, 1000);
					}
					$filename = 'smileys'.$b.'/'.basename($file_to_copy);
					if (!$handle = fopen($filename, "w+")) {$a = " Kann die Datei $filename nicht &ouml;ffnen";}
					if (!fwrite($handle, $contents)) {$a = " Kann in die Datei $filename nicht schreiben";}
					$a = " Fertig, <img src='$filename'> wurde eingef&uuml;gt.";

					fclose($handle);
					fclose($fp);

				} else {
					$a = " Grafikdatei existiert nicht, oder ist kein .gif bzw. .png und kann nicht eingef&uuml;gt werden.";
				}
			} else {
				$a = " Kein unterstütztes Dateiformat? (Erlaubt: gif, png, mp3 und mp4. Vielleicht fehlt auch nur http://)";
			}
		}
		$a = $a." /pn";	// /add wird immer /pn, und damit nur fuer den Admin sichtbar
		return $a;
	}



	// smileys in den Ordner smileys1, smileys2 usw. kopieren:
	if (!isset($smiley_dirs)) {$smiley_dirs = array('Smileys 1');}
	for($i = 1; $i <= count($smiley_dirs); $i++){
		if (strpos($msg_explode[1],"/add".$i." ") && $admintrue !== false) {
			$msg_explode[1] = str_replace("/add".$i." "," ",$msg_explode[1]);
			$msg_explode[1] = add_smiley($msg_explode[1],$i);
		}
	}


	if (trim($msg_explode[1]) == "" && $admintrue === false) exit();  // verhindert den Nickwechsel ohne Meldung


	// Die Zeilenloeschfunktion fuer den Admin - Achtung! sehr maechtig:
	if (strpos($msg_explode[1],"/erase ") !== false && ($admintrue !== false || $modtrue !== false)) {
		$del_line = explode("/erase ",$msg_explode[1]);
		$weg = trim($del_line[1]);
		$weg = str_replace('@','',$weg);
		if (strlen($weg) >= 2) { // einen Buchstaben nicht zulassen
			$zu_aendernder_array = file($room);
			$geaenderter = array();

			foreach($zu_aendernder_array as $zeile) {
				// der User sieht die Loeschung seiner Nachricht fuer die Dauer einer /pn
				//$pos3 = false;
				$pos3 = strpos($zeile,'<span class="ip">');
				if ($pos3 !== false) {
					$zeile2 = substr($zeile,0,$pos3)."</p>\n";
					$zeile2 = str_replace('</span>  </p>','</span></p>', $zeile2);							
					$zeile2 = str_replace('</span> </p>','</span></p>', $zeile2);							
					$msg_del = str_replace ('</span></p>',' <span style="display:none"> /pn </span><span style="color:red !important"> [message deleted]</span></span></p>', $zeile2 );
				} else {
					$zeile = str_replace('</span>  </p>','</span></p>', $zeile);							
					$zeile = str_replace('</span> </p>','</span></p>', $zeile);							
					$msg_del = str_replace ('</span></p>',' <span style="display:none"> /pn </span><span style="color:red !important"> [message deleted]</span></span></p>', $zeile );
				}
	
				if (strpos($zeile,$weg) === false) {
					array_push($geaenderter,$zeile);
				} else {
					array_push($geaenderter,$msg_del);	
				}
			}

			$datei_handle = fopen($room,'w');
			$fertisch = implode("",$geaenderter);
			flock($datei_handle,LOCK_EX);
			fwrite($datei_handle,$fertisch);
			fflush($datei_handle);
			flock($datei_handle,LOCK_UN);
			fclose($datei_handle);
		}
	}



	// immer nur ein mp3 anzeigen - Ausnahme smileys-Ordner
	if (isset($gema) && $gema === true) {
		if (strpos($msg_explode[1],".mp3 ") && strpos($msg_explode[1],"/upload/")) {
			$zu_aendernder_array = file($room);
			$geaenderter = array();

			foreach($zu_aendernder_array as $zeile) {
				if (strpos($zeile,"playmp3") === false || strpos($zeile,"smileys/")) {
					array_push($geaenderter,$zeile);
				}
			}

			$datei_handle = fopen($room,'w');
			$fertisch = implode("",$geaenderter);
			flock($datei_handle,LOCK_EX);
			fwrite($datei_handle,$fertisch);
			fflush($datei_handle);
			flock($datei_handle,LOCK_UN);
			fclose($datei_handle);
		}
	}



	// Mod approve:
	if (file_exists("mod_approve.php")) {
		include("mod_approve.php");
	}


	// Topic setzen:
	if(strpos($msg_explode[1],"/topic") !== false && $admintrue !== false) {
		if (strpos(strtolower($wo),"_pr") !== false) {
			$msg_explode[1] = '/pn '._NOTOPIC;
		} else {

			$topicfile = 'topics/'.$wo.'_topic.txt';
			$topic = str_replace("/topic","",$msg_explode[1]);
			$topic = nl2br($topic);
			

			if (isset($topic_scroll) && $topic_scroll >=1 && trim($topic) != "") {
				// $topic = '<marquee  onMouseover="this.stop()" onmouseout="this.start()" scrollamount="'.$topic_scroll.'" scrolldelay="20">'.$topic.'</marquee>';
				$topic = '<span class="marquee"><span>'.$topic.'</span></span>';
			}

			if (strpos($msg_explode[1],"/topicscroll") !== false)  { // topicscroll setzt Topic ohne config
				$topic = str_replace("scroll","",$topic);
				// $topic = '<marquee  onMouseover="this.stop()" onmouseout="this.start()" scrollamount="3" scrolldelay="20">'.$topic.'</marquee>';
				$topic = '<span class="marquee" id="topicscroll"><span>'.$topic.'</span></span>';
				
			}

			
			//       		   	$msg_explode[1] = str_replace("/topic","/pn Topic gesetzt: ",$msg_explode[1]);
			$msg_explode[1] = "/pn Topic gesetzt";
		 	
			$t = fopen($topicfile, "w");
			fwrite($t, $topic);
			fclose($t);
		}
	}



	// Chat offline schalten:
	if (strpos($msg_explode[1],"/offline ") && $admintrue !== false) {
		$open3 = fopen("rooms/Offline", "w");
		fwrite($open3,"");
		fclose($open3);
	}

	// Fotos verpixeln:
	if (strpos($msg_explode[1],"/pixelon ") && $admintrue !== false) { 
		if (is_file("_jmstv.php") === true && is_file("jmstv.php") !== true) {
			rename("_jmstv.php","jmstv.php");
		}
		if (is_file("upload/_htaccess") === true && is_file("upload/.htaccess") !== true) {
			rename("upload/_htaccess","upload/.htaccess");
		}
		if (is_file("tn_upload/_htaccess") === true && is_file("tn_upload/.htaccess") !== true) {
			rename("tn_upload/_htaccess","tn_upload/.htaccess");
		}
	}
	
	// Fotos unverpixeln:
	if (strpos($msg_explode[1],"/pixeloff ") && $admintrue !== false) { 
		if (is_file("jmstv.php") === true && is_file("_jmstv.php") !== true) {
			rename("jmstv.php","_jmstv.php");
		}
		if (is_file("upload/.htaccess") === true && is_file("upload/_htaccess") !== true) {
			rename("upload/.htaccess","upload/_htaccess");
		}
		if (is_file("tn_upload/.htaccess") === true && is_file("tn_upload/_htaccess") !== true) {
			rename("tn_upload/.htaccess","tn_upload/_htaccess");
		}
	}

	// Chat zeitabhaengig offline:
	if (isset($ab_offen) && isset($bis_offen)) {
		$uhrzeit = date("H:i");

		if ($ab_offen < $bis_offen) {
			if ($uhrzeit < $ab_offen || $uhrzeit >= $bis_offen) {
				//               $msg_explode[1] = "/pn Der Chat ist nur zwischen $ab_offen Uhr und $bis_offen Uhr ge&ouml;ffnet.";
				$msg_explode[1] = "/pn "._CLOSED." $ab_offen - $bis_offen";
				//exit();
			}
		} else {    
			if ($uhrzeit < $ab_offen && $uhrzeit >= $bis_offen) {
				//               $msg_explode[1] = "/pn Der Chat ist zwischen $ab_offen Uhr und $bis_offen Uhr ge&ouml;ffnet.";
				$msg_explode[1] = "/pn "._CLOSED." $ab_offen - $bis_offen";
				//exit();
			}
		}
	}



	$msg_explode[0] = str_replace("*","",$msg_explode[0]); // weil sonst ban etc. nicht geht


	if (file_exists("bannen_inc.php")) include("bannen_inc.php");


	// ban etc. immer fluestern:
	if (strpos($msg_explode[1],"/ban ") !== false
		|| strpos($msg_explode[1],"/ignore ") !== false
		|| strpos($msg_explode[1],"/show ") !== false
		|| strpos($msg_explode[1],"/maulkorb ") !== false
		|| strpos($msg_explode[1],"/offline ") !== false
		|| strpos($msg_explode[1],"/pixelon ") !== false
		|| strpos($msg_explode[1],"/pixeloff ") !== false
	) {
		$msg_explode[1] = str_replace("@","",$msg_explode[1]); // wg Eingabe per Mausklick
		$msg_explode[1] = $msg_explode[1]." /pn";
	}


	// /ghost aufheben, sobald der Admin was schreibt:
	if ($watch !== false && $admintrue !== false
		&& strpos(strtolower($msg_explode[1]),"/pn") === false
		&& strpos(strtolower($msg_explode[1]),"/approve") === false
		&& strpos(strtolower($msg_explode[1]),"/stop") === false
		&& strpos(strtolower($msg_explode[1]),"/go") === false
		&& strpos(strtolower($msg_explode[1]),"/peep") === false
		&& strpos(strtolower($msg_explode[1]),"/nopeep") === false
		&& strpos(strtolower($msg_explode[1]),"/ip") === false
		&& strpos(strtolower($msg_explode[1]),"/noip") === false
		&& strpos(strtolower($msg_explode[1]),"/erase") === false
		&& strpos(strtolower($msg_explode[1]),"/profil") === false
		&& strpos(strtolower($msg_explode[1]),"/showprofil") === false
		&& strpos(strtolower($msg_explode[1]),"/clear") === false
	) {
		setcookie("watch", "");
	}


	// if (strpos($msg,"/noanim") || strpos($msg,"/reanim")) { $msg_explode[1] = "";}


	// // cookie setzen fuer /stop:
	// if (stripos($msg_explode[1],'/stop ') !== false) {
	// 	setcookie("stop", "stop");
	// 	$msg_explode[1] = '';
	// }

	//  /go nicht anzeigen:
	if (strpos($msg_explode[1],'/go ') !== false) {
		$msg_explode[1] = '';
	}


	// cookie setzen fuer /ghost:
	if (stripos($msg_explode[1],'/ghost') !== false && $admintrue !== false) {
		setcookie("watch", "on", $Gueltigkeit);
		$msg_explode[1] = preg_replace('/\/ghost/i','', $msg_explode[1]);
	}

	// cookie setzen fuer /peep:
	if (stripos($msg_explode[1],'/peep') !== false && $admintrue !== false) {
		setcookie("listen", "on");
		$msg_explode[1] = preg_replace('/\/peep/i','', $msg_explode[1]);
	}

	// cookie /peep loeschen:
	if (stripos($msg_explode[1],'/nopeep') !== false) {
		setcookie("listen", "");
		$msg_explode[1] = preg_replace('/\/nopeep/i','', $msg_explode[1]);
	}

	// cookie setzen fuer /ip:
	if (strpos($msg_explode[1],'/ip') !== false && $admintrue !== false) {
		$msg_explode[1] = preg_replace('/\/ip/','', $msg_explode[1]);
	}

	// cookie /ip loeschen:
	if (strpos($msg_explode[1],'/noip') !== false) {
		$msg_explode[1] = preg_replace('/\/noip/','', $msg_explode[1]);
	}

	// /alarm nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/alarm ") !== false ) {
		$msg_explode[1] = str_replace("/alarm ","<span style='display:none'>/alarm</span> "._WAKEUP." ",$msg_explode[1]);
	}

	// /browser -> info:
	if (strpos(strtolower($msg_explode[1]),"/browser ") !== false ) {
		$msg_explode[1] = str_replace("/browser",$_SERVER["HTTP_USER_AGENT"],$msg_explode[1]);
	}

	// /approve nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/approve") !== false && $admintrue !== false) {  // Besucher sieht Fehlermeldung
		$msg_explode[1] = "";
	}
	// /erase nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/erase") !== false

	// das folgende darf nicht sein, weil sonst wiederholtes /kick und /maul nicht geht
	&& strpos(strtolower($msg_explode[1]),"/ban") === false
		&& strpos(strtolower($msg_explode[1]),"/maulkorb") === false
	&& ($admintrue !== false || $modtrue !== false)) {  // Besucher sieht Fehlermeldung
		$msg_explode[1] = "";
	}



	// cookie setzen fuer /ignore:
	if (strpos($msg_explode[1],'/ignore') !== false) {

		$d = $msg_explode[1];
		$d = str_replace("/ignore","",$d);
		$d = str_replace("/pn","",$d);
		$d = trim($d);

		if (isset($ignore)) {
			$d = $ignore."----".$d;
			setcookie("ignore", $d, $Gueltigkeit);
		} else {
			setcookie("ignore", $d, $Gueltigkeit);
		}
		$msg_explode[1] = '';

	}


	// /ignore wird aufgehoben durch /show (Loeschen des cookie):
	if (strpos($msg_explode[1],'/show') !== false) {
		setcookie("ignore", "");
		$msg_explode[1] = '';
	}


	// Fluestern formatieren:
	if (strpos(strtolower($msg_explode[1]),'/pm') !== false) {
		$msg_explode[1] = str_replace('/pm','/pn', $msg_explode[1]);
	}

	// in moderierten Raeumen darf nur der Admin fluestern: -> besser waere evtl.: $user_whisper
	if ($admintrue !== true && in_array($wo, $mod_rooms) !== false && strpos(strtolower($msg_explode[1]),'/pn') !== false) {
		$msg_explode[1] = str_replace('/pn','', $msg_explode[1]);
	}

	if (strpos(strtolower($msg_explode[1]),'/pn') !== false) {

		$msg_explode[1] = str_replace('/pn',' <span style="display:none">/pn</span>', $msg_explode[1]);
		$msg_explode[1] = str_replace('/PN',' <span style="display:none">/pn</span>', $msg_explode[1]);

		$suchmuster = '/ @\S+ /';
		preg_match($suchmuster, $msg_explode[1], $treffer);
		$an = rtrim(str_replace("@",_TO,$treffer[0]));

		$msg_explode[1] = " <span style=\"font-style:italic;\">("._WHISPER."$an)</span>".$msg_explode[1];
		$msg_explode[1] = preg_replace('/( @\S+ )/',' <span style="display:none">$1</span>', $msg_explode[1]);
	}

	$remote = $own_ip;
	// generate unique-ish color for IP
	if (!isset($usercolor)) {$usercolor = "auto";}
	if ($usercolor=="auto") {
		$color = colorify_ip($remote);
	} else {
		if (isset($setcolor)) {$color = $setcolor;}
	}

	// eigene Farbe fuer nick waehlen und in cookie speichern:
	if (strpos($msg_explode[1],'/color #') !== false) {
		// das letzte Vorkommen von /color waehlen: nur ab PHP5!
		// deshalb eigene function: http://www.homepage-forum.de/showthread.php?p=156334
		$lastpos = strripos($msg_explode[1],'/color #');
		$last = substr($msg_explode[1],$lastpos);
		$d = explode('/color #',$last,2);
		$d = substr($d[1],0,6);

		// weisser Adler auf weissem Grund vermeiden:
		$d = str_replace("D","C",$d);
		$d = str_replace("d","c",$d);
		$d = str_replace("E","C",$d);
		$d = str_replace("e","c",$d);
		$d = str_replace("F","C",$d);
		$d = str_replace("f","c",$d);

		// Negerboxkampf im Tunnel vermeiden:
		$d = str_replace("2","3",$d);
		$d = str_replace("1","3",$d);
		$d = str_replace("0","3",$d);

		setcookie("color", $d, $Gueltigkeit);
		$color = $d;
	}

	// Farbwechsel verstecken:
	if (strpos($msg_explode[1],'/color') !== false) {
		$msg_explode[1] = preg_replace('/\/color #\S+\s/','', $msg_explode[1]);
	}

	// leeren nick und leere msg nicht zulassen:
	if(trim($msg_explode[0])=="" || trim($msg_explode[1])=="" ) exit();

	$youtube="";

	if (strpos($msg_explode[1],'https://www.youtube') !== false) {
		$youtube = trim(str_replace('https://','http://', $msg_explode[1]));
	}


	// YouTube1:
	if (strpos($msg_explode[1],'/youtube ') !== false) {
		$youtube = trim(str_replace('/youtube ','', $msg_explode[1]));
	}

	// YouTube2:
	elseif (strpos($msg_explode[1],'https://youtu.be/') !== false) {
		$youtube = trim(str_replace('https://youtu.be/','', $msg_explode[1]));
	}
	elseif (strpos($msg_explode[1],'http://youtu.be/') !== false) {
		$youtube = trim(str_replace('http://youtu.be/','', $msg_explode[1]));
	}

	// YouTube6:
	elseif (strpos($msg_explode[1],'http://www.youtube.com/') !== false && strpos($msg_explode[1],'v=') !== false) {
		$youtube = $msg_explode[1];
	} 

	// YouTube7:
	elseif (strpos($msg_explode[1],'http://m.youtube.com/') !== false && strpos($msg_explode[1],'v=') !== false) {
		$youtube = $msg_explode[1];
	} 



	if (strpos($msg_explode[1],'youtube') !== false || strpos($msg_explode[1],'http://youtu.be/') !== false) {

		if (strpos($youtube,'v=') !== false) {
			$ytstart = strpos($youtube,'v=') +2;
		} else {
			$ytstart = 0;
		}
		$youtube = trim(substr($youtube,$ytstart));		


		if (strpos($youtube,'&') !== false) {
			$ytende = strpos($youtube,'&');
			$youtube = substr($youtube,0,$ytende);
		} 


	}

	

	// Wenn Link mit Startzeit übergeben wird :
	if (strpos($youtube,'?') !== false) {
		$ytende = strpos($youtube,'?');
		$youtube_pv = substr($youtube,0,$ytende);
	} elseif (strpos($youtube,'&t=') !== false) {
		$ytende = strpos($youtube,'&t=');
		$youtube_pv = substr($youtube,0,$ytende);
	} else {
		$youtube_pv = $youtube;
	}

	$youtube_embed = $youtube;
	$youtube_watch = $youtube;
	if (strpos($youtube,'?t=') !== false) {
		$youtube_watch = str_replace('?t=','&amp;t=',$youtube);

		$parts = explode ('?t=',$youtube);

		if (strpos($youtube,'m') !== false) {
			$timeparts = explode ('m',$parts[1]);

			$sec = $timeparts[1];
			$secdec = substr($sec,0,-1);

			$min_to_sec = $timeparts[0] * 60 + $secdec;

			$youtube_embed = $parts[0].'?start='.$min_to_sec;

		} else {
			$youtube_embed = str_replace('?t=','?start=',$youtube);
			$youtube_embed = substr($youtube_embed, 0, -1);			
		}	

	}




	if ($youtube != '') {
		if (strpos($youtube,' ') !== false) {
			$msg_explode[1] = 'yt_error';
		} elseif ($links!="yes" && strpos($room,"_pr") === false && $admintrue !== true ) {
			$msg_explode[1] = ' YouTube Links nicht erlaubt';
		} else {
			$msg_explode[1] = '<a style ="text-decoration:none; color:red;" href="https://www.youtube-nocookie.com/embed/'.$youtube_embed.'" onclick="YTPop(this.href); return false"> <img class="ytpreview" src="https://i1.ytimg.com/vi/'.$youtube_pv.'/mqdefault.jpg" alt="YouTube Video extern" title="YouTube Video im Popup oeffnen" /></a><a style ="text-decoration:none;" href="https://www.youtube-nocookie.com/embed/'.$youtube_embed.'" target="_blank" title="YouTube Video öffnet in neuem Tab/Fenster"> <span class="yta">You</span><span class="ytb">Tube</span></a>';

		}
	}

	// mp3s (eleganter waer das im linker):
	elseif (strpos($msg_explode[1],'.mp3') !== false && strpos($msg_explode[1],'http') !== false) {

		$msg_explode[1] = str_replace(".mp3",".mp3 ",$msg_explode[1]);

		if (strpos($msg_explode[1],'http://') !== false) {
			$start = strpos($msg_explode[1],"http://");
		} elseif (strpos($msg_explode[1],'https://') !== false) {
			$start = strpos($msg_explode[1],"https://");
		} 
		$teil = substr($msg_explode[1],$start);
		$laenge = strpos($teil,"mp3 ")+3;
		$multimedia = trim(substr($teil,0,$laenge));

		$multimedia_title = str_replace('http',' http',$multimedia);

		$multimedia_title = str_replace('.mp3','',$multimedia);
		$multimedia_title = str_replace('_',' ',$multimedia_title);
		$multimedia_title = str_replace('.','',$multimedia_title);
		$multimedia_title = str_replace(';stream','Radiostream',$multimedia_title);

		$rest = str_replace($multimedia,"",$msg_explode[1]);
    
		// abs. Pfad in  relativen Pfadeumwandeln, wg. allow_url_fopen
		// $abs_path = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF'])."/";
		$multimedia = str_replace($abs_path,"",$multimedia);
	
	

		if ( isset($show_player) && $show_player === true) {
			// so wird das Linkziel im Browser nicht angezeigt:
			if (strpos($room,'_pr') !== false) { // in _pr keine mp3-Logs schreiben
				$msg_explode[1] = ' <dfn>Play: </dfn><a class="mp3" href="" onclick="playmp3olog_mit_http(\''.$multimedia.'\');return false;" oncontextmenu="return false;" >'.basename($multimedia_title).'</a> ';
			} else {
				$msg_explode[1] = ' <dfn>Play: </dfn><a class="mp3" href="" onclick="playmp3_mit_http(\''.$multimedia.'\');return false;" oncontextmenu="return false;" >'.basename($multimedia_title).'</a> ';
		
			}					
		}
		// <a class="stop" href=" " onclick="playmp3leer();return false;">Close&nbsp;Player</a>


	} else {
		// automatisch Links erzeugen:
		$msg_explode[1] = linker($msg_explode[1]);
	}


	/* ein bisschen bbcode */
	if(strpos($msg_explode[1],"[b]") !== false && strpos($msg_explode[1],"[/b]") !== false){  
		$msg_explode[1] = str_replace('[b]','<b>',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/b]','</b>',$msg_explode[1]);
	}

	if(strpos($msg_explode[1],"[i]") !== false && strpos($msg_explode[1],"[/i]") !== false){  
		$msg_explode[1] = str_replace('[i]','<i>',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/i]','</i>',$msg_explode[1]);
	}

	if(strpos($msg_explode[1],"[blink]") !== false && strpos($msg_explode[1],"[/blink]") !== false){  
		$msg_explode[1] = str_replace('[blink]','<span class="blink">',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/blink]','</span>',$msg_explode[1]);
	}

	if(strpos($msg_explode[1],"[color=") !== false && strpos($msg_explode[1],"[/color]") !== false){  
		$msg_explode[1] = str_replace('[color=','<span style="color:',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/color]','</span>',$msg_explode[1]);
		$msg_explode[1] = str_replace(']','">',$msg_explode[1]);
	}



	// Videos einbinden	
	if(stristr($msg_explode[1], '.mp4') !== false || stristr($msg_explode[1], '.m4v') !== false || stristr($msg_explode[1], '.MOV') !== false) {

		$msg_explode[1] = str_replace(".mp4",".mp4 ",$msg_explode[1]);
		$msg_explode[1] = str_replace("http"," http",$msg_explode[1]);

		if(strpos($msg_explode[1], 'upload/') !== false || strpos($msg_explode[1], 'smileys') !== false ) { 
			if(strpos($msg_explode[1], 'upload/') !== false) {
				$pos2 = strrpos($msg_explode[1],'upload/');
				$temp2 = substr($msg_explode[1],$pos2);
				$temp3 = str_replace('</a> ','',$temp2);
				$teile1 = explode('" rel=', $temp3);
				$temp4 = $teile1[0];


			} elseif (strpos($msg_explode[1], 'smileys') !== false ){
				$pos2 = strrpos($msg_explode[1],'smileys');
				$temp2 = substr($msg_explode[1],$pos2);
				$temp3 = str_replace('</a> ','',$temp2);
				
				if (strpos($temp3, '\/add') === false && strpos($temp3, '\/del_smiley') === false ){
					$teile1 = explode(' ', $temp3);
					$temp4 = $teile1[0];
				} else {
					$temp4 = $temp3;
				}
			}



			$msg_explode[1] = ' <video src="'.$temp4.'" type="video/mp4" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"  onmouseout="this.removeAttribute(\'controls\', true)" onfocus="this.setAttribute(\'controls\', true)" ></video>';
			
			
			
		} elseif ( preg_match("(http[^ ]+)", $msg_explode[1], $match) ) { // einen URL extrahieren
				$msg_explode[1] = ' <video src="'.$match[0].'" type="video/mp4" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"  onmouseout="this.removeAttribute(\'controls\', true)" onfocus="this.setAttribute(\'controls\', true)"></video>';
		}
		
	}


	// nur ein Joke: (schoener: http://rw47.eu/umdreher/)

	if(strpos($msg_explode[1],"/rev ") !== false){
		$msg_explode[1] = utf8_decode($msg_explode[1]);
		$msg_explode[1] = " ".strrev(str_replace("/rev ","",$msg_explode[1]));
		$msg_explode[1] = utf8_encode($msg_explode[1]);
	}


	// lange Woerter nach ... Zeichen umbrechen:
	//	macht jetzt CSS word-wrap $msg_explode[1] = textWrap($msg_explode[1]);

	if (file_exists("smiley_create.php")) include("smiley_create.php");

	// so liesse sich ein Anonymizer aufrufen:
	// darf nicht fuer Bilder aktiv sein, weil sonst thumbs nicht tut.
	if(isset($anonymizer) ) {

		$meinString = $msg_explode[1];
		$findMich   = '.jpg';
		$findMich2   = '.gif';
		$findMich3   = '.png';

		$pos = strpos($meinString, $findMich);
		$pos2 = strpos($meinString, $findMich2);
		$pos3 = strpos($meinString, $findMich3);

		if ($pos === false && $pos2 === false && $pos3 === false) {
			$msg_explode[1] = str_replace('http://','http://'.$anonymizer.'http://',$msg_explode[1]);
			$msg_explode[1] = str_replace('>http://'.$anonymizer.'','>',$msg_explode[1]);
		}
	}




	// und jetzt noch die Zeile des Admin farbig hinterlegen:
	$highlight="";
	if(($admintrue !== false || $modtrue !== false) && $superadmintrue !== true) {
		$highlight = " class = \"bg\" ";
		// wenn du die Farbe fuer den Admin unabhaengig von cookies festschreiben willst
		// dann folgende Zeile entkommentieren und Hexcode waehlen:
		// $color ="FF0000";
	}

	// erst wenn Farbe gewaehlt und cookie gesetzt, msg einfaerben
	$msg_explode[1] = "<span style=\"color:#$color\">$msg_explode[1]</span>";


	if ($admintrue === false && $modtrue === false ) {
		if (strpos(strtolower($msg_explode[1]),"/erase ") !== false) {
			$msg_explode[1] = ' <span style="display:none">/pn @'.$nickname.' </span>'._ERASE;
		}
	}
		
		
	if ($admintrue === false ) {
		if (strpos(strtolower($msg_explode[1]),"/approve ") !== false) {
			$msg_explode[1] = ' <span style="display:none">/pn @'.$nickname.' </span>'._SORRY._APPROVE;
		}
	}


	if (isset($shoutbox) && $shoutbox !== false) {      // von der shoutbox geschickte msg kennzeichnen:
		$msg_explode[1] = $msg_explode[1].'<span style = "font-size:75%">(sb)</span></span>';
	}



	// Moderation on: 
	if ($mod == "all" || in_array($wo, $mod_rooms) !== false) {

		if ($admintrue === false ) {
			$msg_explode[1] = str_replace ('/me','',$msg_explode[1]);
			$msg_explode[1] = $msg_explode[1].' <span onclick="ads(\'/approve '.$uhr0.'\'); return false;"  style="color:red !important; cursor:pointer">(await mod)</span>';
		}
	}



	if (isset($ip_write) && $ip_write === true && $admintrue !== true) {
		if (file_exists('ip_inc.php')) {
			include ('ip_inc.php');
		} else {
			$msg_explode[1] .= ' <span class="ip">'.$own_ip.'</span>';
		}
	}



	// @nickname nur, wenn nickname schon bekannt:
	// Anm.: Leerschritt vor pointer wg. ARIA i.V.m. (await mod)
	if ($nickname != "") {

		$nickname2 = "<span class=\"nk\" oncontextmenu=\"ads('/erase ".$uhr0."'); return false;\"   onclick=\"ads('\u0040".$nickname."'); return false; \"  title =\"$dt0 $uhr0\" style=\"color:#$color; cursor: pointer\">".implode(":</span>",$msg_explode);

		/* Avatar einbinden */
		if (!isset($av_height)) {$av_height = 32;}
		
		if(file_exists('profile/'.$nickname.'.gif')) {
			$msg = ' <span class="av_link"><a href="popprof.php?profil='.$nickname.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$nickname.' anschauen (Popup)"  > <img class="av" src="profile/'.$nickname.'.gif" onError="this.src=\'img/no_prof_img.png\';" alt="Profilbild" height="'.$av_height.'"></a></span> '.$nickname2;
			
		} elseif(file_exists('profile/'.$nickname.'.jpg')) {
			$msg = ' <span class="av_link"><a href="popprof.php?profil='.$nickname.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$nickname.' anschauen (Popup)"  > <img class="av" src="profile/'.$nickname.'.jpg" onError="this.src=\'img/no_prof_img.png\';" alt="Profilbild" height="'.$av_height.'"></a></span> '.$nickname2;
			
		} else {
			$msg = $nickname2;
		}		   

	} else {
		$msg = "<span class=\"nk\" oncontextmenu=\"ads('/erase ".$uhr0."'); return false;\"   title =\"$dt0 $uhr0\" style=\"color:#$color; cursor: pointer\">".implode(":</span>",$msg_explode);
	}


	// folgende Zeile anstelle der oberen legt Fluestern statt Loeschen auf die rechte Maustaste:
	// zusaetzlich noch die if-Abfrage nach $nickname einbauen
	//        $msg = "<span class=\"nk\" oncontextmenu=\"ads('\u002fpn \u0040".$nickname."'); return false;\"   onclick=\"ads('\u0040".$nickname."'); return false; \"  title =\"$dt0 $uhr0\" style=\"color:#$color; cursor: pointer\">".implode(":</span>",$msg_explode);


	if (file_exists("badwords.txt") && $admintrue !== true) {
		$badwords = file("badwords.txt");
		foreach ($badwords as $b) {
			if (strpos($msg,"http://") !== false && strpos($msg,trim($b)) !== false) {
				$msg = str_ireplace(rtrim($b), "".substr($b,0,0)."example.com", $msg);
				$msg = $msg.'<span  style="display:none">/pn @'.$nickname.' </span>';
			}
			$b = " ".$b;
			$msg = str_ireplace(rtrim($b), " ".substr($b,1,1)."***", $msg);
		}
	}


	// Eine einfache flooding Sperre:
	
	
	if (strpos($msg,"away.gif") === false) {
	
	if ($flood > 0 && $admintrue === false) {         // $flood = 0; in der config schaltet die Sperre aus.

		$fl = "user/flood.txt";
		$vgl = file_get_contents($fl);
		$teil = explode("+++", $vgl);
		$pruef = $msg_explode[0].'+++'.trim($msg_explode[1]).'+++'.time();

		// // away nur alle 120 Sek. schreiben
		// if(($teil[0] == $msg_explode[0] && (time()-$teil[2]) < 120)
		// 	&& strpos($teil[1],'ist jetzt mal <abbr title =" away from keyboard"') !== false
		// && strpos($msg,'ist jetzt mal') !== false) {
		// 	exit();
		// }


		if(($teil[0] == $msg_explode[0] && (time()-$teil[2]) < ($flood / 4))
			|| ($teil[0] == $msg_explode[0] && $teil[1] == trim($msg_explode[1]) && (time()-$teil[2]) < $flood)
		) {

			$ff = fopen($fl, "w+");
			fwrite($ff, $pruef);
			fclose($ff);

			$nickban = $nickname;

			// if (!isset($bantime)) {$bantime=3;}
			// $bantime = time() + 60*$bantime;
			// nur noch 10 sec für flooding
			$bantime = time() + 15;

			$roomid = str_replace("rooms/","_",$room);
			$ipfile = 'user/ip'.$roomid.'.txt';

			$lines = file($ipfile);
			$ipparts = "";
			foreach ($lines as $line_num => $line) {
				if (strpos($line,$nickban) !== false) {
					$ipparts = explode("****", $line);
					$banip = $ipparts[0];
				}
			}

			$banstrg = $nickban."****".$bantime."++++".$banip."\n";

			$banned = "user/maulkorb.txt";
			$fb = fopen($banned, "a+");
			fwrite($fb, $banstrg);
			fclose($fb);


			$msg = '<span style="display:none">/pn @'.$nickname.' vom Chatbot: </span>'._HELLO.$nickname._FLOOD.'</span>';
		}

		$ff = fopen($fl, "w+");
		fwrite($ff, $pruef);
		fclose($ff);
	}
	}

	if (strpos($msg,"yt_error") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._YTERROR.'</span>';

	if (strpos($msg," /nick") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._NICKIRC.'</span>';
	if (strpos($msg," /name") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._NICKIRC.'</span>';
	if (strpos($msg," /who") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._WHOIRC.'</span>';
	if (strpos($msg," /msg") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._MSGIRC.'</span>';

	if ((strpos($msg," /help") !== false) && ($admintrue !== false)) $msg = _HELPIRC.'</span>';
	if ((strpos($msg," /help") !== false) && ($admintrue === false)) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._HELPIRC.'</span>';

	if ((strpos($msg," /hilfe") !== false) && ($admintrue !== false)) $msg = _HELPIRC.'</span>';
	if ((strpos($msg," /hilfe") !== false) && ($admintrue === false)) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._HELPIRC.'</span>';


	if ((strpos($msg," /xprofil") !== false) ) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._XPROFIL.'</span>';


	if (strpos($msg," /list") !== false) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._LISTIRC.'</span>';
	if (strpos(strtolower($msg),"[img]") !== false) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._FORMIMG.'</span>';


	if(strpos($msg,"/me ") !== false  && strpos($msg,"/pn") === false) {
		$msg = str_replace(":</span","</span",$msg);
		$msg = str_replace("/me","",$msg);
	} elseif (strpos($msg,"/me ") !== false) {
		$msg = str_replace("/me","",$msg);
	} 


	if(strpos($msg,"/clear") !== false || strpos($msg," /archiv") !== false) {
		$msg = str_replace(":</span","</span",$msg);
		$msg = str_replace("/clear",_CLEAR,$msg);
		$msg = str_replace("/archiv",_CLEAR,$msg);
	}

	$msg = str_replace("\n","<br />",$msg);

	if(isset($user_whisperroom) && $user_whisperroom == "admin") {
		// nur Admin darf oeffentliche und private Raeume anlegen:
		if ($roomexists == "1" || $admintrue !== false) {

			$f = fopen($room, "a+");
			flock($f,LOCK_EX);
			fwrite($f, "<p$highlight>$dt $uhr<span class=\"tr\"> | </span>$msg</p>\n");
			fflush($f);
			flock($f,LOCK_UN);
			fclose($f);
		}
	} else {
		// nur Admin darf oeffentliche Raeume anlegen:
		if ($roomexists == "1" || strpos($room,"_pr") !== false || $admintrue !== false) {

			$f = fopen($room, "a+");
			flock($f,LOCK_EX);
			fwrite($f, "<p$highlight>$dt $uhr<span class=\"tr\"> | </span>$msg</p>\n");
			fflush($f);
			flock($f,LOCK_UN);
			fclose($f);
		}
	}
}


function refresh() {
	global  $room,
	$roomexists,
	$anz_msg,
	$nickname,
	$admintrue,
	$superadmintrue,
	$modtrue,
	$watch,
	$pnlivetime,
	$enter_livetime,
	$shoutbox,
	$new_lines,
	$guestread,
	$mod,
	$mod_rooms,
	$listen,
	$blankroom,
	$blankrooms,
	$sav_msg,
	$ignore,
	$closepr,
	$bis_offen,
	$ab_offen,
	//		$ip_write,
	$showip,
	$time_offset,
	$style,
	$own_ip,
	$wo,
	$interne,
	// $kicked,
	$display_reverse;

	
	$ignore0 = $ignore1 = $ignore2 = "&nbsp;";

	$wo = trim(substr($room,6));
	// $arrival = "";

	// arrival cookie beim ersten Betreten eines Raums setzen:
	// $woarrival = $wo.'arrival';
	// if (isset($_COOKIE[$woarrival])) $arrival = $_COOKIE[$woarrival];
	if (isset($_COOKIE['arrival'])) $arrival = $_COOKIE['arrival'];


	if (file_exists($room)) {
		$size = filesize($room);
		$maxsize = $sav_msg * 400; // hier etwas Sicherheitsabstand, damit das nicht zu frueh greift
		if ($size > $maxsize)    include_once("cleanup.php");
	}

	
	
	if (file_exists("user/ban.txt")) {
		$banned = file("user/ban.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);

			// Rest Banzeit:
			$nochraw = ($part2[0] - time()) / 60 + 1; 
			$nochstunden = floor($nochraw /60);
			$nochminuten = floor(($nochraw - $nochstunden*60)) ;
			if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
			$noch = ' '.$nochstunden.':'.$nochminuten.'&nbsp;h';

			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  { 
					$new_lines = "<p>"._SORRY." ".$nickname._MUZZLED.$noch;
					return $new_lines;
					exit;
				}
			}
		}
	}

	// Chat offline:
	if ((file_exists("rooms/Offline")
		&& $room != "rooms/Info"
			&& $room != "rooms/Buglist"
				//        && $admintrue === false
	)
		&& (strpos($room,"_pr") === false
			|| (strpos($room,"_pr") !== false && $closepr != "no"))
				)
	{
		if (filesize("rooms/Offline") > 0) {
			$offline_content = file("rooms/Offline");
			$resultat = array_values($offline_content);
			foreach ($resultat as $element) {
				if (strpos($element,"deleted") === false) {
					$new_lines .= $element;
				}
			}

		} else {
			$new_lines = "<p><br />"._OFFLINE;
		}
		return $new_lines;
		exit();
	}

	if ($wo == "Intern") {
		if (!in_array($nickname,$interne) && $admintrue === false) {
			$new_lines = "<p><br />"._INTERN;
			return $new_lines;
			exit();
		}
	}



	// Chat zeitabhaengig offline:
	if (isset($ab_offen) && isset($bis_offen)) {
		$uhrzeit = date("H:i");

		if ($ab_offen < $bis_offen) {
			if ($uhrzeit < $ab_offen || $uhrzeit >= $bis_offen) {
				//               echo "<p>Der Chat ist nur zwischen $ab_offen Uhr und $bis_offen Uhr ge&ouml;ffnet.</p>";
				echo "<p> "._CLOSED." $ab_offen - $bis_offen </p>";

				exit();
			}
		} else {    
			if ($uhrzeit < $ab_offen && $uhrzeit >= $bis_offen) {
				//               echo "<p>Der Chat ist nur zwischen $ab_offen Uhr und $bis_offen Uhr ge&ouml;ffnet.</p>";
				echo "<p> "._CLOSED." $ab_offen - $bis_offen </p>";

				exit();
			}
		}
	}



	// if($roomexists === false) exit();


	// die letzten ... Eintraege:
	if (file_exists($room)) {

		$lines = file($room);
		$lines = array_slice($lines, -$anz_msg);

		if ((isset($display_reverse) && $display_reverse === true) || $style=="12") {$lines = array_reverse($lines);}
		$anz = count($lines);


		// /await mod nicht zeigen:
		if ($mod == "all" || in_array($wo, $mod_rooms) !== false) {

			$sender = "nickname";
			$sender_neu = "nickname";

			if (isset($nickname)) $sender_neu = $nickname.'":';
			if (isset($nickname)) $sender = $nickname.':';

			for($i = 0; $i < $anz; $i++){
				if (strpos(strtolower($lines[$i]),"(await mod)") !== false) {
					if ($admintrue !== false
						|| strpos($lines[$i],$sender) !== false  // Sender sieht eigene msg
							|| strpos($lines[$i],$sender_neu) !== false  // neuer Sender sieht eigene msg
					) {
						$new_lines2[$i] = $lines[$i]."\n";
					}
				} else {
					$new_lines2[$i] = $lines[$i]."\n";
				}
			}
		}
		if (isset($new_lines2)) {
			$lines = $new_lines2;
		}


		$privat = $nickname;

		$privat1 = "@".$privat." ";	// damit's der Empfaenger sieht
		$privat2 = ">".$privat.":"; 	// damit's der Sender sieht
		$privat3 = $privat.'":'; 	// damit's neu reingekommener Sender sieht

		$lines = @array_slice($lines, -$anz_msg);
		$anz2 = count($lines);

		for($i = 0; $i < $anz2; $i++){


			// Zeitstempel der msg ermitteln fuer $blankroom und fluestern:
			$lines1[$i] = str_replace(' class = "bg" ','',$lines[$i]);
			$year = date("Y");
			$month = substr($lines1[$i],23,2);
			$day = substr($lines1[$i],20,2);
			$hour = substr($lines1[$i],51,8);

			// damit beim Jahreswechsel blankroom auch funktioniert:
			$yearblank = $year;
			if ($month > date("n")) {
				$yearblank = $year - 1;
			}

			$pntime = $year.'-'.$month.'-'.$day.' '.$hour;
			$pntimeblank = $yearblank.'-'.$month.'-'.$day.' '.$hour;


			$msgtime = strtotime($pntime)-($time_offset*3600);
			$msgtimeblank = strtotime($pntimeblank)-($time_offset*3600);


			if (strpos($lines[$i],'class="ip"') !== false && $admintrue === false || $showip !== true) {
				$ip_pos = strpos($lines[$i],'class="ip">') -9;
				$lines[$i] = substr($lines[$i],0,$ip_pos).'</p>';
			}


			// Kein Popup fuer YouTube wenn mobile:
			if(file_exists("check_mobile.php")) {
				require_once('check_mobile.php');
				if(check_mobile()) {
					if (strpos($lines[$i],'watch_popup') !== false) {
						$lines[$i] = str_replace('watch_popup','watch',$lines[$i]);
					}
				}
			}

			// Hello usw. zeitgesteuert ausblenden:
			if(strpos($lines[$i],'class="hello"') !== false) {
				// $jetzt = strtotime("now");
				$jetzt = time();
			
				// if ($admintrue === true || $modtrue === true) {
					if (!isset($enter_livetime)) {$enter_livetime = 60 * 5;}
				// } else {
				// 	$enter_livetime = 60 * 60 * 2; // so wird hello angezeigt.
				// }
			
				if (($jetzt - $msgtime) < $enter_livetime && $jetzt - $msgtime >= 0 && strpos($lines[$i],"deleted") === false) // zweites gegen den Jahreswechselbug		
				{
					$new_lines[$i] = $lines[$i]."\n";
				}
			}

			elseif(strpos(strtolower($lines[$i]),"/pn") !== false
				|| (strpos($lines[$i],'cursor:pointer">(await mod') !== false && $admintrue!==true) /* Admin sieht await immer */
					|| strpos($lines[$i],"Achtung! diese Einladung") !== false
						|| strpos($lines[$i],"Warning! This invitation") !== false
							|| strpos($lines[$i],_DBLUSER) !== false
			) {


				$jetzt = strtotime("now");

				// Admin sieht auch pn:
				if ((strpos($lines[$i],$privat1) !== false
					|| strpos($lines[$i],$privat2) !== false
						|| strpos($lines[$i],$privat3) !== false
							|| ($listen === true && $admintrue===true && $watch !== true)
								|| ($listen === true && $superadmintrue===true)
								)
								&& $jetzt - $msgtime < $pnlivetime && $jetzt - $msgtime >= 0 // letzteres gegen den Jahreswechselbug
				) {
					// damit auch der Admin Gefluester ignoren kann:
					if (isset($ignore)) {
						$noshow = explode("----",$ignore);
						
						// max. 3 nicks koennen ignored werden:
						$ignore0 = $noshow[0];
						if (isset($noshow[1])) $ignore1 = $noshow[1];
						if (isset($noshow[2])) $ignore2 = $noshow[2];

						if(strpos($lines[$i],$ignore0) === false
							&& strpos($lines[$i],$ignore1) === false
								&& strpos($lines[$i],$ignore2) === false
						) {
							$new_lines[$i] = $lines[$i]."\n";
						}
					} else {
						$new_lines[$i] = $lines[$i]."\n";
					}
				}

				//  Anzeige doppelter user nur von Zeit abhaengig machen, nicht vom user, geht auch ohne cookies
				elseif(strpos($lines[$i],_DBLUSER) !== false && $jetzt - $msgtime < $pnlivetime && $jetzt - $msgtime > 0){
					$new_lines[$i] = $lines[$i]."\n";
				}

			} else {	// wenn nicht /pn
				// wenn ignore cookie gesetzt:
				if (isset($ignore)) {

					$noshow = explode("----",$ignore);
					// max. 3 nicks koennen ignored werden:
					// $ignore0 = $noshow[0].":";
					// if (isset($noshow[1])) $ignore1 = $noshow[1].":";
					// if (isset($noshow[2])) $ignore2 = $noshow[2].":";

					// ignore auch alle msg, die ignored enthalten:
					// max. 3 nicks koennen ignored werden:
					$ignore0 = $noshow[0];
					if (isset($noshow[1])) $ignore1 = $noshow[1];
					if (isset($noshow[2])) $ignore2 = $noshow[2];


					if(strpos($lines[$i],$ignore0) === false
						&& strpos($lines[$i],$ignore1) === false
							&& strpos($lines[$i],$ignore2) === false
					) {
						
						// wenn chat bei Ankunft leer sein soll:
						if ((isset ($blankrooms) && $blankrooms == "yes"  && $admintrue === false && $modtrue === false) || (isset($blankroom) && in_array($wo, $blankroom) !== false) && $admintrue === false && $modtrue === false) {
							if ($msgtimeblank > $arrival) {
								$new_lines[$i] = $lines[$i]."\n";
							}
						} else {
							$new_lines[$i] = $lines[$i]."\n";
						}
					}
				} else {
					// wenn chat bei Ankunft leer sein soll:
				
					// echo "$msgtimeblank <br> $arrival"; exit;
				
					if ((isset ($blankrooms) && $blankrooms == "yes"  && $admintrue === false && $modtrue === false) || (isset($blankroom) && in_array($wo, $blankroom) !== false) && $admintrue === false && $modtrue === false) {
						if ($msgtimeblank > $arrival) {
							$new_lines[$i] = $lines[$i]."\n";
						}
					} else {
						$new_lines[$i] = $lines[$i]."\n";
					}
				}
			} 

		}




		if (isset($new_lines)) {
		

			// (fluestert) ohne Adressaten generell nicht zeigen:
			$new_lines = str_replace ("(fl&uuml;stert)","",$new_lines);
			if ($nickname) {
				// mit @nickname Angesprochene sehen die Ansprache gehighlighted:
				//                      $new_lines = str_ireplace(trim($privat1),'<span style="font-weight:bold; color: #444; background-color: #ff6"> '.trim($privat1).'</span>',$new_lines);
				$new_lines = str_ireplace(trim($privat1),'<span class="at"> '.trim($privat1).'</span>',$new_lines);

				// Angefluesterte sehen die Ansprache gehighlighted:
				//                      $privat3 = str_replace("@",_TO,trim($privat1)).')'; // diese Ersetzung bereits in Zeile 1414
				$privat3 = str_replace("@"," ",trim($privat1)).')';
				//                      $new_lines = str_ireplace($privat3,'<span style="font-weight:bold; color: #444; background-color: #ff6"> '.trim($privat3).'</span>',$new_lines);
				$new_lines = str_ireplace($privat3,'<span class="whisper"> '.trim($privat3).'</span>',$new_lines);
			}

			return join("\n", $new_lines);
		}
	}
}

// filesize abfragen vor dem AJAX refresh des Inhalts:
function file_changed() {
	global  $room;
	if (file_exists($room)) {
		$size = filesize($room);
		return $size;
	}
}


$sajax_request_type = "POST";
sajax_init();
sajax_export("add_line", "refresh", "user_online", "user_room", "file_changed");
sajax_handle_client_request();

?>
