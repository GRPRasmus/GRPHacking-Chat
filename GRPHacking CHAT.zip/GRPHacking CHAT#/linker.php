<?php

// Variable f�r shortlink() setzen abh�ngig vom per cleanup.php erstellten file:
$is_fp = false;
if (file_exists("fp.txt") && file_get_contents("fp.txt") == "yes") $is_fp = true;

function linker($link) {

	global $room,
	       $uhr,
	       $datum,
	       $links,
	       $sound;

	$linkx = $link;	// Unterscheiden, ob URL oder PN umgewandelt wird

        if (strpos($link,":http://") === false) {   // wegen http://tbn0.google.com/images?q=tbn:Cg5amOzrpIob9M:http://www.cclonline.com/
	   $link = str_replace("http://"," http://",$link); // Leerzeichen vor dem URL erzwingen:
	}
	$link = str_replace("www."," www.",$link);
        $link = str_replace("http:// www.","http://www.",$link);

	$link = str_replace("http://www.","www.",$link);
	$link = str_replace("www.","http://www.",$link);

      // wegen z.B. http://images.google.de/imgres?imgurl=http://www.enorma...:
	$link = str_replace("= http","=http",$link);



        function shortlink($matches) { // _pr
          // http://de.php.net/manual/en/function.preg-replace-callback.php
                global $imginclude_pr,
                       $nick,
                       $admintrue,
                       $maxwidth,
                       $create_thumbs,
                       $maxheight,
                       $is_fp;


        	$matches[0] = str_replace("<","&lt;",$matches[0]);
        	$matches[0] = str_replace(">","&gt;",$matches[0]);

            $nocache = false;
            if (strpos($matches[0],"profile") !== false) $nocache = true; // damit Profilbilder nicht gecacht werden

            $moresmileys = $matches[0]; // ermoeglicht more smileys auch mit imginclude no


            // abs. Pfad in  relativen Pfadeumwandeln, wg. allow_url_fopen
            $abs_path = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF'])."/";

            $matches[0] = str_replace($abs_path,"",$matches[0]);

            // damit getimagesize nicht bei externen Links aufgerufen wird (wenn der Server das nicht erlaubt):
            if ($is_fp !== false || strpos($matches[0],"http:") === false) {

                  if ($imginclude_pr == "yes" || $admintrue !== false || strpos($moresmileys,"/smileys") !== false) {
                        $size = @getimagesize (trim($matches[0]));
                        if ($size[2] == 1 || $size[2] == 2 || $size[2] == 3) {
                                $width = $orgwidth = $size[0];
                                $height = $orgheight = $size[1];

                                // zu grosse Bilder zurueckweisen:
                                $red = 0;
                                //if ($width > 1600 || $height > 1200) return "<span style=\"display:none\">/pn</span> Bild zu gross - max. 1600 x 1200px";

                                // max. Groesse:
                                if (isset($maxwidth)) {
                                     if ($orgwidth > $maxwidth) {
                                         $height = $orgheight * $maxwidth / $orgwidth;
                                         $width = $maxwidth;
                                         $red = 1;          // Link zum Original, wenn verkleinert
                                     }
                                }

                                if (isset($maxheight)) {
                                     if ($height > $maxheight) {
                                         $width = $width * $maxheight / $height;
                                         $height = $maxheight;
                                         $red = 1;
                                     }
                                }
                                if ($red == 1) {
                                     // allow_url_fopen oder cURL verf�gbar?
//                                     if ($create_thumbs !== true || (ini_get('allow_url_fopen') != 1 || !function_exists('curl_init') )) {
                                     if ($nocache !== false || $create_thumbs !== true || (ini_get('allow_url_fopen') != 1 || !function_exists('curl_init') )) {
                                           // return ' <a href="redir.php?l='.$matches[0].'" target="_top" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.round($width,0).'px;" /></a> ';
                                           return ' <a href="'.$matches[0].'" onclick="OpenNewWindow(this.href,'.$orgwidth.','.$orgheight.',\'\');return false;" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.round($width,0).'px;" /></a> ';
                                     } else {
                                           // phpthumb:
                                           return ' <a href="'.$matches[0].'" onclick="OpenNewWindow(this.href,'.$orgwidth.','.$orgheight.',\'\');return false;" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="phpThumb.php?src='.$matches[0].'&amp;w='.$maxwidth.'&amp;h='.$maxheight.'&amp;q=70" /></a> ';

                                     }
                                } else {
                                         return ' <img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.$width.'px;" /> ';
                                }
                        }
                    }
                }



                if (strlen($matches[0]) > 37) {
                   return '<a href="redir.php?l='.$matches[0].'" rel="nofollow">'.substr($matches[0],0,30).' ...</a>';
                } else {
                   return '<a href="redir.php?l='.$matches[0].'" rel="nofollow">'.$matches[0].'</a>';
                }
        }
        function shortlink2($matches) { // nicht _pr
                global $new_win,
                       $nick,
                       $admintrue,
                       $imginclude,
                       $create_thumbs,
                       $links,
                       $maxwidth,
                       $maxheight,
                       $is_fp;
$create_thumbs = true;
$imginclude = "yes";
$maxwidth = 400;
$maxheight = 240;


        	$matches[0] = str_replace("<","&lt;",$matches[0]);
        	$matches[0] = str_replace(">","&gt;",$matches[0]);

            $nocache = false;
            if (strpos($matches[0],"profile") !== false) $nocache = true; // damit Profilbilder nicht gecacht werden

            $moresmileys = $matches[0]; // ermoeglicht more smileys auch mit imginclode no

            // abs. Pfad in  relativen Pfadeumwandeln, wg. allow_url_fopen
            $abs_path = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF'])."/";

            $matches[0] = str_replace($abs_path,"",$matches[0]);

            // damit getimagesize nicht bei externen Links aufgerufen wird (wenn der Server das nicht erlaubt):
            if ($is_fp !== false || strpos($matches[0],"http:") === false) {

                   if ($imginclude == "yes" || $admintrue !== false || strpos($moresmileys,"/smileys") !== false) {


                        $size = @getimagesize (trim($matches[0]));
                        if ($size[2] == 1 || $size[2] == 2 || $size[2] == 3) {
                                $width = $orgwidth = $size[0];
                                $height = $orgheight = $size[1];

                                // zu grosse Bilder zurueckweisen:
                                $red = 0;
                                //if ($width > 1600 || $height > 1200) return "<span style=\"display:none\">/pn</span> Bild zu gross - max. 1600 x 1200px";

                                // max. Groesse:
                                if (isset($maxwidth)) {
                                     if ($orgwidth > $maxwidth) {
                                         $height = $orgheight * $maxwidth / $orgwidth;
                                         $width = $maxwidth;
                                         $red = 1;          // Link zum Original, wenn verkleinert
                                     }
                                }

                                if (isset($maxheight)) {
                                     if ($height > $maxheight) {
                                         $width = $width * $maxheight / $height;
                                         $height = $maxheight;
                                         $red = 1;
                                     }
                                }

                                if ($red == 1) {
                                     // allow_url_fopen oder cURL verf�gbar?
//                                     if ($create_thumbs !== true || (ini_get('allow_url_fopen') != 1 || !function_exists('curl_init') )) {
                                     if ($nocache !== false || $create_thumbs !== true || (ini_get('allow_url_fopen') != 1 || !function_exists('curl_init') )) {

                                           if ($new_win == "yes") {
                                                 // return ' <a href="'.$matches[0].'" target="_blank" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.round($width,0).'px;" /></a> ';
                                                 return ' <a href="'.$matches[0].'" onclick="OpenNewWindow(this.href,'.$orgwidth.','.$orgheight.',\'\');return false;" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.round($width,0).'px;" /></a> ';
                                           } else {
                                                 // return ' <a href="'.$matches[0].'" target="_top" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.round($width,0).'px;" /></a> ';
                                                 return ' <a href="'.$matches[0].'" onclick="OpenNewWindow(this.href,'.$orgwidth.','.$orgheight.',\'\');return false;" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.round($width,0).'px;" /></a> ';
                                           }
                                     } else {
                                           // phpthumb:
                                           return ' <a href="'.$matches[0].'" onclick="OpenNewWindow(this.href,'.$orgwidth.','.$orgheight.',\'\');return false;" title="klick mich, und ich werde gro&szlig;!"><img alt="'._USERIMG.'" src="phpThumb.php?src='.$matches[0].'" /></a> ';
                                     }
                                } else {
                                         return ' <img alt="'._USERIMG.'" src="'.$matches[0].'" style="width:'.$width.'px;" /> ';
                                }
                        }
                    }
                }

                if ($new_win == "yes") {
        		$linktarget = "target=\"_blank\"";
        		$ext_hinweis = "<span class=\"dot\">"._LNKNEWWIN.": </span>";
        	    } else {
        		$linktarget = "";
        		$ext_hinweis = "";
        	    }

                if (isset($links) && $links == "no"  && strpos($matches[0],'popprof') === false) return _NOLINK;

                if (strlen($matches[0]) > 37) {
                  return $ext_hinweis.'<a href="'.$matches[0].'" rel="nofollow" '.$linktarget.'>'.substr($matches[0],0,30).' ...</a>';
                } else {
                  return $ext_hinweis.'<a href="'.$matches[0].'" rel="nofollow" '.$linktarget.'>'.$matches[0].'</a>';
                }
        }


	if (strpos($room,"_pr") !== false) {	// keinen referrer aus pr mitschicken
                $link = preg_replace_callback("/([\w]+:\/\/[\S+\.\/\@]+[\w\/])/i","shortlink", $link);

	} else {
		$link = preg_replace_callback("/([\w]+:\/\/[\S+\.\/\@]+[\w\/])/i","shortlink2", $link);
	}

//      if (isset($links) && $links == "no" && strpos($link,'profil') === false) {
//            return _NOLINK;
//      } else {
            $link = preg_replace("/([\S+\.\/]+\@(\[?)[\S+\.]+\.([a-zA-Z0-9]{2,6})(\]?))/i","<a href=\"mailto:$1\" rel=\"nofollow\">$1</a>",$link);
//      }

	// Einladung in private R�ume zum Link umwandeln:
	if ($link == $linkx && strpos($link,"/del") === false) {
                if (strpos($link,"/pn") === false) {
                	$link = preg_replace("/(\b\w+_pr\b)/",_INVITEPR.": <a href=\"chat.php?room=$1&amp;datum=$datum&amp;uhr=$uhr&amp;sound=$sound\">$1</a><br />"._INVITEADVISE."", $link);
                } else {
                	$link = preg_replace("/(\b\w+_pr\b)/",_INVITEPR.": <a href=\"chat.php?room=$1&amp;datum=$datum&amp;uhr=$uhr&amp;sound=$sound\">$1</a><br />", $link);
                }
	}

	return $link;

}
?>