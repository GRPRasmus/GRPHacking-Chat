<?php
header('Content-Type: text/javascript');

// cachen verhindern (IE):
// Bust cache in the head
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");

// always modified
header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
header ("Pragma: no-cache");                          // HTTP/1.0

$file = 'user_anw.txt';
$user = file($file);
$user = implode(" ",$user);
if ($user == "") $user = 0;
if (time() - filemtime($file) > 15) $user = 0;

?>

<? echo "document.write (': $user user on')"; ?>






