<?php
include ('chat_config.php');

// Alle Supporter aus chat_config.php auslesen:
// http://stackoverflow.com/questions/6284553/using-an-array-as-needles-in-strpos
function strposa($haystack, $needle, $offset=0) {
    if(!is_array($needle)) $needle = array($needle);
	if (!empty($needle)) {
		foreach($needle as $query) {
			if(strpos($haystack, $query, $offset) !== false) return true; // stop on first true result
		}
	}
    return false;
}

function support_online() {
	global $supporter,$online;
		
	// Wenn der Supporter in einem beliebigen Raum ist:
	$handle=opendir ("rooms");
	$supp_avail = false;
	if(isset($supporter)) {
		while ($datei = readdir ($handle)) {
			$anwesend = 'user/ip_'.$datei.'.txt';
			if (file_exists($anwesend)) {
				$online = file_get_contents($anwesend);
				$filealter = time() - filemtime ($anwesend);
				if (strposa($online,$supporter)!== false && $filealter < 5) {
					$supp_avail = true;
				} else {
				}
			}
		}
	} 
	closedir($handle);
	
	// Alternativ: Seite supporter_online.php im Browser öffnen:
	$anwesend2 = 'support_online/support_on.txt';
	if (file_exists($anwesend2)) {
		$filealter2 = time() - filemtime ($anwesend2);
	} else {
		$filealter2 = 100;
	}
	

	if($supp_avail === true || $filealter2 < 5 ) {
		echo 1;
	} else {
		echo 0;
	}
}
support_online();
?>
