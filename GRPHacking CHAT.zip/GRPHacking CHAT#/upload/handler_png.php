<?php

// ===========================================================================
// (c) 2010, Daniel Rued, www.rued.com
// http://www.ruedfotos.de/news/2010/2341/sendezeitbeschraenkung-fuer-bilder/ 
// ===========================================================================

if (file_exists("../jmstv.php")) include("../jmstv.php");

@ini_set('memory_limit','256M');


$image = new drImage($_REQUEST['png'].".png");

// Sendezeitbeschraenkung JMStV:
if (isset($jmstv_start) && isset($jmstv_end)) {

$stunde = date("G");
if ($stunde >= $jmstv_start || $stunde < $jmstv_end) {
  $image->showComplete();
}
else {
  $image->showBlur();
}

} else {
  $image->showComplete();
}



// Klasse zur Bildbehandlung

class drImage {
  protected	$image_input, $image_output; // Typ: Image-Ressourcen
  protected $zielhoehe, $zielbreite, $seitenverhaeltnis,
            $hoehe, $breite, $bildgroesse; // Typ: Integerwerte
	
  public function drImage($image_path) {
    $this->_loadImage($image_path);
    $this->_setSize();
  }

  protected function _loadImage($path) {
    $this->image_input = ImageCreateFromPNG($path);	
  }

  protected function _setSize($groesse=null) {
    if (empty($groesse)) {
      $x=@ImageSX($this->image_input);
      $y=@ImageSY($this->image_input);
      if ($x > $y) { 
        $this->bildgroesse=$x; 
      }
      else {
        $this->bildgroesse=$y;
      }
    }
    else {
      $this->bildgroesse=$groesse;
    }
  }

  public function show($groesse) {
    $this->bildgroesse=$groesse;
    $this->_calculateSize();
    $this->_resizeImage();
    header ("Content-type: image/png");
    ImagePNG ($this->image_output);
  }

	
  public function showBlur() {
    $tmp = $this->bildgroesse;
    $this->bildgroesse=75;
    $this->_calculateSize();
    $this->_resizeImage();
    $this->image_input = $this->image_output;
    $this->show($tmp, 50);
  }
	
  public function showComplete() {
    $this->show($this->bildgroesse);
  }
	
  protected function _resizeImage() {
    $this->image_output = imagecreatetruecolor ($this->zielbreite, $this->zielhoehe);
    imagecopyresized ($this->image_output, $this->image_input, 0, 0, 0, 0, $this->zielbreite, $this->zielhoehe, $this->breite, $this->hoehe );
  }
	
  protected function _calculateSize() {
    $this->breite=@ImageSX($this->image_input);
    $this->hoehe=@ImageSY($this->image_input);    
  	
    $this->seitenverhaeltnis = $this->hoehe/$this->breite;
    
    // wenn querformat
    if ($this->breite > $this->hoehe) {
      if ($this->breite < $this->size) { $this->bildgroesse=$this->breite; }
      $this->zielbreite=$this->bildgroesse;
      $this->zielhoehe=$this->seitenverhaeltnis*$this->zielbreite;
    }
    else {
      if ($hoehe < $size) {$this->bildgroesse=$this->hoehe; }
      $this->zielhoehe=$this->bildgroesse;
      $this->zielbreite=(1/$this->seitenverhaeltnis)*$this->zielhoehe;
    }    
		
  }
	
}

?>