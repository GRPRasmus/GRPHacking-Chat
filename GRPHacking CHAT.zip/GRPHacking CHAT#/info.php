<html>
<head>
<title>Spuren im Netz</title>
</head>
<body>
<h3>Was Sie so f&uuml;r Spuren im Netz hinterlassen!</h3>
<table border="0">
<tr>
	<td valign="top"><b>&Uuml;ber den Server:</b></td>
	<td valign="top"></td>
</tr>
<tr>
	<td valign="top">Ihre IP-Adresse:</td>
	<td valign="top"><? echo $_SERVER["REMOTE_ADDR"]; ?></td>
</tr>
<?
$what = gethostbyaddr($_SERVER["REMOTE_ADDR"]);
if ($_SERVER["REMOTE_ADDR"] != $what) 
{
?>
<tr>
	<td valign="top">Host:</td>
	<td valign="top"><? echo $what ?></td>
</tr>
<?
}
?>
<tr>
	<td valign="top">Sie kommen von:</td>
	<td valign="top"><? echo $_SERVER["HTTP_REFERER"]; ?></td>
</tr>
<tr>
	<td valign="top">Anfrage Methode:</td>
	<td valign="top"><? echo $_SERVER["REQUEST_METHOD"]; ?></td>
</tr>
<tr>
	<td valign="top">Ihr Browser erlaubt:</td>
	<td valign="top"><? echo wordwrap($_SERVER["HTTP_ACCEPT"],50, "<br />", 1); ?></td>
</tr>
<tr>
	<td valign="top">Server Protokoll:</td>
	<td valign="top"><? echo $_SERVER["SERVER_PROTOCOL"]; ?></td>
</tr>
<tr>
	<td valign="top">Browser-Version:</td>
	<td valign="top"><? echo $_SERVER["HTTP_USER_AGENT"]; ?></td>
</tr>
<tr>
	<td valign="top">Sprache:</td>
	<td valign="top"><? echo $_SERVER["HTTP_ACCEPT_LANGUAGE"]; ?></td>
</tr>
<tr>
	<td valign="top">Port:</td>
	<td valign="top"><? echo $_SERVER["REMOTE_PORT"]; ?></td>
</tr>
<tr>
	<td valign="top"><b>&Uuml;ber Java Script:</b></td>
	<td valign="top"></td>
</tr>
<tr>
	<td valign="top">Browser:</td>
	<td valign="top"><script type="text/javascript">document.write(navigator.appName)</script></td>
</tr>
<tr>
	<td valign="top">Betriebsystemtyp:</td>
	<td valign="top"><script type="text/javascript">document.write(navigator.platform)</script></td>
</tr>
<tr>
	<td valign="top">Bildschirmaufl&ouml;sung:</td>
	<td valign="top"><script type="text/javascript">document.write(screen.width + " x " + screen.height)</script></td>
</tr>
<tr>
	<td valign="top">Farbtiefe:</td>
	<td valign="top"><script type="text/javascript">document.write(screen.colorDepth + " bit")</script></td>
</tr>
<tr>
	<td valign="top">Java eingeschaltet?</td>
	<td valign="top">
		<script type="text/javascript">
		if(navigator.javaEnabled()){document.write("Ja")}
		else{document.write("Nein")}
		</script>
	</td>
</tr>
<tr>
	<td valign="top">Anti-aliasing Schriften?</td>
	<td valign="top">
		<script type="text/javascript">
		if(window.screen.fontSmoothingEnabled == true){document.write("Ja")}
		else{document.write("Nein")}
		</script>
	</td>
</tr>
<tr>
	<td valign="top">Plugins (nur Netscape):</td>
	<td valign="top">
		<script type="text/javascript">
		for(i=0; i<navigator.plugins.length; i++)
		{
			document.writeln(navigator.plugins[i].name + "<br />");
		}
		</script>
	</td>
</tr>
</table>
</body>
</html>