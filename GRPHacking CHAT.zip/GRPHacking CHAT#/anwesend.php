<?php

// Anzeige der user online

// cachen der AJAX Daten verhindern (IE):
// Bust cache in the head
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header('Content-type: text/html; charset=utf-8');

// always modified
header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
header ("Pragma: no-cache");                          // HTTP/1.0

$show_dir = 'user/';
$dir=opendir($show_dir);
$liste = "";
while (false !== ($file = readdir($dir))) {
        $on = "";

       	if(strpos($file,"ip_") !== false
               && time() - filemtime($show_dir.$file) < 20) {

               $room = str_replace("ip_","",$file);
               $room = str_replace(".txt","",$room);
               if (strpos($file,"_pr")) {           // private Raeume anonym anzeigen
                  $room = "<p><em>In einem privaten Raum:</em></p>\n<ul>\n";
               } else {
                  $room = "<p><em>Im Raum $room:</em></p>\n<ul>\n";
               }
               $userfile = $show_dir.$file;
               $lines = file($userfile);
               foreach ($lines as $line_num => $line) {
                        $user = explode("++++",$line);
						//$user2 = explode("####",$user3[1]);
						//$user = $user2[0];

						if (strlen($user[1]) > 1 && strpos($user[1],"ghost") === false && trim($user[1]) != '####') {
							$anwesend = str_replace("####handy"," <span>📱</span>", $user[1]);
							$anwesend = str_replace("####","", $anwesend);
							$on .= "<li>".$anwesend."</li>\n";
                        }
						if (strlen($user[1]) > 1 && trim($user[1]) == '####') {
							$on .= "<li>Mitleser in der Shoutbox</li>\n";
                        } 
               }
               if ($on != "") {
                       $on = explode("\n",$on); // sortieren
					   $on = array_unique($on); 
                       natcasesort($on);
                       $on = implode("\n",$on);
                       $liste = $room.$on."</ul>";
                       echo $liste;
               }
        }
}
//if ($liste == "") echo "<p>... leider niemand <img src=\"sad.gif\" alt=\"traurig\" width=\"15\" height=\"15\" /></p>";
if ($liste == "") echo "<p>... niemand</p>";
?>