<?php



$chat_light = "no";	   // yes, dann hast Du einen Chat-light ohne R�ume und ohne Optionen


$admins = array(
    'Max',
    'Moritz'
              // du kannst beliebig viele weitere Namen hinzuf�gen
              // Achtung: die letzte Zeile ohne Komma am Ende!
);



$languages = array(
   'de'             // und wieder: die letzte Zeile ohne Komma!
);


$anz_rooms = 6;

$flood = 0;	       		 // Floodingsperre in Sekunden.
                               // 0 = Floodingsperre aus
                               // beim Admin greift die Floodingsperre nat�rlich nicht


$anz_msg = "40";

$maxsize = 8000;

$logfile = "on";


$refresh = 1000;

$user_hoehe = 14;          // einige Skins verwenden diesen Wert f�r die H�he der user Online Anzeige



$pnlivetime = 2592000;             // Lebensdauer von privaten Nachrichten in Sekunden: 1 Monat


$onmouseoveroptions = false;    // mit false das onmouseover bei den Anzeigeoptionen ausschalten


$showdat = "off";		   // "on/off"	- Datum anzeigen
$showtime = "off";		   // "on/off"	- Uhrzeit anzeigen


//$nickcolors = "off";	   // "on/off" - Ausklappmen� f�r Nickfarben anzeigen

                              
$mp3all = "clean";             // "alle" - Alle d�rfen in allen R�umen mp3 hochladen
                              // "clean" - mp3 hochladen erlaubt in moderierten R�umen, Cleanrooms und privaten R�umen, Admins in allen R�umen
                              // "admins" - nur Admins d�rfen mp3 hochladen (in allen R�umen)
                              // "" - kein mp3 Uplodad



$mailmust = true;             // muss bei der Registrierung eine Mail-Addy angegeben werden?


$default_skin = 12;   // dieser Skin wird voreingestellt, wenn $stil = 0, und solange der user keinen anderen Skin w�hlt.

$schrift = 100;		   // Schriftgr��e. Sinnvolle Werte: 80 bis 120

$ip = "off";                // "on/off" - IP anzeigen
$online_time = "off";       // "on/off" - Online-Zeit anzeigen
$real_time = "off";         // "on/off" - Uhrzeit anzeigen
$slowdown = 0;
$klapp_options = false;
$imginclude = "no";          // "yes/no" Bilder einbinden zulassen, und das Upload Feld anzeigen.
                              // Admin kann immer Bilder einf�gen/ Dateien uploaden
                              // Achtung! das Einbinden von Bildern erzeugt hohe CPU Last auf dem Server!
                              
$imginclude_pr = "no";        // wie $imginclude, f�r private R�ume


$anz_msg = "30";		   // Anzahl der angezeigten Meldungen (mit Scrollen)
				   // wenn das Nachrichtenfenster nicht mehr richtig scrollt, dann hast Du hier wahrscheinlich �bertrieben

$blankrooms = "yes";            // "yes/no" - "yes": alle R�ume sind nach dem Login leer

/* alternatives Soundschema */
$sound1 = "0.mp3";   // Du betrittst einen Raums / Aktualisierung
$sound2 = "sounds/sound50.mp3";   // User betritt den Raum
$sound3 = "sounds/sound54.mp3";   // Du schickst eine Meldung ab
$sound4 = "sounds/sound55.mp3";   // Eingang einer anderen Meldung
$sound5 = "sounds/bass.mp3";   // User verlaesst den Raum
$sound6 = "sounds/alarm3.mp3";    // der Alarm

$more_smileys = "off";	// "on/off" - more_smileys zeigen // show/hide more_smileys

?>