<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
if (!isset($user_hoehe)) $user_hoehe = 14;
?>

/* CSS fuer Skin 10 Sky */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, input, select {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	/* color: #303030; die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */
}

html {
	/* overflow-y: scroll; macht einen permanenten Geisterscrollbalken auch im Fx und Op, leider nicht valid */
}

body {
      width: 95%; max-width: 65em;
      margin: 10px auto;
	background:#fff; 	/* hier die Hintergrundfarbe fuer die Seite */
}


h1 {
	font-size:1.3em;
	line-height:125%;
	font-variant:small-caps;
	color:#747474;
}

h2 {
	font-size:.8em;
	line-height:125%;
      margin: 1em 0 .3em 0;
}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #help tr, legend, select {
	font-size:.8em;
}


#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
	/* position:relative; top:.15em; hm? */
}

#user_pro_room a {text-decoration:none}


#user_pro_room em:after { 
	content:" ✔︎";
}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}


ul {
	font-size:.8em;
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}



fieldset {
	clear: right;
	background: #fff;		/* die Hintergrundfarbe fuer das Chatfenster */
	margin:0 0 0 0;
      border:none;
 	padding: 2px 2px 0 2px;
}

fieldset fieldset {
       background: #fff;	/* die Hintergrundfarbe fuer die Optionsfelder */
       /*background-image:url(bg_teaser.gif);
       background-repeat:repeat-x;
       */

	 padding: 2px 4px 4px 3px;
	 margin-bottom: 3px;
}
* html fieldset fieldset {
         float:right;
         width:20%;
}

/* Op und Safari hack (Op 9.1 kanns auch ohne): */
html:first-child>b\ody fieldset fieldset {
	 margin-left: 76%;
}

.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #747474;
}

.tr {visibility: hidden;}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {
	margin: 0 6px 2em 0;
}

#wall {
	height: <?php echo $hoehe ?>em;
	background:#fff;		/* die Hintergrundfarbe fuer das Nachrichtenfenster */
	/* background-image:linear-gradient( #eeeff1, #fff 15%); */

	overflow: auto;
	margin: 0 0 15px 0;
	border: 1px solid #aaa;
	padding: 3px;
	line-height: 1.1em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
}
* html #wall {
      background-attachment:fixed;
}

*+html #wall {
	background-position: 0 2em; /* sonst doppelter border-top */
    background-attachment:fixed;
}

#wall p {
        /* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 3em;
	text-indent: -2.6em;
	margin-bottom: 2px;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#wall .whisper, #wall .at {color:red; background: yellow}



#line {
	width: 80% !important;
	min-width:80% !important;
	max-width: 80% !important;
	margin-left:0;
    border: 1px solid #aaa;
    padding: 2px 5px;
	font-size:1em;
}
input#line {position:relative; top: -7px;}



#op {margin:3px 0}

#ton {
	width: 0;
	height: 0;
}

#uo{
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
        echo "display:block; min-height: 8em; max-height: ".($hoehe - (20 - $user_hoehe))."em; overflow-y:auto; overflow-x:hidden";
	} else {
 		echo "line-height: 2em;";
        }
        ?>
}
html:first-child>b\ody #uo { /* Opera Hack */
      overflow: auto;
}

#user_pro_room{
	display:block; min-height: <?php echo $anz_rooms+1; ?>em; overflow-y:auto; overflow-x:hidden}
html:first-child>b\ody #user_pro_room { /* Opera Hack */
      overflow: auto;
}


#uo ul, #uo ul li {
	display: inline;
	<?php
      if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	}
      ?>
	font-size:100%;
	margin: 0; 
	padding:0 .1em;
}
#uo ul, #user_pro_room ul {
	background:#fff;
/*    background-image:url(img/bg_teaser3.gif);
	background-repeat:repeat-x; */
	background-image:linear-gradient( #eee, #fff);

	/* border: 1px solid #bbb;*/
	padding: .3em 0 .25em .2em;
	margin-top: .3em;
	line-height:1.45em;
}

/* #user_pro_room ul {display:none;} */

#uo a, #user_pro_room a {text-decoration:none}

#addsmileys {
/*	float:left; */
	margin: 3px 0 0 5px;
}
object {margin: 5px;}

dfn, .dot, #sr {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


.bg {background:none;}  /* der Hintergrund fuer den Admin */


label,
select,
input {
cursor: pointer;
}

.button {padding:3px; top:-7px}

* html .button {padding:0;}
*+html .button {padding:0;}

.away {
    border-radius: 1em;
    padding:1px 6px 2px 6px;
    background-color: #747474;
    color: #fff;
}

label {margin:0 3px}


#line, #handle, #room {
       background:#fff;
       cursor:text;
}



#menu1, #menu2, #room {width:50%}
* html #menu1, * html #menu2 {width:48%}

select {font-size: 100%}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
   echo '#menu2 {width: 100%}';
   echo '* html #menu3 {width:96%}';
}
?>

<?php
if ($stil != 0) {
   echo '#menu1 {width: 100%}';
   echo '* html #menu1 {width:96%}';
}
?>

#opt2 {clear:left; padding-top: 5px}
.opt {
     display:block;
     margin: 0 0 2px 0;
     padding: 0;
}
* html .opt {margin: 0 0 -4px 0;}
.uolist {display:none;}
#upload {
	clear:left;
	margin:8px 5px 3px -7px;
	background:#fff;
}

/* #upload div img {margin-left:7px} */

@media screen and (-webkit-min-device-pixel-ratio:0) { /* nur Blink, also Chrome - und natürlich Opera */
	audio {
	border: 1px solid #ccc;
	border-radius: 40px;
	}
}

_::-webkit-full-page-media, _:future, :root audio { /*Safari*/
	border: 0;
}

#upload_2 {margin: 0 6px ;}
#addsmileys ul li a:visited span {color:#fff}
#addsmileys ul li a:hover span,
#addsmileys img {
        color: #303030;
}

#logout, .logout, #einaus_ae {
        text-align:center;
        margin:7px 1px 0 0;
        padding:3px 8px;
        border: 1px solid #ccc;
		border-radius:1em;
        background-color: #f1f3f4;
		cursor:pointer;
		display:block;
}
#logout:focus, #logout:hover, .logout:focus, .logout:hover, #einaus_ae:hover, #einaus_ae:focus {
	background-color:#fff
}

#logout a, .logout a {text-decoration:none; color:#555 !important}

.helplinks {
margin:0 10px;
position:relative;top:2px;
}

input, select {
border: 1px dotted #666;
padding: 2px;
}
input {
margin-right: 2px;
}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50% !important;
}

.av {
	width: 30px !important;
	object-fit: cover;
}

.hello {color: #747474; font-size: 80%; font-style:italic;}

fieldset #upload #file{border:0 none !important;} /* fuer Chrome */

a.stop {
color:#fff;
background: #747474 !important;
text-decoration:none;
font-size: 80%;
padding: 3px 6px;
border-radius: 1em;
}
#ae {margin-bottom:.5em;}
#einaus_ae {color:#555;min-height:17px}

#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
      border: 0;
      background: transparent;
}

#mp3 {display:block;}
#r_player ul, #player ul {background: #fff;}
#r_player a, #player a {color: #222;}

/* #webradio {color:#666;} */
#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

#topic, #topic_wdw {
margin:3px 0 5px 0;
font-weight:bold;
color: #747474;
}

#nickname {display:inline-block;color:red;}

.uhr {font-size:.7rem;color:#747474;margin-left:1em}

.more_smileys img {
    border: 1px solid #747474;
    border-radius: 2em;
}

.yta {color:black;font-weight:bold; font-family:Arial narrow; font-size: 1.2em;}
.ytb {font-family:Arial narrow; background:red;color:white;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}


#webradio {text-align:center;max-width:100%}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;border-radius:5px;}
input[type="image"]:hover, input[type="image"]:focus { background: #fff}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
#audio-controls {
	margin: .5em 0;
	border: 1px solid #ccc;
	padding-top: 10px;
	border-radius: 7px;
	background: #f1f3f4;
}

