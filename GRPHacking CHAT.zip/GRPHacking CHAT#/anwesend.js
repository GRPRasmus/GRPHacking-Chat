/* ///////// audio-sprite: ////////////// */

if (document.getElementById('audio-sprite')) { var audioSprite = document.getElementById('audio-sprite');}

var spriteData = {
	aktiv: {
		start: 0,
		length: 1.6
	},
	msg: {
		start: 3,
		length: 3
	},
	betreten: {
		start: 7,
		length: 3
	}
};

// current sprite being played
var currentSprite = "";

// time update handler to ensure we stop when a sprite is complete
var onTimeUpdate = function() {
	if (this.currentTime > currentSprite.start + currentSprite.length) {
		this.pause();
		this.currentTime = 0;
	}
};

if (document.getElementById('audio-sprite')) {
	audioSprite.addEventListener('timeupdate', onTimeUpdate , false);
}


var playSprite = function(id) {

	if (document.getElementById('audio-sprite')) {
		
			// alert(audioSprite.currentTime);
			if (spriteData[id] && spriteData[id].length) {
				currentSprite = spriteData[id];
				setTimeout(audioSprite.currentTime = currentSprite.start,100);
				audioSprite.play();
			}
	
	} else {
			// nichts tun
	}
};


// touchstart nur einmal ausführen:
var enterPushed = true;

document.addEventListener("touchstart",function(){
	if (enterPushed === true) {
		// alert ("touchstart");
		playSprite('aktiv');
		enterPushed = false;
	}
});


/* /////// end audio-sprite ///////////////// */

if (document.getElementById('help')) {
	const target = document.getElementById("help");
	function help() {
		target.style.opacity = '0';
	}
}

var repeat_sound_off = 1; 

if (document.getElementById('soundoff')) {
	document.getElementById('soundoff').onclick = function(){
		// alert('click');
		document.getElementById('soundoff').style.display='none';
		document.getElementById('hinweis').style.display="block";
		help();	
		repeat_sound_off = 0; 
	}
};


domain = document.domain;
path = window.location.pathname; // /chat/whoson.php
if (path.indexOf("whoson") != -1) {
	var dir = path.replace("/whoson.php","");
	var install = "//" + domain + dir;
} else {
	var install = "//" + domain + "/chat";
}

// zuerst der AJAX Teil:
// http://aleembawany.com/2005/09/01/ajax-instant-tutorial/
function loadurl(dest) {
	try {
		xmlhttp = window.XMLHttpRequest?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
	}
	catch (e) { /* do nothing */ }

	xmlhttp.onreadystatechange = triggered;
	xmlhttp.open("POST", dest);
	xmlhttp.send(null);
}

function triggered() {
	if (xmlhttp.readyState == 4) document.getElementById("output").innerHTML =xmlhttp.responseText;
}

// function help() {
// document.getElementById('sound_activate').style.display='none';
// }

// und jetzt auto-refresh und sounds:
var anw = 0;
var waiting = 0;

function refresh() {
	loadurl('anwesend.php');

	y=document.getElementById("output").innerHTML;
	x=y.length;

	if (y.indexOf('noscript') != -1) {
		anw = 0;
	} else if (y.indexOf('niemand') != -1) {
		changeFavicon('img/traurig_ico.png');
		document.title = "Leider niemand im Chat";	
		anw = 0;
		waiting = 0;
	} else {
		changeFavicon('img/favicon-32x32.png');
		document.title = " Chatter anwesend";
		//alert (y);
		
		if (y.indexOf('Lobby') != -1) { // Sound nur im Raum Lobby
			if (anw == 0) {
				if (waiting == 1) {
					if (repeat_sound_off == 1 ) {
						if (y.indexOf('Support') == -1) { // Kein Wiederholungs-Sound, wenn der User "Support" (Admin) im Raum ist.
							playSprite('msg');	// Wiederholungs-Sound. Entkommentieren, wenn Soundwiederholung gewünscht wird.
						}
					}
				} else {
					playSprite('betreten'); // Eintrittsmeldung einmalig
				}
			}
		}
		if (waiting == 1) {
			anw = 0;
		} else {
			anw = 1;
		}
		waiting = 1;
	}

	if (waiting == 1) {
		update_refresh = setTimeout(refresh, 10000); // Häufigkeit Wiederholungs-Sound
	} else {
		update_refresh = setTimeout(refresh, 2000);
	}
}


document.head = document.head || (document.getElementsByTagName('head')[0]);
function changeFavicon(src) {
	src = src+'?='+Math.random(); // so wird das cachen zuverlässig vermieden
	
	var link = document.createElement('link'),
	oldLink = document.getElementById('dynamic-favicon');
	link.id = 'dynamic-favicon';
	link.rel = 'shortcut icon';
	link.href = src;
	if (oldLink) {
		document.head.removeChild(oldLink);
	}
	document.head.appendChild(link);
}

window.onload = function () {
	playSprite('aktiv');
	refresh();
	setTimeout(help, 20000);
}