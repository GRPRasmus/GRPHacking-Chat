<?php
session_start();


// Schriftgröße:
if (isset($_GET['size'])) {
	
	
	if (isset($_SESSION['textsize'])) { // falls Session-Variable "textsize" bereits existiert
		$basesize = $_SESSION['textsize']; // wird "textsize" als Basis für nachfolgende Berechnung verwendet
	} else {
		$basesize = 1; // andernfalls: Basis Textgröße 1
	}

	$factor = $_GET['size']; // der Vergrößerungs-/Verkleinerungsfaktor wird aus dem URL-Parameter ausgelesen
	$textsize = $basesize * $factor; // und mit Basis multipliziert zur neuen Textgröße
	
	// Jetzt noch min-/max- Schriftgröße festlegen:
	if ($textsize > 2.5) {$textsize = 2.5;}
	if ($textsize < .8) {$textsize = .8;}
	
	
	$_SESSION['textsize'] = $textsize; // und die neue Textgröße in einem Session-Cookie speichern.
} 


header('Location: ' . $_SERVER['HTTP_REFERER']); // zurück zur aufrufenden Seite
?>