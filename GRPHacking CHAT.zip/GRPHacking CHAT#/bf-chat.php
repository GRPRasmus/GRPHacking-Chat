<?php

if(file_exists("check_mobile.php")) {
       require('check_mobile.php');
       if(check_mobile() !== true) {
		   setcookie("Style", "12" , time() +3600);  /* verfällt nach 1 Stunde */
       }
}


// Redirect zum Chat:

$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'login.php';

header("Location: http://$host$uri/$extra");
exit;

?>


