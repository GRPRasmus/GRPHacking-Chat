/* <![CDATA[ */

// zuerst der AJAX Teil:
// http://aleembawany.com/2005/09/01/ajax-instant-tutorial/

var xmlhttp = "";
function loadurl2(dest2) {
        try {
                xmlhttp = window.XMLHttpRequest?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (e) { /* do nothing */ }

        xmlhttp.onreadystatechange = triggered2;
        xmlhttp.open("GET", dest2);
        xmlhttp.send(null);
}

function triggered2() {
        if (xmlhttp.readyState == 4) if (xmlhttp.status == 200) if(document.getElementById("anw")) document.getElementById("anw").innerHTML =xmlhttp.responseText;
}


// und jetzt auto-refresh:

function refresh2() {
         // in folgender Zeile evtl. den Pfad anpassen:
         loadurl2('http://' + document.domain + '/chat/anw_anz.php');
         setTimeout("refresh2()", 4000);
}
//window.onload=refresh2;

/* ]]> */
