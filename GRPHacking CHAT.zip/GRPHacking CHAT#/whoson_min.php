<?php
session_start();
if (isset($_SESSION['textsize'])) {
	$size = $_SESSION['textsize'];
} else {
	$size = 1; // Standard-Schriftgröße, falls noch kein Session-Cookie gesetzt
}

if( isset( $_SERVER['HTTP_USER_AGENT'])){
	$u_agent = $_SERVER['HTTP_USER_AGENT'];
} else {
	$u_agent = '';
}

?>	
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<meta name="description" content="Ein kostenloser Chat - von webdesign weisshart. Whoson zeigt die anwesenden User, und spielt Sound-Mitteilungen." />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Chat whoson - by webdesign weisshart</title>


<style>
	html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img {
		font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
		border:0;
		margin:0;
		padding:0;
		
	}
	
	
	html {background: #fff;padding:1em;-webkit-text-size-adjust: 100%;}
	p, legend, ul {font-size: 100.01%;}
	li {margin-left: 1.5em;}
	fieldset {
		padding:1em;
		display:inline-block;
		width: calc(100% - 2.5em);
/*		font-size:1.2em;*/
		min-height: 4em;
		border:2px solid #aaa;
	}	
	#hinweis {display:none;text-align:center;cursor:pointer;}
	#hinweis b {border:2px solid;padding:.5em 1em;background:#ddd;display:block;margin-top:.5em;}
	
	#soundoff {border:2px solid;padding:.5em 1em;background:#ddd;display:block;margin-top:1em;text-align:center;font-weight:bold;cursor:pointer;}
	
	body {font-size:<?php echo $size; ?>em;max-width: 35em;margin:auto;}
	#styleswitcher {position:-webkit-sticky;position:sticky;top:0;text-align:right; z-index:5;margin:.3em .3em 1em 0;}
	#styleswitcher a {text-decoration:none;color:#000;background: #ddd; display:inline-block; padding:3px 5px;font-family:sans-serif;font-weight:bold;border:2px solid;}
	#styleswitcher a:focus, #styleswitcher a:hover {text-decoration:underline;filter:invert(1);}
	img {max-width:100%;height:auto;}
	
	@media (prefers-color-scheme: dark) {
		html {filter:invert(1);}
	}
	
	
</style>

<?php
if($size > 2.5) {echo '<style>#bigger {display:none !important;}</style>';}
if($size < .9) {echo '<style>#smaller {display:none !important;}</style>';}
?>

</head>
<body>
	

<!--<div id="styleswitcher">
<a id="smaller" href="resize.php?size=0.8" >A&minus;</a> <a id="bigger" href="resize.php?size=1.25">A+</a>
</div> -->
	
<fieldset>
	<legend> Wer ist im Chat? </legend>
	<div id="output"> <noscript><p>Die User-Online Anzeige erfordert Javascript.</p></noscript> </div>
</fieldset>


<!--<p id="hinweis"><br>Zum Aktivieren des Sounds <a onclick="javascript:hide()"><b>➡︎&nbsp;hier klicken&nbsp;/ tippen</b></a></p>

<p id="soundoff">Sound ausschalten</p>

<audio  id="audio-sprite"><source src="sounds/sprite3.mp3?<?php echo time(); ?>" type="audio/mpeg" /></audio>
 -->


<script src ="anwesend.js?<?php echo time(); ?>"></script>

</body>
</html>

