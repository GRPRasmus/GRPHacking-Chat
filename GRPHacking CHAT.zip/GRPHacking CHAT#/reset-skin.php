<?php
// cookies loeschen:
setcookie ('Style', '', time() - 3600);
setcookie ('reverse', '', time() - 3600);
setcookie ('bilder', '', time() - 3600);
setcookie ('datum', '', time() - 3600);
setcookie ('uhr', '', time() - 3600);
setcookie ('sound', '', time() - 3600);
setcookie ('nickfarben', '', time() - 3600);
setcookie ('nickfarben2', '', time() - 3600);
setcookie ('time_online', '', time() - 3600);
setcookie ('time_real', '', time() - 3600);

setcookie ('ignore', '', time() - 3600);

//Redirect zum Chat:
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra1 = 'chat.php';

if ( isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != '' ) {
	header("Location: https://$host$uri/$extra1");
	exit();
} else {
	header("Location: http://$host$uri/$extra1");
	exit();
}	



?>
