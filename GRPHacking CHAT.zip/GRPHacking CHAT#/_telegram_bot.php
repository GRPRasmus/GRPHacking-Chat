<?php

function isExtensionLoaded($extension_name){
    return extension_loaded($extension_name);
}


if (isExtensionLoaded('curl')) {
	echo "cURL";
} else {
	exit;
}


include("chat_config.php");


if (!isset($token) || !isset($chatID)) {exit("telegram ID und token not set in config");}
if (!isset($_SESSION["chatuser"])) {exit;}

$user = $_SESSION["chatuser"].' hat den Chat betreten.' ;
$zeit = date("H:i ");

$text = $zeit.$user;

function sendMessage($chatID, $messaggio, $token) {
//echo "sending message to " . $chatID . "\n";

$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
$url = $url . "&text=" . urlencode($messaggio);
$ch = curl_init();
$optArray = array(
	CURLOPT_URL => $url,
	CURLOPT_RETURNTRANSFER => true
);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);
}


sendMessage($chatID,$text, $token);

?>

