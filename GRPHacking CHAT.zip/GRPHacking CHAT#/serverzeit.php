<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="1">

<title>Serverzeit</title>

</head>
<body>



<p>Auf deinem Server eingestellte Zeit: 


<?php
$datum = date("d.m.Y");
$uhrzeit = date("H:i:s");
echo $datum," - ",$uhrzeit," Uhr";
?>



</body>
</html>
