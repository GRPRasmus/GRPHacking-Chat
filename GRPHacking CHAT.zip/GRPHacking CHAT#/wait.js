function noshowWait() {
	if (document.getElementById('wait')){
		document.getElementById('wait').style.visibility='hidden';
		return true;
	}
}
function showWait() {
	if (document.getElementById('wait')){
		document.getElementById('wait').style.visibility='visible';
		return true;
	}
}