<?php

if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}

switch ($lang) {
	default: include("langDE_inc.php");
	break;
	case "de": include("langDE_inc.php");
	break;
	case "en": include("langEN_inc.php");
	break;
}

include("chat_config.php");

function isMobile() {
	return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}

if (!isset($self_close) || $self_close != "" || isMobile() ) {$self_close = "self.close();";}

if (isset($stil) && $stil <> 0) {
	$s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
	$s = $default_skin;
}

//if (isMobile()) {$s = 13;}

?>

<!DOCTYPE html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />

<title>Smileys einf&uuml;gen</title>



<link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" />
<link rel="stylesheet" type="text/css" media="screen" href="smiley_box_css.php" />


<script>

	function newsmile(smiley) {
		if (window.opener.document.getElementById('line').value.indexOf('<? echo _MESSAGE; ?>') !== -1) {
			window.opener.document.getElementById('line').value = "";
		}
        	
		window.opener.document.getElementById('line').value += " "+smiley+" ";
		window.opener.focus();
		window.opener.document.getElementById('line').focus();
	}
		
	function kp(e){if (!e) e=window.event;if (e.keyCode==27 && !e.shiftKey){self.close();}}window.onkeypress=kp;

	var cookieWert;
	function holeCookie(keksname) {
		var alleCookies, i;
		alleCookies=document.cookie;
		cookieArr=alleCookies.split(";");
		for(var i=0;i<cookieArr.length;i++) {
			if(cookieArr[i].split("=")[0].replace(/\s+/,"") == keksname) {
				cookieWert=cookieArr[i].split("=");
				cookieWert=decodeURIComponent(cookieWert[1].replace(/\+/g," "));
				return true;
			}
		}
		return false;
	}
	
	var timeOutFunctionId;
	function workAfterResizeIsDone() {
		var w = window.innerWidth;
		var h = window.innerHeight;
		var l = window.screenLeft;
		var t = window.screenTop;
		
		localStorage.setItem("box_width", w);		
		localStorage.setItem("box_height", h);		
		localStorage.setItem("box_left", l);		
		localStorage.setItem("box_top", t);							
					
	}
	window.addEventListener("resize", function() {
		clearTimeout(timeOutFunctionId);			
		timeOutFunctionId = setTimeout(workAfterResizeIsDone, 500);
	});
	

</script>


</head>
<body onkeydown="kp()" onload="focus();">


<div class="wrapper">
<div class="wechselbuttons">

<?php


$verz1 = str_replace('usr_','',basename($_SERVER['PHP_SELF']));
$verz = str_replace('.php','',$verz1);


for($i = 0; $i <= count($smiley_dirs); $i++){
	if (file_exists ("smileys".$i."")  && file_exists ("usr_smileys".$i.".php") && strpos($_SERVER['PHP_SELF'],"usr_smileys".$i.".php") === false) {
		echo '<a class="button" href="usr_smileys'.$i.'.php">▶︎ '.$smiley_dirs[$i - 1].'</a>&nbsp;';
	}
	if (file_exists ("smileys".$i."")  && file_exists ("usr_smileys".$i.".php") && strpos($_SERVER['PHP_SELF'],"usr_smileys".$i.".php") !== false) {
		echo '<p class="button" style="opacity:.5" >'.$smiley_dirs[$i - 1].'</p>&nbsp;';
	}
}

echo "</div>";

$bilder = array();

$dir=opendir($verz);

while (false !== ($file = readdir($dir))) {
	if(strpos($file,".gif") !== false || strpos($file,".png") !== false|| strpos($file,".mp3") !== false || strpos($file,".mp4") !== false ) { 
		$bilder[] = $file;
	}
}
		
if(empty($bilder)) {
	echo "<p>Hier gibt es (noch) keine Smileys</p>"; 
}

sort($bilder);


if ( isset( $_SERVER["HTTPS"] ) && strtolower( $_SERVER["HTTPS"] ) == "on" ) {
	$prot="https://";
} else {
	$prot="http://";
}

if (isset($usr_smileys_table_x) && isset($usr_smileys_table_y) && is_numeric($usr_smileys_table_x) && is_numeric($usr_smileys_table_y) ) {
	echo '<table><tr>';
	foreach($bilder as $wert) {
		$smiley = '<img src="'.$verz.'/'.$wert.'" alt="" />';
		$directory = "";
		if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
		$link = $prot.$_SERVER['SERVER_NAME'].$directory.'/'.$verz.'/'.$wert;
		$linktext = str_replace("Audio:","",$link);
		$linktext = str_replace(".mp3","",$linktext);
		$linktext = str_replace("_"," ",$linktext);

		// auch mp3 und mp4
		if(strpos($wert,".mp4") !== false ) {
			$smiley = '<video src="'.$verz.'/'.$wert.'" height="100" width="150" type="video/mp4" autoplay mute playsinline  ></video>';
			echo '<td><a href="#" onclick="newsmile(\''.$link.' \'); '.$self_close.' return false;">'.$smiley.'</a></td>';
		} elseif (strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
			echo '<td><a href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.$smiley.'</a></td>';
		} else {
			echo '<td> <a class="mucke" href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.basename($linktext).'</a></td>';
		}
	}
	echo '</tr></table>';
        
} else {
        
	echo '<ul>';
	foreach($bilder as $wert) {
		$smiley = '<img src="'.$verz.'/'.$wert.'" alt="" />';
		$directory = "";
		if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
		$link = $prot.$_SERVER['SERVER_NAME'].$directory.'/'.$verz.'/'.$wert;
		$linktext = str_replace("Audio:","",$link);
		$linktext = str_replace(".mp3","",$linktext);
		$linktext = str_replace("_","&nbsp;",$linktext);

		// auch mp3 und mp4
		if(strpos($wert,".mp4") !== false ) {
			$smiley = '<video src="'.$verz.'/'.$wert.'" height="100" width="150" type="video/mp4" autoplay mute playsinline  ></video>';
			echo '<li><a href="#" onclick="newsmile(\''.$link.' \'); '.$self_close.' return false;">'.$smiley.'</a></li>';
				
				
		} elseif (strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
			echo '<li><a href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.$smiley.'</a></li>';
		} else {
			echo '<li> <a class="mucke" href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.basename($linktext).'</a></li>';
		}
	}
	echo '</ul>';            
        
}

closedir($dir);
?>

<div class="push"></div>

</div>

<div class="footer">

<?php
echo '<p>'._USR_SMILEY1._USR_SMILEY2.'</p>';
?>
</div>

</body>
</html>