<?php
// Diese Datei schreibt ein Logfile mp3log.txt mit den aufgerufenen mp3
// sie wird von dem AJAX Request get() in der function playmp3(typ) in der Datei chat_js.php aufgerufen
@include("chat_config.php");


$zeit = date("d.m.Y H:i:s");
$titel = $_GET['file'];
$titel = str_replace ('smileys/','',$titel);
$titel = str_replace ('upload/','',$titel);
$titel = str_replace ('chat/','',$titel);
$titel = str_replace ($_SERVER['SERVER_NAME'],'',$titel);
$titel = str_replace ('http://','',$titel);
$titel = str_replace ('/','',$titel);
$titel = str_replace ('_',' ',$titel);

// ab PHP5 http://www.homepage-total.de/php/schreiben_lesen.php
// jeden Monat ein neues Log:
$monat = date("ym");
$logfile = 'admin/mp3log_'.$monat.'.txt';
$inhalt = file_get_contents($logfile);

if (phpversion() >= '5.0.0') {
	file_put_contents($logfile, $inhalt .= "$zeit | $titel\n"); 
	

} elseif (phpversion() >= '4.3.0') {

	if (!$handle = fopen($logfile, 'a')) {
	echo "Cannot open file ($logfile)";
	exit;
	}

	if (fwrite($handle, $inhalt) === FALSE) {
	echo "Cannot write to file ($logfile)";
	exit;
	}

	fclose($handle);

} else {
	echo "<p>Dieses Script erfordert PHP Version 4.3.0 oder h&ouml;her!<br />";
	echo "auf Deinem Server l&auml;uft aber PHP Version ".phpversion().".</p>";
	exit();
}


?>

