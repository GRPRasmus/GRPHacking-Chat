<?php

// Das file zum Saubermachen:
@include("chat_config.php");

/* strpos that takes an array of values to match against a string
 * note the stupid argument order (to match strpos)
 */
function strpos_arr($haystack, $needle) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $what) {
        if((@$pos = strpos($haystack, $what))!==false) return $pos;
    }
    return false;
}

$clean_dir = 'rooms/';
$logs_dir = 'logs/';
//$anzahl_msg = $sav_msg;
$anzahl_msg = $anz_msg * 2;
// if ($anzahl_msg < 60) $anzahl_msg = 60;

$log_dir=opendir($clean_dir);

while ($file = readdir ($log_dir)) {
	if($file != "."
		&& $file != ".."
			&& $file != ".htaccess"
				&& $file != ".htusers"
					&& $file != ".htpasswd"	
	) {

		// zuerst große files kürzen:
		$oldlines = file($clean_dir.$file);

		if(count($oldlines) > $anzahl_msg && strpos($file,"_log") === false) { 
			$lines = array_slice($oldlines, -(floor($anzahl_msg / 2)));
			$lines = join($lines);
			$f = fopen($clean_dir.$file, "w");
			flock($f,LOCK_EX);
			fwrite($f, $lines);
			flock($f,LOCK_UN);	// Warning: flock(): 8 is not a valid stream resource is weg, wenn flock vor fclose
			fclose($f);

			// und jetzt die Protokolldatei schreiben, wenn files gekürzt werden:
			if (isset($logfile) && $logfile == "on") {
				$newlines = array_slice($oldlines, 0, -(floor($anzahl_msg / 2)));

				foreach($newlines as $oeftla) {
					if (strpos($oeftla,"approve") === false && strpos($oeftla,"Chatbot") === false) $tolog[] = $oeftla;
				}

				$newlines = join($tolog);
				// $newlines = join($newlines);

				// jetzt rel. img Pfade fürs Archiv anpassen:
				$newlines = str_replace("smileys/","../smileys/",$newlines);
				$newlines = str_replace("smileys2/","../smileys2/",$newlines);
				$newlines = str_replace("smileys3/","../smileys3/",$newlines);
				$newlines = str_replace("upload/","../upload/",$newlines);
				$newlines = str_replace("img/","../img/",$newlines);
				$newlines = str_replace("profile/","../profile/",$newlines);
				//$newlines = str_replace("phpThumb.php?src=../","../phpThumb.php?src=",$newlines);
				$newlines = str_replace("wmk.php?pic=","",$newlines);
						
				$newlines = str_replace("tn_../upload/","../tn_upload/",$newlines);
	                  
				// $suchmuster = '/(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/i';
				// $ersetzung = 'xxx.xxx.xxx.xxx';
				// $newlines = preg_replace($suchmuster, $ersetzung, $newlines);

				$newlines = preg_replace('~(\d+)\.(\d+)\.(\d+)\.(\d+)~', "$1.$2.$3.x", $newlines);

				$fprot = fopen($logs_dir.$file."_log", "a");
				flock($fprot,LOCK_EX);
				fwrite($fprot, $newlines);
				flock($fprot,LOCK_UN);
				fclose($fprot);
			}
		}
	}
}
closedir($log_dir);



$log_dir=opendir($clean_dir);
while ($file = readdir ($log_dir)) {

	$filealter = time()-filemtime($clean_dir.$file);

	// erst mal leere Räume löschen:
	if(strpos($file,"_pr") !== false  && $filealter >= 60*3 && filesize($clean_dir.$file) == 0) {
		unlink($clean_dir.$file);
	}

	// und jetzt alte files zum Löschen kennzeichnen:
	// öffentliche Räume:
	if($file != "."
		&& $file != ".."
			&& $file != ".htaccess"
				&& $file != ".htusers"
					&& $file != ".htpasswd"	
						&& $file != "Standard"
							&& $file != "Offline"
								&& $file != "Flirtchat"
									&& $file != "Lobby"
			 
										&& strpos($file,"_pr") === false
											&& strpos($file,"_log") === false
	&& $filealter >= 60*60*$clean){

		// damit keine Inhalte in falsche Logs geschrieben werden:
		$contents = "";
		$lines = "";
		$tolog =array();

		// Archivieren von nicht_pr vor dem automatischen Löschen:
		if (isset($logfile) && $logfile == "on") {

			$handle = fopen ($clean_dir.$file, "r");
			$contents = fread ($handle, filesize ($clean_dir.$file));
			fclose ($handle);
			$lines = explode("\n",$contents);

			foreach($lines as $oeftlb) {
				if (strpos($oeftlb,"approve") === false && strpos($oeftlb,"Chatbot") === false) $tolog[] = $oeftlb;
			}
			$contents = implode("\n",$tolog);

			// jetzt rel. img Pfade fürs Archiv anpassen:
			$contents = str_replace("smileys/","../smileys/",$contents);
			$contents = str_replace("smileys2/","../smileys2/",$contents);
			$contents = str_replace("smileys3/","../smileys3/",$contents);
			$contents = str_replace("upload/","../upload/",$contents);
			$contents = str_replace("img/","../img/",$contents);
			//$contents = str_replace("phpThumb.php?src=../","../phpThumb.php?src=",$contents);
			$contents = str_replace("wmk.php?pic=","",$contents);
				  
			$contents = str_replace("tn_../upload/","../tn_upload/",$contents);
			$contents = str_replace("popprof.php","../popprof.php",$contents);
 
			// $suchmuster = '/(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/i';
			// $ersetzung = 'xxx.xxx.xxx.xxx';
			// $contents = preg_replace($suchmuster, $ersetzung, $contents);

			$contents = preg_replace('~(\d+)\.(\d+)\.(\d+)\.(\d+)~', "$1.$2.$3.x", $contents);
 				  

			$fprot = fopen($logs_dir.$file."_log", "a");
			flock($fprot,LOCK_EX);
			fwrite($fprot, $contents);
			flock($fprot,LOCK_UN);
			fclose($fprot);
		}
		$array[] = $file;
	}
	// private Räume:
	if(strpos($file,"_pr") !== false && $filealter >= 60*60*$clean_priv){

		// damit keine Inhalte in falsche Logs geschrieben werden:
		$contents = "";
		$lines = "";
		$tolog =array();
            
		// Archivieren von _pr vor dem automatischen Löschen:
		if (isset($logfile) && $logfile == "on") {

			$handle = fopen ($clean_dir.$file, "r");
			$contents = fread ($handle, filesize ($clean_dir.$file));
			fclose ($handle);
			$lines = explode("\n",$contents);

			foreach($lines as $oeftlc) {
				if (strpos($oeftlc,"approve") === false && strpos($oeftlc,"Chatbot") === false) $tolog[] = $oeftlc;
			}
			$contents = implode("\n",$tolog);
                  
			// jetzt rel. img Pfade fürs Archiv anpassen:
			$contents = str_replace("smileys/","../smileys/",$contents);
			$contents = str_replace("smileys2/","../smileys2/",$contents);
			$contents = str_replace("smileys3/","../smileys3/",$contents);
			$contents = str_replace("upload/","../upload/",$contents);
			$contents = str_replace("img/","../img/",$contents);
			$contents = str_replace("profile/","../profile/",$contents);
			//$contents = str_replace("phpThumb.php?src=../","../phpThumb.php?src=",$contents);
			$contents = str_replace("wmk.php?pic=","",$contents);
				  
			$contents = str_replace("tn_../upload/","../tn_upload/",$contents);
			$contents = str_replace("popprof.php","../popprof.php",$contents);

			// $suchmuster = '/(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/i';
			// $ersetzung = 'xxx.xxx.xxx.xxx';
			// $contents = preg_replace($suchmuster, $ersetzung, $contents);
				  
			$contents = preg_replace('~(\d+)\.(\d+)\.(\d+)\.(\d+)~', "$1.$2.$3.x", $contents);

			$fprot = fopen($logs_dir.$file."_log", "a");
			flock($fprot,LOCK_EX);
			fwrite($fprot, $contents);
			flock($fprot,LOCK_UN);
			fclose($fprot);

		}
		$array[] = $file;
	}

}
closedir($log_dir);


if(isset($array)) {
	$del_file = $array;
} else {
	$del_file = "";
}

// array durchlaufen und löschen (if fileexist):
if ($del_file != "") {
	$anz = count($del_file);
	for($i = 0; $i < count($del_file); $i++){
		if(file_exists($clean_dir.$del_file[$i])) {
			//echo "$clean_dir$del_file[$i]<br/>";
			unlink($clean_dir.$del_file[$i]);
		}
	}
}



// die ban.txt bereinigen, abgelaufene bans loeschen:
$ban_dateiname = "user/ban.txt"; // Name der Datei
if (file_exists($ban_dateiname)) {
	$change1 = false;
	$newline = "";
	$lines = file($ban_dateiname);

	foreach($lines as $key => $val) {

		$teile = explode("****", $val);
		$teile1 = $teile[1];
		$teile2 = explode("++++", $teile1);
		$unix_time = $teile2[0];
	
		if (time() < $unix_time) {
			$newline .= $val;		 
		} else {
			$change1 = true; // eine Zeile wurde geloescht
		}
	}

	if ($change1 === true) { // Datei nur neu schreiben, wenn mindestens eine Zeile geloescht wurde
		$handler = fopen($ban_dateiname, "w");
		fwrite($handler , $newline);
		fclose($handler);
	}
}

// die maulkorb.txt bereinigen, abgelaufene loeschen:
$maul_dateiname = "user/maulkorb.txt"; // Name der Datei
if (file_exists($maul_dateiname)) {
	$change2 = false;
	$maul_newline = "";
	$lines = file($maul_dateiname);

	foreach($lines as $key => $val) {

		$teile = explode("****", $val);
		$teile1 = $teile[1];
		$teile2 = explode("++++", $teile1);
		$unix_time = $teile2[0];
	
		if (time() < $unix_time) {
			$maul_newline .= $val;		 
		} else {
			$change2 = true; // eine Zeile wurde geloescht
		}
	}

	if ($change2 === true) { // Datei nur neu schreiben, wenn mindestens eine Zeile geloescht wurde
		$maul_handler = fopen($maul_dateiname, "w");
		fwrite($maul_handler , $maul_newline);
		fclose($maul_handler);
	}
}




// alte user online files löschen:
$clean_dir2 = 'user/';
if ($handle = opendir($clean_dir2)) {
	// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
	// Löschen von unser online files vermutlich nicht (so häufig) erforderlich
	while (false !== ($file = readdir($handle))) {
		$filealter = time()-filemtime($clean_dir2.$file);
		if(strpos($file,"p_") == 1 && $filealter >= 10){
			$array[] = $file;
		}
	}
		
	closedir($handle);



}


if(isset($array)) {
	$del_file = $array;
} else {
	$del_file = "";
}


// array durchlaufen und löschen (if fileexist):
if ($del_file != "") {
	$anz = count($del_file);
	for($i = 0; $i < count($del_file); $i++){
		if(file_exists($clean_dir2.$del_file[$i])) {
			unlink($clean_dir2.$del_file[$i]);
		}
	}
}


// alte upload files löschen:
//if (!isset($upload_clean)) {$upload_clean = 14;} 
$clean_dir3 = 'upload/';


// hier files nach $max_upload_files loeschen
$files = glob( 'upload/*.*' );

// Sort files by modified time, latest to earliest
// Use SORT_ASC in place of SORT_DESC for earliest to latest
array_multisort(
array_map( 'filemtime', $files ),
SORT_NUMERIC,
SORT_DESC,
$files
);


$files = str_replace ($clean_dir3,'',$files);

$p = 0;
$max_upload_files = 200;
foreach($files as $key => $file) {
	if(	$file != "."
        && $file != ".."
		&& $file != ".htaccess"
		&& $file != "_htaccess"
		&& $file != ".htusers"
		&& $file != ".htpasswd"	
	    && $file != "handler.php"
	    && $file != "handler_gif.php"
	    && $file != "handler_png.php"
	    && $file != "handler_bmp.php"
	    && strpos($file,".mp3") === false
	){
		if ($p >= $max_upload_files) {
			//echo $file.'<br>';
			$upload_array[] = $file;
		}
	$p ++;
	}
}

$q = 0;
$max_upload_mp3 = 20;
foreach($files as $key => $file) {
	if( strpos($file,".mp3") !== false){
		if ($q >= $max_upload_mp3) {
			//echo $file.'<br>';
			$upload_array[] = $file;
		}
	$q ++;
	}
}

if(isset($upload_array)) {
	$del_file = $upload_array;
} else {
	$del_file = "";
}
// array durchlaufen und löschen (if fileexist):
if ($del_file != "") {
	$anz = count($del_file);
	for($i = 0; $i < count($del_file); $i++){
		if(file_exists($clean_dir3.$del_file[$i])) {
			unlink($clean_dir3.$del_file[$i]);
		}
	}
}


// alte tn_upload files  löschen:
//if (!isset($upload_clean)) {$upload_clean = 14;} 
$clean_dir4 = 'tn_upload/';


// hier files nach $max_upload_files loeschen
$files = glob( 'tn_upload/*.*' );

// Sort files by modified time, latest to earliest
// Use SORT_ASC in place of SORT_DESC for earliest to latest
array_multisort(
array_map( 'filemtime', $files ),
SORT_NUMERIC,
SORT_DESC,
$files
);


$files = str_replace ($clean_dir4,'',$files);

$p = 0;
$max_upload_files = 200;
foreach($files as $key => $file) {
	if(	$file != "."
        && $file != ".."
		&& $file != ".htaccess"
		&& $file != "_htaccess"
		&& $file != ".htusers"
		&& $file != ".htpasswd"	
	    && $file != "handler.php"
	    && $file != "handler_gif.php"
	    && $file != "handler_png.php"
	    && $file != "handler_bmp.php"
	){
		if ($p >= $max_upload_files) {
			//echo $file.'<br>';
			$upload_array2[] = $file;
		}
	$p ++;
	}
}


if(isset($upload_array2)) {
	$del_file = $upload_array2;
} else {
	$del_file = "";
}
// array durchlaufen und loeschen (if fileexist):
if ($del_file != "") {
	$anz = count($del_file);
	for($i = 0; $i < count($del_file); $i++){
		if(file_exists($clean_dir4.$del_file[$i])) {
			unlink($clean_dir4.$del_file[$i]);
		}
	}
}




// profile files löschen, wenn nicht (mehr) in der user.txt:
$clean_dir5 = 'profile/';
if ($handle = opendir($clean_dir5)) {
	// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
	while (false !== ($file = readdir($handle))) {

        // nur registrierte User
        $in_regdb = false;
        if (file_exists("user/user.txt")) {
        	$d1 = file("user/user.txt");
        	foreach ($d1 as $c) {
        		$part1 = explode("****",$c);
        		if ($part1[0] == $file) {
					$in_regdb = true;
        		} elseif ($part1[0].'.jpg' == $file) {
					$in_regdb = true;
        		} elseif ($part1[0].'.gif' == $file) {
					$in_regdb = true;
                }
        	}
        }

		// if(($in_regdb !== true 	|| filesize($clean_dir5.$file) < 160)
		if(($in_regdb !== true )
			&& $file != "."
			&& $file != ".."
			&& $file != ".htaccess"
			&& $file != ".htusers"
			&& $file != ".htpasswd"
			// && strpos($file,"_inv.txt") === false // flirtfiles anders behandeln
		){$profile_array[] = $file;}
	}
	closedir($handle);
}
if(isset($profile_array)) {
	$del5_file = $profile_array;
} else {
	$del5_file = "";
}
// array durchlaufen und löschen (if fileexist):
if ($del5_file != "") {
	$anz = count($del5_file);
	for($i = 0; $i < count($del5_file); $i++){
		if(file_exists($clean_dir5.$del5_file[$i])) {
			unlink($clean_dir5.$del5_file[$i]);
		}
	}
}



// alte Flirt-Einladungen löschen, wenn _pr älter als clean_priv:
//
// $search_dir = 'rooms/';
// if ($handle = opendir($search_dir)) {
// 	// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
// 	while (false !== ($file = readdir($handle))) {
// 		$filealter = time()-filemtime($search_dir.$file);
// 		if (isset($clean_priv)) {$clean = 3600 * 48 * 3 * $clean_priv;} else {$clean = 3600 * 24 * 3;}
// 		if($filealter >=
// 			$clean
// 			&& $file != "."
// 			&& $file != ".."
// 			&& $file != ".htaccess"
// 			&& $file != ".htusers"
// 			&& $file != ".htpasswd"
// 			&& strpos($file,'_pr') !== false && $file[0] == 'P'
// 		){
// 			$file = str_replace('P','',$file);
// 			$file = str_replace('_pr','',$file);
// 			$cache_array3[] = $file;
// 		}
// 	}
//
// 	closedir($handle);
// }
//
// if(isset($cache_array3)) {
// 	$del_file3 = $cache_array3;
// } else {
// 	$del_file3 = "";
// }
//
//
// $clean_dir4 = 'profile/';
// if ($handle4 = opendir($clean_dir4)) {
// 	while (false !== ($file4 = readdir($handle4))) {
//
// 		if (strpos ($file4,'_inv.txt') !== false && strpos_arr($file4,$del_file3) ) {
// 			unlink($clean_dir4.$file4);
// 		}
// 	}
// 	closedir($handle4);
//
// }
//
// // natürlich auch noch das _pr selbst löschen:
// $clean_dir7 = 'rooms/';
// if ($handle7 = opendir($clean_dir7)) {
// 	while (false !== ($file7 = readdir($handle7))) {
//
// 		if (strpos ($file7,'_pr') !== false && strpos_arr($file7,$del_file3) ) {
// 			unlink($clean_dir7.$file7);
// 		}
// 	}
// 	closedir($handle7);
//
// }
//
//
//
// // Flirt-Einladungen löschen, wenn kein _pr:
// $clean_dir6 = 'profile/';
// if ($handle6 = opendir($clean_dir6)) {
// 	while (false !== ($file = readdir($handle6))) {
//
// 		if( strpos($file,"_inv.txt") !== false && (time()-filemtime($clean_dir6.$file) > 100 )){
//
// 			$file2 = str_replace('_inv.txt','',$file);
// 			$tmp = explode('___',$file2);
//
// 			if (!file_exists('rooms/P'.$tmp[1].'_pr')) {
// 				unlink('profile/'.$file);
// 			}
//
// 		}
// 	}
// }
// closedir($handle6);

// Ende Flirt


// grosse Archivdateien umbenennen, damit ein neues Archiv geschrieben wird:
// und nach 90 Tagen endgültig löschen:
if ($handle = opendir($logs_dir)) {
	while (false !== ($file = readdir($handle))) {

     		$filealter = time()-filemtime($logs_dir.$file);
       	if($file != "."
               && $file != ".."
	         && $file != ".htaccess"
	         && $file != ".htusers"
			 && $file != ".htpasswd"	
               && $file != "reader.php"
               && $file != "log_list.php"
               && $file != "imgalt"
               && $filealter >= 60*60*24*90){
		      	unlink($logs_dir.$file);
		}

		$filegroesse = @filesize($logs_dir.$file );
		if($filegroesse >= 1000000 && strpos($file,"_bak") === false){
                 rename ( $logs_dir.$file, $logs_dir.$file.time().'_bak' );
		}
	}

	closedir($handle);
}


//einmalig abfragen, ob getimagesize vom Server erlaubt:
//if (!file_exists("no_fp.php") && !file_exists("fp.php")) {
if (!file_exists("fp.txt") || file_get_contents("fp.txt") == "null") {
      $is_fp = @fsockopen('www.google.de', 80, $errno, $errmsg, 2);
      if ($is_fp) {
      	$f7 = @fopen("fp.txt", "w");
      	@fwrite($f7,"yes");
      	@fclose($f7);
      } else {
      	$f7 = @fopen("fp.txt", "w");
      	@fwrite($f7,"no");
      	@fclose($f7);
      }
}


?>