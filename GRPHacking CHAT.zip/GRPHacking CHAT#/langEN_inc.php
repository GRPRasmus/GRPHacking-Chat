<?php
@include("chat_config.php");

########### chat.php: ##############
define("_BLINDHELP",  "Help for the visually impaired");
define("_HELP",       "Help");
define("_HELPTITLE",  "Chat Help");
define("_MESSAGE",    "your message");
define("_NICK",       "nickname");
define("_SUBMIT",     "Submit");
define("_PR",         "Now you're in a private room ");
define("_ROOM",       "(Private) room");
define("_YOUROOM",    "You're in room ");
define("_NOROOM",     "<em style=\"color:red\">This room doesn't exist!</em><br />Please choose one of the public rooms in the list." );
define("_NEWROOM",    "Enter an existing room, or create a private room ");
define("_COMEIN",     "Enter");
define("_OPT",        "Display&nbsp;Options <dfn>(click to open)</dfn>");
define("_OPT_TITLE",   "Select Display Options");


define("_FONTSIZE",   "Font size");
define("_REVERSE",    "Input&nbsp;Field&nbsp;top&nbsp;");
define("_TEXTAREA",   "Input&nbsp;multiline");

define("_DATEOFF",    "hide&nbsp;timeline date&nbsp;&nbsp;");
define("_TIMEOFF",    "hide&nbsp;timeline time&nbsp;&nbsp;");
define("_SOUNDOFF",   "sounds&nbsp;off&nbsp;&nbsp;");
define("_COLOROFF",   "high&nbsp;contrast");
define("_COLOR2OFF",   "Colors&nbsp;off&nbsp;");
define("_ONLINEOFF",  "hide&nbsp;online time&nbsp;");
define("_HOUROFF",    "hide&nbsp;clock&nbsp;");
define("_NICKCOLOR",  "Nick color");
define("_NICKCOLORLABEL",          "Choose color for your messages");
define("_COL1",       "blue");
define("_COL2",       "red");
define("_COL3",       "pink");
define("_COL9",       "green");
define("_COL4",       "gold");
define("_COL5",       "green");
define("_COL6",       "turquoise");
define("_COL7",       "brown");
define("_COL8",       "dark grey");
define("_SKIN",       "Style");
define("_SKINS",      "Skin");
define("_SKINLABEL",  "Choose Skin");
define("_ONTIME",     "Online Time");
define("_REALTIME",   "Time");
define("_NOJS",       "Please enable Javascript to use the chat");
define("_NOCOOKIE",   "Please allow cookies and reload this page.");
define("_SMIL",       "Insert Smilies");
define("_WHERE",      "Where am I?");
define("_REGUSER",    "Your registered nickname is ");
define("_UPLOADLEGEND",    "File upload");
define("_UPLOADLABEL",    "press SPACE to open the search dialog");
define("_YOUR_IP",    "Your IP: ");
define("_NO_MP3",     "No hotlinking of mp3");
define("_DOWNLOAD",    "Download");
define("_HIDE_PICS",    " Hide pics &amp; smileys");
define("_SMALL_PICS",    " Show images smaller");
define("_HIDE_UO",    " Hide user online");
define("_HIDE_AVATAR",    " Hide avatars");
define("_SHOW_POPUP",    " Enable Popup");
define("_STATION",    "Choose Radio Station");
define("_AWAY1",    "You‘re now temporarily disconnected");
define("_AWAY2",    "until you close this message.");
define("_SHOW_UP_PLAYER",    "Show Player [Uploads]");
define("_SHOW_HTML5_PLAYER",    "Show Radio [noFlash]");

define("_TIT_REVERSE", "Das Eingabefeld oberhalb des Nachrichtenfensters platzieren, und die Nachrichten in umgekehrter Reihenfolge ordnen: Neueste Nachricht oben");
define("_TIT_TEXTAREA", "Das Eingabefeld mehrzeilig darstellen. Das mehrzeilige Eingabefeld kann durch Ziehen mit der Maus an der rechten unteren Ecke in der Größe angepasst werden.");
define("_TIT_DATEOFF", "Die Anzeige des Datums im Nachrichtenfenster ausblenden.");
define("_TIT_TIMEOFF", "Die Anzeige der Uhrzeit im Nachrichtenfenster ausblenden.");
define("_TIT_HIDE_PICS", "Die Anzeige aller Bilder, auch Smileys und Avatare, verbergen.");
define("_TIT_SMALL_PICS", "Alle Bilder, Smileys und Videos kleiner anzeigen.");
define("_TIT_HIDE_UO", "User-Anzeige verbergen, wenn sie zu sehr nervt");
define("_TIT_HIDE_AVATAR", "Die Anzeige von Avataren verbergen");
define("_TIT_SOUNDOFF", "Alle Benachrichtigungssounds deaktiveren");
define("_TIT_SHOW_POPUP", "Zeigt den Eingang einer Meldung in einem Popup an. Nützlich z. B. in lauter Umgebung. (Muss entsprechend konfiguriert sein.)");
define("_TIT_COLOROFF", "Alle Schriften fett anzeigen");
define("_TIT_COLOR2OFF", "Alle Nachrichten ohne farbliche Unterschiede zeigen");
define("_TIT_HOUROFF", "Die Anzeige der aktuellen Uhrzeit (unterhalb des Skinwählers) auschalten");
define("_TIT_ONLINEOFF", "Die Anzeige der online verbrachten Zeit ausschalten");
define("_TIT_SHOW_UP_PLAYER", "Zeigt einen Player mit den zuletzt hochgeladenen MP3");
define("_TIT_SHOW_HTML5_PLAYER", "Zeigt einen Radioplayer");


########## chat_inc.php: ###########
define("_ALLROOMS",   "Rooms");
define("_PUBLROOMS",  "Public rooms");
define("_ACTROOM",    "You are in room");
define("_YOURINROOM", "You are in room");
//define("_ALONE",      "... and, alas!, alone. ");
define("_ALONE",      "... and nothin' doin' here.&nbsp;<img src=\"img/sad.gif\" alt=\"\" height=\"12\" width=\"12\"> ");
define("_GUESTSLOGIN"," Users in the shoutbox");
define("_GUESTLOGIN", " User in the shoutbox");
define("_BACKTOSTD",  "back to room");
define("_INROOM",     "Users online");
define("_LNKNEWWIN",  "Link will open new window");
define("_INVITEPR",   "Please click here to enter a private room:");
define("_INVITEADVISE",   "Warning! This invitation is public. If you don't want that, then choose another name for the private room, and resend this invitation as private message (whispering).");
define("_RENAME",     "calls him/herself now");

if (date('G') < 10) {
   $hourgreeting = 'Good morning,';
} elseif (date('G') < 18) {
   $hourgreeting = 'Have a nice day,';
} else {
   $hourgreeting = 'Good evening,';
}
define("_NEWUSER", "entered the chatroom");

define("_DBLUSER",    " A user with this nick is (or was) already online.");
//define("_ADMINNICK",  "This nick is for the admin only!");
//define("_RESERVED",   "Sorry, this is a reserved nick!");
define("_WHISPER",    "whispering");
define("_TO",         " to ");
define("_APPLY",      "apply");
define("_CLEAR",      "emptied this room.");
define("_LOGIN",      "Hello Guest,<br />please enter a nickname and submit your first message to join the chat.");
define("_HOURS",      "");
define("_WHISPERTO",  "whisper to ");
define("_NOCHEAT",    " Don't whisper and change your nick at the same time!");
define("_USERIMG",    "user submitted image");
define("_FORMIMG",    "no [img][/img] here. To show an image, just enter the URL.");
define("_FORMURL",    "no code here, just enter the URL.");
define("_OFFLINE",    "This room is temporarily closed ");

define("_CLOSED",    "This room is temporarily closed. Opening hours: ");
define("_INTERN",    "This chat room is for internal use only. Please contact the administrator if necessary. ");

define("_NOMOD",      " The moderation feature is not available.");
define("_NOLINK",    " Links are not allowed here! ");
define("_NOIMGLINK",    " No external images allowed! ");
define("_NOTOPIC",    " Topic not allowed in private rooms! ");

define("_ROOM_NAME1",    "Error! Room names must not contain blanks. Delete or rename in dir /rooms.");
define("_ROOM_NAME2",    "Error! Room names must begin with a capital letter.  Delete or rename in dir /rooms.");
define("_ROOM_NAME3",    "Error! Invalid character in a room name. Delete or rename in dir /rooms.");

define("_WAKEUP",    "Hey! Wake Up! ");
define("_STOPMSG",    "has temporarily stopped the refresh.");


###### Chatbot: #########
define("_HELLO",      "Hello ");
define("_KBBROKE",    ": what's wrong? Why are you consistently typing the same character!<br /> Is your keybord broken?<br />Btw: Only you see this message. Other users are not beeing disturbed by it.");
define("_FLOOD",      ": Cool, your typing very quickly.<br />But flooding is blocked here! For ".$bantime."&nbsp;minute(s) actually. (Sorry, but it's configurable.)<br />Btw: Only you see this message. Other users are not beeing disturbed by it.");
define("_NICKIRC",    "Sorry, this is no IRC. To change your nickname you must logout and login anew.");
define("_WHOIRC",     "Sorry, this is no IRC. To find out who's online, look at the top right corner. And if it says: \"... on your own\", your on your own.");
define("_MSGIRC",     "Sorry, this is no IRC. To whisper click a user name in the list.");
define("_HELPIRC",    "here is <a href=\"helpEN.php\">Help</a> - and here <a href=\"http://webdesign.weisshart.de/chat-faq.php\">FAQ (german)</a>");
define("_README",     "read the <a href=\"http://webdesign.weisshart.de/chat/readme.txt\">readme.txt</a>");
define("_LICENCE",    "Want to get rid of the credit link? <a href=\"http://webdesign.weisshart.de/chat-lizenz.php\">you're welcome!</a>");

define("_PROFIL",    "Your Profile");
define("_XPROFIL",    "<a href=\"profil.php\">Edit Profile</a> (registerd users only)");
define("_SHOW_PROFIL",    "registered user only may see profiles.");

define("_LISTIRC",    "Entering rooms is different here from IRC: <a href=\"help.php#roomhelp\">Help on rooms</a>");
define("_AGEQUEST",   " how old ");
define("_AGE",        "Hi, I'm your chatbot, and I am ");
define("_AGE2",       " seconds old.");
define("_GENDERQUEST"," m or f ");
define("_GENDER",     "Hi, I'm your chatbot, and I'm a <a href=\"http://en.wikipedia.org/wiki/Hermaphrodite\">Hermaphrodite.</a>");
define("_SORRY",      "Sorry");
define("_ADMINONLY",  ", this is an admin-only command");
define("_MUZZLED",    ", du hast jetzt mal kurz Sendepause. Bitte nutze die Zeit, um &uuml;ber dein Verhalten nachzudenken.");
define("_ERASE",      ", only the admin may erase messages.");
define("_APPROVE",     ", only the admin can appove messages.");
define("_YTERROR",      " A YouTube Link must not contain any additional text. ");


########## chat_js.php: ###########
define("_NICKNOTALLOWED",   "This nick is not allowed here!");
define("_CHARNOTALLOWED",   "This nick containes forbidden characters!");
define("_CHARNOTALLOWEDMSG",   "Your message containes forbidden characters!");
define("_ROOMNOTALLOWED",   "This roomname containes forbidden characters!");
define("_TIMEOUT",   "..... Chat disconnected (timeout) \\n\\nHey, this is not a public calefactory, this is a chat!");
define("_NOCOOKIEALERT",   "Please allow cookies to get rid of this alert and the welcome message.");
define("_JSADMINONLY",  "This is an admin-only command!");
define("_NOHTML",  "No HTML allowed here!");

define("_JSERASE",      "Want to whisper? Just click one of the users online (top right!).\\n\\nTo adress any particular user, click a name in the message window.");
define("_JSIRC",      "Sorry, this is no IRC!\\nRefer to Help for available commands.");
define("_DELROOM",      "Are you shure? Want to delete that room?\\n\\nCaution! The current room can't be deleted.");
define("_WHISPERNOTALLOWED",      "Whispering only to/from admin");
define("_WHISPERROOMSNOTALLOWED",      "Only admin may open private rooms");
define("_READONLY",      "Guests are not allowed to post.\\n\\nPlease log out and log in with your registered nick,\\nor register first.");
define("_CHARREP",      "Your keyboard is seized!\\nPlease check your input.");
define("_MULTURL",      "Multiple links/uploads not allowed.");
define("_NOBLANK",      "No blanks allowed in file names.");
define("_UPPERCASE",      "Is your keyboard seized?\\nIt seems to have only uppercase letters.");
define("_AWAY",    "You‘re now temporarily disconnected\\nuntil you close this message.");
define("_AWAY_MSG",    "is \bafk");
define("_RE_MSG",    "re");

define("_WARM_MSG",    "retired to the calefactory");
define("_STOP_MSG",  "Automatic refreshs are now disabled until you type \/go, or reload the page manually.");

########## upa.php ################
if (!isset($gifsize)) {$gifsize = 64;}

define("_UPDONE",     "Upload&nbsp;completed.<br />Click&nbsp;here&nbsp;to&nbsp;insert&nbsp;your&nbsp;picture.");
define("_JPGERR",     "jpeg&nbsp;corrupt");
define("_TYPEERR",    "Wrong&nbsp;file&nbsp;type.&nbsp;Allowed:&nbsp;jpg,&nbsp;png,&nbsp;bmp,&nbsp;gif,&nbsp;or&nbsp;mp3.");
define("_SIZEERR",    "File&nbsp;too&nbsp;big");
define("_SIZEERR1",    "File&nbsp;too&nbsp;big;, max.&nbsp;");
define("_SIZEERR2",    "&nbsp;kB&nbsp;jpg/png/mp3&nbsp;and&nbsp;$gifsize&nbsp;kB&nbsp;gif&nbsp;allowed.");
define("_UPERR",      "Upload&nbsp;error.");
define("_MP3ADMINONLY",      "mp3&nbsp;upoad&nbsp;Admin&nbsp;only!");
define("_SWFADMINONLY",      "Flash&nbsp;upoad&nbsp;Admin&nbsp;only!");

######### usr_smileys.php #########
define("_USR_SMILEY1",      "Just click a smiley to insert it into the message field, SUBMIT or ENTER<br />Admin: More Smileys? Simply add file to directory ");
define("_USR_SMILEY2",      " ... done! - or /add URL in the message field.<br />Or, even quicker: /add and drag&nbsp;&amp;&nbsp;drop.<br />No blanks allowed in file names.");

######## login.php ###
define("_LOGIN_H1",     "Chat Login");

define("_LOGIN_FORM",     "Credentials");
define("_LOGIN_FORM1",     "Register");
define("_LOGIN_FORM2",     "Wrong password");
define("_LOGIN_FORM3",     "This nickname is unregistered");
define("_LOGIN_FORM4",     "Save credentials (cookie)");


define("_LOGIN_FORM_FORUM1",     "Please enter credentials");
define("_LOGIN_FORM_FORUM2",     "This nickname is taken");
define("_LOGIN_FORM_FORUM3",     "This nickname is not allowed");
define("_LOGIN_FORM_FORUM4",     "Forbidden characters in nickname");

define("_LOGIN_GUEST",     "Login as guest");
define("_LOGIN_GUEST2",     "Nickname:");
define("_LOGIN_GUEST3",     "Password:");
define("_LOGIN_GUEST4",     "With a guest login you're set to chat.");
define("_LOGIN_GUEST5",     "Note: With a guest login you're not allowed to write.<br />Please <a href='reg.php'>register</a> if you want to participate.");

define("_TO_REG",     "Register to protect your nickname");
define("_TO_REG2",     " and enable profiles");
define("_TO_REG3",     "Registration");

define("_WHOSON",     "who's online? (Popup)");
define("_NO_REG",	"Leave password field blank to enter w/o registration.<br />or <br />Nickname: Gast<br />Password: demo");
define("_NO_REG_NO_GUEST",	"Leave password field blank to enter w/o registration.");
define("_LOG_FORM",     "Guest login ");
define("_SEC",     "&nbsp;seconds");

define("_NOBODY",     "Sorry, there's no one in the chat room right now.");
define("_ONEUSER",    "There is only 1 user in the chatroom at the moment.");
define("_MOREUSERS1",     "There are ");
define("_MOREUSERS2",     " user in the chatroom.");

define("_SUPPORT",     " Chat support is now available.");
define("_NOSUPPORT",     " Unfortunately there is no support available in the chat at the moment.");

######## reg.php #####
define("_REG_H1",     "Chat Registration");

define("_REG_FORM",     "No nickname submitted");
define("_REG_FORM1",     "Nickname too short");
define("_REG_FORM2",     "No password submitted");
define("_REG_FORM3",     "Passwords don't match");
define("_REG_FORM4",     "Please submit a valid e-mail");
define("_REG_FORM5",     "Do not fill the following field:");
define("_REG_FORM6",     "Repeat password:");
define("_REG_FORM7",     "E-mail (not displayed):");
define("_REG_FORM8",     "E-Mail (optional, not displayed):");
define("_REG_FORM9",     "Register");
define("_REG_FORM10",     "Registration ");
define("_REG_FORM11",     "Nickname and password must not be identical ");


define("_REG_HINWEIS",     "Only letters, numbers and the underscore ( _ ) - no blanks allowed.");
define("_REG_HINWEIS1",     "Note: Password cannot be altered by user. The chat admin only can reset it.");
define("_REG_HINWEIS2",     "registrered users");
define("_REG_HINWEIS3",     "(Test registrations allowed in this demo chat room. Will be deleted without notice.)");

define("_TO_LOGIN",     "Login");

####### logout.php ####

define("_LOGOUT",     "Thank you for your visit.");
define("_LOGOUT1",     "You may close this window now.");
define("_LOGOUT2",     "Chat info page");
define("_LOGOUT3",     "has logged off");




?>