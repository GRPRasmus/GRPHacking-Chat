<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
$hoehe_ie = $hoehe * 1.05;
if (!isset($user_hoehe)) $user_hoehe = 14;
?>


/* CSS fuer Skin 8 Firebox */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, input, textarea, select {
	font-family: Verdana, Geneva, Arial, Helvetica, "Trebuchet MS", sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #343;  
}


html {
background-color: #666 !important;
/* background-image:url(img/chat_bg8.jpg);
background-repeat:repeat-x;
background-position: top;
*/
background:linear-gradient( #fff, #666);
background-attachment:fixed;
}

body {
	width: 95.1%;
    max-width:62.9em;
    margin: 0 auto;
	background:transparent !important;
}



h1 {
	font-size:1.4em;
	color:#373;		/* dies ist ein Beispiel fuer eine spezielle Schriftfarbe fuer die Ueberschrift */
	line-height:125%;
	position: relative; top: .5em;
}
h1 span {color:#373}

h2 {
	font-size: 1em;
	color:#676;
	line-height:125%;
        margin: 7px 0 4px 3px;
}
h2 a, h2 a span {color:#676;}

h3, h4, h5 {
	font-size:.8em;
	margin: 1em 0 .5em;
	line-height:125%;
}

p, ol li, #uo, #help tr  {
	font-size:.8em;
	/* margin-bottom: 2px; */
	/*line-height:1.4em;*/
}

a {color:#555;}


#farben ul li {
	display:inline;
	margin:0;
}

#addsmileys {
	margin: 3px 0 0 3px;
}

/* display-inline durch float ersetzt, wg Flackern */
#addsmileys ul li {
float:left;
padding: 0 2px;
margin: 0;
line-height: 30px;
}

/*
#addsmileys ul li.more_smileys{line-height:22px;}
#addsmileys ul li a span {vertical-align:20%;}
*/
#addsmileys ul li a:visited span {color:#f1f1f1}
#addsmileys ul li a:hover span{color: #555; background:#f1f1f1;}


ul {
	font-size:.8em;
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}



fieldset {
	clear: right;
	background: #f1f1f1;		/* die Hintergrundfarbe fuer das Chatfenster */
	margin: 0;
    padding: 8px 10px;
    border:solid 3px #ddd;
    border-radius:18px;
}


fieldset fieldset {
         background: #fafafa;	/* die Hintergrundfarbe fuer die Optionsfelder */
	 /* padding: 2px 4px 4px 3px; */
	 margin-bottom: 3px;
	 font-size:92%;
}


fieldset fieldset, #wall {
         padding: 5px;
         border:solid 2px #ccc;
         border-radius:6px;
}

* html fieldset fieldset {
         margin: 0 0 0 0;
         float:right;
         width:20%;
}


.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #888;
}
.tr {visibility:hidden}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {
	margin: 0 6px 0 0;
	height: 100%;
	width:78% !important;
}
#talk p {margin:.3em}


#wrapper {height: 90% !important;min-height:29em}

#wall {
	height: 63%;
	overflow: auto;
	margin: 0 0 7px 0;
	line-height: 1.1em;

	background-image:url(img/_nina.jpg);
	/* background-size:contain; */
	background-position: 100% 0;
	background-repeat:no-repeat;
	
	background-color: #fdfdfd;	/* die Hintergrundfarbe fuer das Nachrichtenfenster */	
	-webkit-hyphens: auto;
	-moz-hyphens: auto;
	-ms-hyphens: auto;
	hyphens: auto;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
}
/*
* html #wall { height: <?php echo $hoehe_ie ?>em; }
*/

#wall p {
        /* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 6.7em;
	text-indent: -6.7em;
	margin-bottom: 2px;
	outline:none;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#wall .whisper, #wall .at {color:red; background: yellow}

#line {
	width: 80% !important;
	min-width:80% !important;
	max-width: 80% !important;
	font-size:1em !important;
	padding: .3em .5em;
	background-color:transparent;
	margin-bottom:8px;
}
textarea#line {width:60%;height:2.5em}
#line:focus, #line:hover {background-color:#fff;}


#op {margin:3px 0}

#ton {
	width: 0;
	height: 0;
}

#uo {
      border:solid 1px #ccc;
      border-radius:4px;
      background:#fff;
      padding: 5px;
	display: inline;
	margin-top: .3em;
	<?php
           if ($chat_light != "yes" && $anz_rooms != 1) {
              // das 14 in der folgenden Zeile beeinflusst die Hoehe der user online Anzeige
 	        echo "display:block; min-height: 8em; max-height: ".($hoehe - (20 - $user_hoehe))."em; overflow-y:auto; overflow-x:hidden";
           } else {
 		  echo "line-height: 2em;";
           }
      ?>
}

html:first-child>b\ody #uo { /* Opera Hack */
      overflow: auto;
}

#uo a, #user_pro_room a {color:#343;text-decoration:none}

#uo ul, #uo ul li {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
            echo "padding:0 .1em;";
	}else{
            echo "padding:.5em;";
      }
      ?>
	font-size:100%;
	margin: 0;
}
#uo ul {
	padding: .2em 0 .5em .0em;
      line-height:1.3em;
      margin-top:4px;
}


#user_pro_room {
      padding: 3px;
  	margin: 0 0 1em 0;
      border-radius:4px;
	display:block; max-height: <?php echo $anz_rooms +3.5; ?>em; overflow-y:auto; overflow-x:hidden;
}


#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
	/*  position:relative; top:.15em; hm? */
}


#user_pro_room em:before {
	content:"\25B6\00A0";
}


dfn, .dot {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


/* der Hintergrund fuer den Admin */
/* all modern browsers, including IE9 , aeltere in ie_bg.css per cond.comm. */
.bg {background-color: rgba(240,240,240,0.5); border-radius: 4px; }



label,
select,
input {
cursor: pointer;
}


label {margin:0 0 0 3px}


#line, #handle, #room {
      /* background:#fff; */
       cursor:text;
		font-size: 100%;
}


textarea, input, select {
    /*  background:#fff; */
      margin: 0;
      padding: 4px;
      border:solid 2px #ccc;
      border-radius:6px;

}
select {
      padding: 0 0 0 3px;
      border-top-right-radius: 0;
      border-bottom-right-radius:0;
}


.button, .away {
	  padding: 2.8px 5px 2.3px 5px;
      border:solid 2px #ccc;
      border-radius:6px;
      background: #fff;
      font-weight:normal;
	  top:0;
}

.button {vertical-align:top}

.away {margin-left:0;margin-bottom: 0 !important;}


#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
      border: 0;
      background: transparent;
}

.av { width: 30px !important;}

#menu1, #menu2, #room {width:50%; font-size:1em;}
* html #menu1, * html #menu2 {width:48%}

#menu2 {margin-bottom: .3em;}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
   echo '#menu2 {width: 100%}';
   echo '* html #menu2 {width:96%}';
}
?>

<?php
if ($stil != 0) {
   echo '#menu1 {width: 100%}';
   echo '* html #menu1 {width:96%}';
}
?>

#opt2 {clear:left; padding-top: 5px}
.opt {
     margin: 0 0 2px 0;
     padding: 0;
}
* html .opt {margin: 0 0 -4px 0;}
*+html .opt {margin: 0 0 -4px 0;}


.uolist {display:none;}
#upload {
	clear:left;
	margin:12px 5px 3px 0; 
	background: #f1f1f1;
	min-height:2em !important;
}
#upload legend {background-color: #F1F1F1;border-radius:1em;padding:3px;border-top:2px solid #ccc}

margin: 0 0 0 -5px !important;
#upload div img {margin-left:7px}
#upload_2 {padding: 2px;}



.helplinks{margin:10px;}
.helplinks p a{margin-bottom: 5px;}

#logout a:link, 
#logout a:visited, 
.logout a:link,
.logout a:visited,
#toggle_radios {
   /* zoom: 1;  ie7 hack  */
   
   margin: 5px 0;
   text-align:center;
   padding: 2px 0 4px 0;
   border:solid 2px;
   border-radius:2em;
   border:solid 1px #ccc;
   display:block;
   text-decoration:none;
   
   /* background: #999;
   background: -webkit-gradient(linear, left top, left bottom, from(#ccc), to(#444));
   background: -moz-linear-gradient(top,  #ccc,  #444);
   color:#fff;

   font-weight:normal !important;
   text-shadow: 0 1px 1px rgba(0,0,0,.6); */
}

#logout a:hover,
#logout a:focus,
#logout a:active, 
.logout a:hover,
.logout a:focus,
.logout a:active,
a.away:hover,
a.away:focus,
a.away:active,
.button:hover, 
.button:focus,
.button:active,
#toggle_radios:hover,
#toggle_radios:focus {
  color:#333 !important;
  background: #ccc;
  outline:none;
}


#Uhr_Anzeige2 {margin-left: .2em;}

/* falls nur 1 Raum, folgende Zeile entkommentieren: */
/* #user_pro_room {display:none} */

#file {margin-top: 5px; color:transparent; background-color:transparent; border:0; font-size: .85em}

/* #ton, #mp3 {clear:left; width: 80%; font-size: .8em; color:red;} */

/* #wall a {outline:none;} */

#wall {
    height: calc(100vh - 23em) !important;
}

wbr {
  width: 0 !important;
  display: inline-block !important;
  overflow: hidden !important;
}

a.mp3 {
text-decoration: none;
color:red;
font-weight: bold;

padding-left: 20px;
background-image:url(img/audio.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50% !important ;
}
.hello {color: #888; font-size: 80%; font-style:italic;}


a.stop {
color:#fff;
background: #888 !important;text-decoration:none;
font-size: 80%;
padding: 0 .4em .1em;
border-radius: 1em;
}

.rooms {padding:2px 5px;z-index:1;position:relative;}
.rooms p {margin: 0 3px}

#mp3 {display:block; margin-top:5px;}
#r_player ul, #player ul {background:#f1f1f1; border-radius: 0 0 5px 5px; }

@media screen and (-webkit-min-device-pixel-ratio:0) { /* nur Blink, also Chrome - und natürlich Opera */
	audio {
	border: 1px solid #ccc;
	border-radius: 40px;
	}
}

_::-webkit-full-page-media, _:future, :root audio { /*Safari*/
	border: 0;
}



#radio #player_0 embed {text-align:center;width: 97%;}
#talk #player_0 embed{
/*	float:right; */ 
	outline:0; 
/*	max-width:50%; */
} 
.rooms #player_0 embed {outline:0; margin: -15px 3px;}

#topic, #topic_wdw {
color:red;
margin:0 0 5px 5px;
}

#nickname { color:red; margin-left: 2px;display:inline-block;}

#webradio {width:100%; text-align:center;color:#666}

#toggle_radios {margin-bottom:0 !important;cursor:pointer;max-width:22em;margin:auto;margin-bottom:5px !important;} 
#radiowahl {margin-top:0 !important}

.yta {color:black;font-weight:bold; font-family:Arial narrow, Arial; font-size: 1.2em;}
.ytb {font-family:Arial narrow, Arial; background:#a00;color:white;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}

a.footerlink {color:#ccc;}

.more_smileys img {
border:2px solid #888;
border-radius: 2em;
}

/* Bilder in der Timeline */
span img {border-radius: 5px}

#webradio {text-align:center;}
#audio-controls {margin-top: .5em;}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;}
input[type="image"]:hover, input[type="image"]:focus { background: #ddd}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}

#wdwlogo {text-align:center;}



/* Smartphones and iPad (portrait and landscape) ----------- */
@media only screen 
and (min-device-width : 320px) 
and (max-device-width : 1024px) {
	#talk {max-width:72% !important}
}

@media only screen and (max-width : 1023px) {
	#talk {max-width:70% !important}
}
