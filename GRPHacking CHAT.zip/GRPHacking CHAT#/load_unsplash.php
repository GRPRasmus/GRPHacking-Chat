<?php
$content = file_get_contents('https://source.unsplash.com/random/1900×1200?people chatting');
file_put_contents('cached_from_unsplash.jpg', $content);
?>
