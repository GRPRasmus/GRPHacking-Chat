<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

/* CSS fuer Skin 3 Web2 */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, fieldset, input {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #343; /* die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */
}


body {
	padding: 10px 20px 0 20px;
	
	background-color:#e1e1bb;
	background-attachment:fixed;
	background-image: -moz-linear-gradient(90deg , #e1e1bb, #ffffff 40%);
	background-image: -webkit-linear-gradient(90deg , #e1e1bb, #ffffff 40%);
	background-image: -o-linear-gradient(90deg , #e1e1bb, #ffffff 40%);
	background-image: -ms-linear-gradient(90deg , #e1e1bb, #ffffff 40%);
	background-image: linear-gradient(0deg , #e1e1bb, #ffffff 40%)
	
}	

h1 {
	font-size:1.4em;
	color:#373;		/* dies ist ein Beispiel fuer eine spezielle Schriftfarbe fuer die Ueberschrift */
	line-height:125%;
}
h1 span {color:#373}

h2 {
        color: #888;
	font-size:.9em;
	line-height:125%;
}
h2 a, h2 a span {color:#888}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}


p, ol li, #uo, #help tr  {
	font-size:.8em;
}

a {color: brown}


fieldset fieldset a {text-decoration:none;}

#user_pro_room li {color:#ccc}

#user_pro_room ul li a:focus,
#user_pro_room ul li a:hover,
#uo ul li a:focus,
#uo ul li a:hover {
        background:#e1e1bb;
}


#addsmileys a:hover {background:none}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
}

#user_pro_room em:after { /* das geht natuerlich im IE nicht */
	content:"\00A0\221A";
}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}


ul {
	font-size:.8em;
	list-style-type: square;
}


li {
	margin: 0 1em 0 0;
}

hr {
	display:none;
}


fieldset {
	clear: right;
	margin:0;
	padding: 0;
	min-width: 8em;
}



/*  Op hack: */
html:first-child>b\ody fieldset fieldset {
	 margin-left: 79%;
}


#wrapper {margin:20px 0 0 0}

#wrapper:after, #opt:after { /* der Konq braucht das 1., der Op das 2. */
	content : ".";		
	display : block; 
	height : 0; 
	clear : both; 
	visibility : hidden;
}

/* Hides from IE-mac \*/
* html #opt {height: 1%;}
/* End hide from IE-mac */
/* End Op hacks */


.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .8em;
	color: #888;
}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {margin: 10px 3px 0 0;}

.rooms {margin-top:20px;}

#wall {
	height: <?php echo $hoehe?>em;
	/* background: #fff;	 die Hintergrundfarbe fuer das Nachrichtenfenster */
	/* -webkit-mask-image: -webkit-gradient(linear, left top, left 8%, from(rgba(0,0,0,0)), to(rgba(0,0,0,1))); */
	border: 1px solid #aaa;
	overflow: auto;
	margin: 10px 10px 20px 0;
	padding: 1px 3px;
	line-height: 1.03em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
}

/* Op hack < V9.0: */
      html:first-child>b\ody #wall {
	overflow: auto;
}

#wall p {
        /* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 3.4em;
	text-indent: -3.4em;
	margin-bottom:3px;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#wall .whisper, #wall .at {color:red; background: yellow}

#line {
	width: 80% !important;
	min-width:80% !important;
	max-width: 80% !important;
	font-size:1em;
}
input#line {position:relative; top: -6px; padding:3px;}




#ton {
	width: 0;
	height: 0;
}
#uo {
	display: inline;
	margin-bottom:1em;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
 		echo "display:block; min-height: 5em;";
	} ?>
}

#uo ul {margin-top:1em}

#user_pro_room {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
 		echo "display:block; ";
 		echo "margin-bottom: 1em;";
	} ?>
}

#uo ul, #uo ul li {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	} ?>
	font-size:100%;
}
#user_pro_room ul {
	padding: .2em 0 0 1.25em;
}


#user_pro_room ul li {
        padding:0;
        line-height:1.3em;
}
* html #user_pro_room ul li {
        line-height:1.2em;
}

#addsmileys {
/*	float:left; */
	margin: 3px 0 0 5px;
}
object {margin: 5px;}


dfn, .dot {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


p.bg {padding-top:4px !important}
.bg {background:rgba(220,220,200,0.4);}  /* der Hintergrund fuer den Admin */



input[type="text"], select {
    border: 1px solid;
    padding: .2em .3em;
}

/* so wills der IE */
#talk input, .rooms input {
       background:#fff;
       border:1px solid #888;
       cursor:pointer;
}
#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
      border: 0;
      background: transparent;
}

.button, .away {
    font-size: 1em;
    text-decoration: none;
    padding: 2px 5px;
    border: 1px solid;
    background: #fff;
}

.button {bottom:6px !important}

#line, #handle, #room {
       border: 1px solid #888;
       padding: 1px 0 1px 3px;
       background:#fff;
       cursor:text;
}

label, select {cursor:pointer; font-size:1em;}
label {margin-left: 4px;}


#menu1, #menu2 {width:65%; clear:both; display:block;margin-bottom: 4px !important;}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
}
?>

.yta {color:black;font-weight:bold; font-family:Arial narrow, Arial; font-size: 1.2em;}
.ytb {font-family:Arial narrow, Arial; background:#a00;color:white;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}

.uolist {display:none;}
/* #opt {display:block; float:right; width:21.5%;} */
#upload {display:block; margin:8px 0 6em 0; clear:left;}

#logout, .logout {
        text-align:center;
        margin:4px 8px 4px 0;
        padding:3px 8px;
        border: 2px outset #eee;
        background-color: transparent;
}
.logout a {text-decoration:none;}

<?php
if ($stil != 0) {
   echo '#menu1 {width: auto}';
}
?>

#opt2 {margin-top: .5em}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50%  !important;
}
.hello {color: #888; font-size: 80%; font-weight:bold; font-style:italic;}

fieldset #upload #file{border:0 none !important; background:transparent; font-size: .8em; color:transparent}
#ae {margin-bottom:.5em;}
#mp3 {display:block;}

#r_player a, #player a {color: #222;}


#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

#nickname {color:red;}

/* Avatar */
.av { width: 30px !important;}

#webradio {text-align:center;}
#audio-controls {margin-top: .5em;}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;border-radius:5px}
input[type="image"]:hover, input[type="image"]:focus { background: #ddd}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
