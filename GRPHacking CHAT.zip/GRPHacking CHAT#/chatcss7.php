<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

/* CSS fuer Skin 7 mobile */

* {outline:none;}



html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li {
	font-family: Helvetica, Verdana, Geneva, Arial, sans-serif;
	border:0;
	margin:0 auto;
	padding:0;
	color: #343; /* die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */
}

html {-webkit-text-size-adjust: 100%; background-color: #ddd; width:100%} 
body {padding:0 3px 0 10px;margin:0;}

p, ul li, #uo, #upload input {
	margin-bottom: 2px;
}

a {color: blue;}

#uo li {
	font-size:100%;
}

#user_pro_room ul, #uo ul{
	margin:5px 0 0 0;
}


#uo a, #user_pro_room a {text-decoration:none}


#wall img {max-width: 100%;vertical-align:top}

#wall .pop::after {top: 6px;}

#wrapper {height:98vh !important;}


fieldset {
	float:left;
	border:none;
	background: #ddd;		/* die Hintergrundfarbe fuer das Chatfenster */
	margin:0;
	padding:0;
}

#addsmileys {display:block;max-width:90%;margin:0;}

#addsmileys ul {
	clear: left;
	padding-top: 10px;
	margin-left: 3px;
}
	
#addsmileys ul li{display:inline-block;max-width:90%}


h1,
.rooms p img,
#switch,
.dot,
dfn,
/* input, #opt, #farben, .rooms p, #opt2, */  /* diese Zeile entkommentieren, um eine Infobox zu erstellen */
/* fieldset fieldset,    */            /* diese Zeile entkommetieren um alle Optionen auszublenden */
#Anzeige,
#Uhr_Anzeige,
#offaddsmileys ul,
#header,
.ytpreview,
#curr_tit {
	display:none;
}
#afk_button {
	display:none !important;
}

h2 {
font-size:1em;
margin: .5em 0 0 0;
}

video {max-height:150px; max-width:260px}

#topic, #topic_wdw {margin:.5em 0 .2em 0}
/* #topic, #topic_wdw {display:none} */

.rooms {clear:left;width:100%;}


#mp3 audio, #webradio audio, #r_player audio, #player audio {width:98%;border:none;font-size: 1em;}
#r_player {margin-top: 5px;}
#r_player ul, #player ul {margin: 0 4px 0 0;}
#r_player a{color:#222}

#webradio {
    padding: 7px 5px 0 5px;
    margin-top: 7px;
	text-align:center;
}
#audio-controls {text-align:left !important; display:block !important;} /* iOS kann onunload nicht */ 

#webradio h3 {margin: 0 0 .5em 0;font-size:.8rem; color:#666;font-family:Arial}
#webradio  {font-size:.7rem; color:#666;font-family:Arial}

input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;border-radius:5px;background:#eee}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}


/* On iOS devices, the audio level is always under the user’s physical control. The volume property is not settable in JavaScript. Reading the volume property always returns 1. */


#user_pro_room ul li {
	list-style-type:none;
	display:inline-block;
	border:1px solid;
	border-radius:4px;
	background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#d1d1d1));
	margin: 5px 3px 0 0;
	padding:1px 6px 2px 6px;
}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
	/* position:relative; top:.15em; hm? */
}

#user_pro_room a {text-decoration:none;color:#222}


#user_pro_room em:after { 
	content:" ✔︎";
}

#uo, #uo ul {min-height: 2em !important;}

#uo ul li{ display:block;} /* wichtig, weil sonst Ghost Leerzeile macht */


#talk {
   font-size: 100%;
}

#wall {
/*	overflow: auto; */
/*	-webkit-overflow-scrolling: touch !important; */
	margin: 10px 0 10px 0;
	padding: 1px 3px;
	height: 60vh !important;
}


.tr  {
	visibility:hidden;
	height: 0;
	display: block;
	margin-bottom: -1px;
}
/* span.tr:after {
    content: "";
    display: block;
} */


.av {
	margin: 3px 5px 3px 0;
	border:1px solid #888;
	border-radius:3em;
	/* max-height:3em; */
	width:31px !important;
	clip-path: circle(50% at 50% 50%);
	float:left;
	background:#fff;
}

#wall p {
	position: relative;
	background: #fff;
	color: #333 !important;
	border-radius: 0 .7em .7em .7em;
	padding:  .3em .5em .3em .5em;
	margin-bottom: 6px;
	margin-left:.7em;
	max-width: 80vw;
	word-wrap:break-word;
	clear:left;
	display:flow-root;
	/*overflow:auto;*/
}



#wall p:before {
	content: ' ';
	position: absolute;
	width: 0;
	height: 0;
	right: 100%;
	top: 0;
	border: 5px solid;
	border-color: #fff #fff transparent transparent;
}


/* das sollte natürlich nicht .bb sein, sondern der schreibende User, also in chat? */
#wall p.bg {
	background: #e8fbd3;
	position: relative;
	left: 12%;
	width:76%;
	border-radius: .7em 0 .7em .7em;
	margin-left:0;		
}

#wall p.bg:before {
	border:0;	
}

#wall p.bg:after {
	content: ' ';
	position: absolute;
	width: 0;
	height: 0;
	left: 100%;
	top: 0;
	border: 5px solid;
	border-color: #e8fbd3 transparent transparent #e8fbd3;
}
	

#wall p.bg span:not(.ytb) {
	color: #666 !important;
}




#wall .whisper, #wall .at {color:red; background: yellow}

.bg {background:#eee;}  /* der Hintergrund fuer den Admin */

textarea#line {width:97.5%;}
input#line {
    max-width: 68vw;
    line-height: 1.5em;
    margin-bottom: .5em;
}
input {
      background:#fafafa;
      margin: 0 0 0 0;
      font-size: 100%;
}

input#reset_button {padding:5px 10px 6px 10px !important;margin:0 !important;position:relative;top:0;margin:0; -webkit-appearance: button;font-weight:bold;}

/* .button {margin:15px 0 0 0 !important;} */

button.button {
	margin-top: 0 !important;
	padding: 5px 8px 6px 8px !important;
	bottom: 0;
}
#f .button {display:inline-block; margin-top: 1em;}

.opt, .opt3 {
     display:block;
     margin-top: .2em;
}

#menu1 {margin-right:1em}  /* damit's untereinander steht */

#menu1, #menu2{
  width:288px;
  font-size: 1em;
}

#room {
     width:50%;
     margin-top: 5px;
}



#logout, .logout, .button, .away {
	display:inline-block;
	margin:5px 1px 2px 0;
	padding:2px 8px;
	background-color: #fff;
	border: 1px solid #555;
  	border-radius: 5px;
	background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#d1d1d1));
	background: -moz-linear-gradient(top,  #fff,  #d1d1d1);
	font-size: 1em;
}

fieldset.rooms {padding-bottom: 5em !important;}

#logout a, .logout a, a.away {font-family: sans-serif; text-decoration:none; color: #222; font-weight: normal !important;} 
#logout a, .logout a {display:block}

/* .av {
    position: relative;
    left: -8px;
    top: 4px;
    margin-right: -8px;
}
*/

.away {padding: 1px 8px !important;font-family:Verdana !important;}
 
/* embed {width: 100%; height: 75%; } */


a.stop {
color:#fff;
background: #888 !important;
text-decoration:none;
font-size: 80%;
padding: 1px 7px;
border-radius: 2em;
}

#upload {
  clear:both;
  margin:1em 0 0 0;
  border:none;
  padding:0;
  min-height:unset !important;
}

#upload legend {font-size:1em !important;}


#ip {margin-top:0}

#file {color: transparent;background-color:transparent;max-width:95vw}

<?php
if ($_SERVER['SERVER_NAME'] == "webdesign.weisshart.de") {
	echo '#user_pro_room ul li:nth-child(2) {display:none}'; // hide darkroom
}
?>

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50% !important ;
}


.yta {color:black;font-weight:bold; font-family:Arial; font-size: 1.2em;}
.ytb {font-family:Arial; background:#a00;color:white !important;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}

.dt, .uz, .tr {font-size:.7em;display:contents;}

/* Avatar */
.hello {color: #888; font-size: 80%; font-style:italic;}
#footerlink{display:none;}

#einaus_ae {font-size:1.5em}	
#esc {display:none !important}
	
#eu-cookie-irrsinn {opacity:1 !important}	
	

#f .button, .button, .logout, #logout {max-width:90vw !important;padding:.6em;color:#555}

#radiowahl {font-size:1em !important; margin-top:1em !important;float:none}
	
@media only screen and (orientation:landscape){	
	#wall {height: 60vmin !important;}
	#wall p {
		/* damit word-wrap weiss was es tun soll */
		max-width: 30em;  	
	}	
}

#mixed_content {display: none;}
#popout_icon {bottom:0 !important;margin: 16px;}
	
.helplinks {
margin:0 10px;
position:relative;top:5px;
}
.helplinks p {color:transparent !important}

.helplinks p a:not(.flag) {
border: 1px solid;
border-radius:3px;
padding: 2px 4px;
background:#fff;
}
.helplinks a {color:#747474;text-decoration:none}
.helplinks a span.dot {display:none}

.flag {
margin-top: -2px !important;
}
	
	
<?php
if(!isset($show_player) || $show_player !== true) {
echo '
a.mp3 {
text-decoration: none;
color: #ccc
}

a.mp3:before{
  color: red;
  content:"mp3 Wiedergabe leider nicht möglich ";
}

a.stop {
display:none;
}
';
}


?>

