// die user.txt bereinigen, uralte inaktive Registrierungen loeschen:

$user_dateiname = "user/user.txt"; // Name der Datei
if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {

		$teile = explode("****", $val);
		$last_access = $teile[3];

echo $last_access.'<br>';

//		$unix_time = $teile2[0];
	
//		if (time() < $unix_time) {
//			$newline .= $val;		 
//		}
	}


//	$handler = fopen($user_dateiname, "w");
//	fwrite($handler , $newline);
//	fclose($handler);
}
