<?php
// ob_start('ob_gzhandler'); // das macht Probs mit Session im IE6 => Hinweis?
session_start();
if (isset($_SESSION['chatuser'])) {$nickname= $_SESSION['chatuser'];}

header('Content-Type: application/javascript');

@include("chat_config.php");

$closepop = "no";
if(isset($self_close)) $closepop = "on";



$registered = 0;
if(isset($_SESSION['login']) && $_SESSION['login']==1 || isset($nickname)) $registered = 1;

$eigener = "";
if(isset($nickname)) $eigener = $nickname;



// Sprache abfragen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
      $lang = $languages[0];
}

// Cookie reverse Anzeige abfragen
if (isset($_COOKIE["rev"])) {
	if ($_COOKIE["rev"]=="1") {
		$display_reverse=true;
	}
}
// bf_linear abfragen für reverse
if (isset($_COOKIE["bf_linear"])) {
	if ($_COOKIE["bf_linear"]=="1") {
		$display_reverse=true;
	}
}



$s = "";
if (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
}	

$lang_file = 'lang'.strtoupper($lang).'_inc.php';

if (file_exists($lang_file)) {
	include ($lang_file);
}


if (!isset($popup)) {$popup = "disable";}

if (!isset($flood_test)) {$flood_test = 4;} 

?>


var width = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;


if (holeCookie) {holeCookie("Style");}
style=cookieWert;


if (holeCookie) {holeCookie("rev");}
// if (cookieWert == "1") {reverse = 'reverse';} else {reverse = 'normal';}

if (style == 12 || cookieWert == "1" ) {
	reverse = 'reverse';
} else {
	reverse = 'normal';
}


/* ///////// audio-sprite: ////////////// */

if (document.getElementById('audio-sprite')) { var audioSprite = document.getElementById('audio-sprite');}

var spriteData = {
	stumm: {
		start: 0,
		length: 1.1
	},	
	rein: {
		start: 1.4,
		length: 1.4
	},	
	raus: {
		start: 3.6,
		length: 0.5
	},
	msg: {
		start: 13,
		length: 0.5
	},
	alarm: {
		start: 5.6,
		length: 5.9
	}
};

// current sprite being played
var currentSprite = "";

// time update handler to ensure we stop when a sprite is complete
var onTimeUpdate = function() {
	if (this.currentTime > currentSprite.start + currentSprite.length) {
		this.pause();
		this.currentTime = 0;
	}
};

if (document.getElementById('audio-sprite')) {
	audioSprite.addEventListener('timeupdate', onTimeUpdate , false);
}

// in mobile Safari, the first time this is called will load the audio. Ideally, we'd load the audio file completely before doing this.

var playSprite = function(id) {

		
if (spriteData[id] && spriteData[id].length) {
	currentSprite = spriteData[id];
	setTimeout(audioSprite.currentTime = currentSprite.start,100);
	audioSprite.play();
}
	
};


/* /////// end audio-sprite ///////////////// */

var flood_test ="<?php echo $flood_test ?>";

var konfig = 0;
konfig = "<?php echo $popup ?>";


away_msg = '';
function away() {
	away_msg = 'weg';
	add();
//	document.cookie="stop=stop";
//	document.location.reload(false); 
	alert('<?php echo _AWAY; ?>');
	
	away_msg = 're';
	add();
	away_msg = '';
}

function waermestube(){
	away_msg = 'warm';
	add(); 
	away_msg = '';
}

function popup(new_data) {
	if (holeCookie) {holeCookie("pop_up");}
	if (cookieWert == "aus" && konfig == "enable") { 
		if (reverse == 'normal') {
			start = new_data.lastIndexOf("pointer")+9;
			post = new_data.substr(start);
		} else {
			start = new_data.indexOf("pointer")+9; 
			end = new_data.indexOf("</span></p>"); 
			length = end - start;	
			post = new_data.substr(start,length)+'</p>';	
		}
		
		anex = "<script>setTimeout(window.close,60000);</script>";

		var w = window.open('', 'popup', 'width=300,height=150,left=0,top=0');
		if (w) { 
			w.document.write('<p><span>'+post+anex); 
			new_data ="";
			w.document.close(); // needed for chrome and safari?
		} else {
	    	alert("Dein Browser verhindert leider die Anzeige eines Popups.");
		}
	}
}

// http://www.professorweb.de/javascript-ajax/iframe-hohe-an-dessen-inhalt-automatisch-anpassen.html
/*
var framefenster = document.getElementsByTagName("iFrame");
var auto_resize_timer = window.setInterval("autoresize_frames()", 400);
function autoresize_frames() {
	for (var i = 0; i < framefenster.length; ++i) {
	    if(framefenster[i].contentWindow.document.body){
	      var framefenster_size = framefenster[i].contentWindow.document.body.offsetHeight;
	      if(document.all && !window.opera) {
	        framefenster_size = framefenster[i].contentWindow.document.body.scrollHeight;
	      }
	      framefenster[i].style.height = framefenster_size + 'px';
	    }
	}
}
*/


// Enter schickt die Eingabe ab anstelle einer Zeilenschaltung in textarea
if (document.getElementById('line')) {
	document.f.line.onkeypress = function(e){
	  e = e || event;
//	  	if (e.keyCode === 13) {
		if (e.keyCode == 13 && !e.shiftKey) { 
	    add(); return false;
	  }
	  return true;
	}
}


var Opera = (navigator.userAgent.match(/Opera|OPR\//) ? true : false);
var iOS = !!navigator.platform.match(/iPhone|iPod|iPad/); 
if (iOS ===true) {
	if (document.getElementById("soundwahl")) {
		document.getElementById("soundwahl").style.display = "none";
	} 
}


var show_user;

var sb = 0;
if (location.href.indexOf("shoutbox") != -1) sb = 1;

var check_n = 0;
var old_data = "--";
var old_result = 1;


var anz_opt = "<?php echo _OPT; ?>";

var light;
light = "<?php echo $chat_light ?>";

var nick;
nick = "<?php echo $eigener ?>";

// http://www.validome.org/doc/HTML_ge/navigation/anzeige/rechte_maustaste.htm
// duerfte inzwischen hinfaellig sein. Vor allem macht es den Rechtsklick in FF/Mac kaputt
function click (e) {
  if (!e)
    e = window.event;
  if ((e.type && e.type == "contextmenu") || (e.button && e.button == 2) || (e.which && e.which == 3)) {
    if (window.opera)
      window.alert("Benutzer \u00e4lterer Opera-Versionen k\u00f6nnen die Rechtsklick-Funktion hier eventuell nicht nutzen.\n\nFalls die Einladung nicht im Textfeld erscheint,\nbitte die entsprechenden Tastaturbefehle benutzen siehe Hilfe.\n\n");
    return false;
  }
}
//if (document.layers)
//document.captureEvents(Event.MOUSEDOWN);
//document.onmousedown = click;




function getInternetExplorerVersion()
// Returns the version of Internet Explorer or a -1
// (indicating the use of another browser).
{
  var rv = false; // Return value assumes failure.
  if (navigator.appName == 'Microsoft Internet Explorer')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      rv = parseFloat( RegExp.$1 );
  }
  return rv;
}



function strpos (haystack, needle, offset) {
    // Finds position of first occurrence of a string within another  
    // discuss at: http://phpjs.org/functions/strpos    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // *     example 1: strpos('Kevin van Zonneveld', 'e', 5);    // *     returns 1: 14
    var i = (haystack+'').indexOf(needle, (offset || 0));
    return i === -1 ? false : i;
}

/* nur noch aus dem viewport schieben */
function klappx(beitrag) {
     if (document.getElementById) {
          if (document.getElementById(beitrag ).style.display == 'none') {
              document.getElementById(beitrag).style.display = "block";
              document.getElementById('einaus_' +beitrag).innerHTML = anz_opt+' [&#8722;]';
          } else  {
              document.getElementById(beitrag).style.display = "none";
              document.getElementById('einaus_' + beitrag).innerHTML = anz_opt+' [+]';
          }
     }
}

function klapp(beitrag) {
     if (document.getElementById(beitrag)) {
          if (document.getElementById(beitrag).style.position == 'absolute') {
              document.getElementById(beitrag).style.position = "static";
              document.getElementById('einaus_' +beitrag).innerHTML = anz_opt+' <span aria-hidden="true">[&#8722;]</span> <span id="esc" style="font-weight:400; font-size: .8em;">(esc)</span>';
			  
          } else  {
              document.getElementById(beitrag).style.position = "absolute";
              document.getElementById(beitrag).style.left = -1000;
              document.getElementById(beitrag).style.top = -1000;
              document.getElementById(beitrag).style.width = 0;
              document.getElementById(beitrag).style.height = 0;
              document.getElementById(beitrag).style.overflow = 'hidden';
              document.getElementById(beitrag).style.display = 'inline';
              document.getElementById('einaus_' + beitrag).innerHTML = anz_opt+'<span aria-hidden="true">[+]</span> <span id="esc" style="font-weight:400; font-size: .8em;">(strg+1)</span> ';
          }
     }
		playsound(''); // damit beim Klappen kein Sound gespielt wird.
}

function kp(e){
	if (!e) e=event;
	// alert (e.keyCode);
	//if (e.keyCode==79 && e.altKey) {klapp('ae'); document.getElementById("reverse").focus(); return false;} /* alt + o */	
	if (e.ctrlKey && e.keyCode==49) {klapp('ae'); document.getElementById("reverse").focus(); return false;} /* strg + 1 */
	if (e.keyCode==27  && document.getElementById('ae').style.position != 'absolute'){klapp('ae'); document.getElementById("line").focus();}
}
document.onkeydown=kp;


function FensterOeffnen (url) {
	var width  = screen.width * <?php echo (isset($more_smiley_width) ? $more_smiley_width : 0.67); ?>;
	var height = screen.height * <?php echo (isset($more_smiley_height) ? $more_smiley_height : 0.67); ?>;
	var left   = (screen.width  - width)/1.1;
	var top    = (screen.height - height)/3;
	var params = 'width='+width+', height='+height;
	params += ', top='+top+', left='+left;
	params += ', location=no';
	params += ', menubar=no';
	params += ', resizable=yes';
	params += ', scrollbars=yes';
	params += ', status=no';
	params += ', toolbar=no';
	params += ', dependent=yes';
	newwin=window.open(url,'usr_smileys', params);
	if (window.focus) {newwin.focus()}
	return false;
}


var self_close = "no";
var self_close = "<?php echo $closepop; ?>";

function closepopup() {
	if(typeof(newwin) == "object" && false == newwin.closed && self_close != "on") {
//	if(false == newwin.closed) {
		newwin.close ();
	} else {
		// do nothing;
	}
}


function YTPop (Adresse) {
	var iPhone = !!navigator.platform.match(/iPhone|iPod/);

	if (iPhone === false) {
		MeinFenster2 = window.open(Adresse,'youtube','width=800, height=450, left=0, top=0, toolbar=no, location=no, menubar=no, scrollbars=yes, status=no, resizable=yes, dependent=yes').focus();
	} 
}

function CookieSetz(Bezeichner,Wert,Dauer) {
	jetzt=new Date();
	Auszeit=new Date(jetzt.getTime()+Dauer*86400000);
	document.cookie=Bezeichner+"="+Wert+";expires="+Auszeit.toGMTString()+";";
}


var cookieWert;
function holeCookie(keksname) {
      var alleCookies, i;
	alleCookies=document.cookie;
	cookieArr=alleCookies.split(";");
	for(var i=0;i < cookieArr.length;i++) {
		if(cookieArr[i].split("=")[0].replace(/\s+/,"") == keksname) {
			cookieWert=cookieArr[i].split("=");
			cookieWert=decodeURIComponent(cookieWert[1].replace(/\+/g," "));
			return true;
		}
	}
  	return false;
}



// Abfrage, ob Admin:
<?php
$admincheck = 0;
if (isset($nickname)) {
   	//$nickname = $_COOKIE["nick"];
   	// if (in_array(utf8_decode($nickname), $admins)) $admincheck = 1;
	if (file_exists("admin/admins.txt") && file_exists("admin/admin_admins.php")) {
		$admins2 = file("admin/admins.txt"); 
		$admins2 = array_map('trim',$admins2);
		$admins = array_merge($admins, $admins2);
	}
	foreach($admins as $key => $val) {
		if (utf8_decode($nickname) == trim(utf8_decode($val))) {$admincheck = 1;}
	}
}

$modcheck = 0;
if (isset($nickname)) {
   	//$nickname = $_COOKIE["nick"];
   	// if (in_array(utf8_decode($nickname), $admins)) $admincheck = 1;
	if (file_exists("admin/mods.txt") && file_exists("admin/admin_mods.php")) {
		$mods = file("admin/mods.txt"); 
	}
	foreach($mods as $key => $val) {
		if (utf8_decode($nickname) == trim(utf8_decode($val))) {$modcheck = 1;}
	}
}

?>

var isadmin = "<?php echo $admincheck ?>";
var ismod = "<?php echo $modcheck ?>";

if(isadmin==1 && ismod==1) {alert ("Achtung! Du bist gleichzeitig Admin und Moderator!")};

allow_url_fopen = <?php if(ini_get('allow_url_fopen') == 1) {echo 1;}else{echo 0;} ?>;


// die Anzeige der online-Zeit bei reloads oder Raumwechsel nicht zuruecksetzen:
var Jetzt = new Date();
cookieWert ="";
holeCookie("arrival");
if (cookieWert != "") {
	login = cookieWert;
} else {
	login = Jetzt.getTime();
}

<?php

// http://www.myhpi.de/~dtibbe/php/php2js.php
function php2js($php = array(), $name = 'foo', $useVar = TRUE) {
	if (!is_array($php)) {
		trigger_error('The frist parameter has to be an array', E_USER_ERROR);
		die();
	}

	static $first = TRUE;
	if ($first) {
		if ($useVar) { echo 'var '; }
		echo $name.' = '; $first = FALSE;
	}

	echo "new Array();\n";
	foreach ($php as $key => $value) {
		$OName = $name.'[';
		if (is_numeric($key)) {
			$OName .= $key;
		} else {
			$OName .= '"'.$key.'"';
		}
		$OName .= ']';

		echo $OName.' = ';

		if (is_array($value)) {
			php2js($value, $OName, FALSE);
		} else {
			if (is_numeric($value)) {
				echo $value;
			} else {
				echo '"'.$value.'"';
			}
			echo ";\n";
		}

	}
}
  


if (isset($user_whisper) && $user_whisper == "admin") {
    echo  php2js($admins, 'all_admins');
}

?>


// unerlaubte Raumnamen zurueckweisen:
function room_name() {
	if (document.forms[2].room.value.match(/\W/)) {

		alert ("<?php echo _ROOMNOTALLOWED; ?>");
		return false;
	}
}




// AJAX http://board.gulli.com/thread/801675-php-script-aus-einem-javascript-aufrufen/
function get(url, callback_function, return_xml){
	var http_request = false;

	if (window.XMLHttpRequest) {
		http_request = new XMLHttpRequest();
		if (http_request.overrideMimeType) {
			http_request.overrideMimeType('text/xml; charset= iso-8859-1');
		}
	}else if(window.ActiveXObject) {
		try {
			http_request = new ActiveXObject("Msxml2.XMLHTTP");
		}catch (e) {
			try {
				http_request = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {}
		}
	}
	if (!http_request) {
		alert('Leider unterstuetz Ihr Browser diese Funktion nicht.');
		return false;
	}
	http_request.onreadystatechange = function() {
		if (http_request.readyState == 4) {
			if (http_request.status == 200) {
				if (return_xml) {
					eval(callback_function + '(http_request.responseXML)');
				} else {
//					eval(callback_function + '(http_request.responseText)'); // scheint ausser einem JS error nichts zu bewirken
				}
			} else {
				alert('Problem: ' + http_request.status + ')');
			}
		}
	}
	http_request.open('GET', url, true);
	http_request.send(null);
}


function playmp3_mit_http(typ) {

	document.getElementById("mp3").style.display="block";
	document.getElementById("mp3").innerHTML = '<audio autoplay="autoplay" controls="controls" onended="hide_player()" controlslist="nodownload"><source src="'+typ+'"  ></audio>';
	//document.getElementById("line").focus();
	
	
	
	
//	strtyp = str_replace('_','',typ);
//	
//	var y = document.getElementsByClassName("stop");
//	var i;
//	for (i = 0; i < y.length; i++) {
//		
//		strstop= str_replace('Audio:','',document.getElementsByClassName('stop')[i].previousElementSibling.innerHTML);
//		strstop= str_replace(' ','',strstop);
//		
//		if (strtyp.indexOf(strstop)!= -1) { // Stopbutton nur angeklicktes mp3
//			y[i].style.display="inline";
//		}
//	}
	

	if (holeCookie) {holeCookie("counted");}
	if (cookieWert != typ) { // bei wiederholten Klicks des selben Titels nur einmal zaehlen
		get("mp3log.php?file="+typ,""); // Aufruf der Funktion zum Schreiben des Logfiles
		
		// erst nach 2 Min. wird der selbe Titel erneut gezaehlt
		var ablauf = new Date();
		var Minuten = ablauf.getTime() + ( 120 * 1000); 
		ablauf.setTime(Minuten);
		document.cookie="counted="+typ+"; expires=" + ablauf.toGMTString();
	}
}





function playmp3olog_mit_http(typ) {
	
	document.getElementById("mp3").style.display="block";
	document.getElementById("mp3").innerHTML = '<audio src="'+typ+'" autoplay controls onended="hide_player()"  controlslist="nodownload" oncontextmenu="return false;"><p> <a href="'+typ+'">Play</a></p></audio>';
	//document.getElementById("line").focus();
	
//	strtyp = str_replace('_','',typ);
//
//	var y = document.getElementsByClassName("stop");
//	var i;
//	for (i = 0; i < y.length; i++) {
//
//		strstop= str_replace('Audio:','',document.getElementsByClassName('stop')[i].previousElementSibling.innerHTML);
//		strstop= str_replace(' ','',strstop);
//
//		if (strtyp.indexOf(strstop)!= -1) { // Stopbutton nur angeklicktes mp3
//			y[i].style.display="inline";
//		}
//	}
	
}

function hide_player() {
	document.getElementById("mp3").style.display="none";
}


//// die Javascript Funktionen zum Ausschalten des Players:
//function playmp3leer() {
//    document.getElementById("mp3").innerHTML = '';
//	//document.getElementById("line").focus();
//	
//	var y = document.getElementsByClassName("stop");
//	var i;
//	for (i = 0; i < y.length; i++) {y[i].style.display="none"; }
//		
////	document.cookie="counted=no"; // Nachdem Titel gestoppt wurde, bei erneutem Start neu zaehlen
//}




time_init = <?php if (isset($refresh)) {echo $refresh;} else {echo "2000";} ?>;
if (time_init < 500) time_init = 500;

disconnect = time_init * 3; // disconnect bei Erreichen dieses refresh Wert

<?php
     if (!isset($slowdown)) $slowdown = 15;

     if ($slowdown == 0) {
          $slowdown1 = 0;
     } else {
          $slowdown1 = 70 / $slowdown;
     }
?>

slowdown = <?php echo $slowdown1; ?>;
meldung = '<?php echo _TIMEOUT; ?>' ;


// Online Zeit anzeigen:
// erst nach 10 Min. Inaktivitaet startet ein reload oder Raumwechsel die online Zeit neu:
var ablauf = new Date();
var Minuten = ablauf.getTime() + (10 * 60 * 1000); 
ablauf.setTime(Minuten);
// document.cookie="arrival="+login+"; expires=" + ablauf.toGMTString();



// function ZeitAnzeigen () {
// 	if (document.getElementById('Anzeige2')) {
// 		var absSekunden = Math.round(ZeitBerechnen());
// 		var relSekunden = absSekunden % 60;
// 		var absMinuten = Math.abs(Math.round((absSekunden - 30) / 60));
// 		var relMinuten = absMinuten % 60;
// 		var absStunden = Math.abs(Math.round((absMinuten - 30) / 60));
// 		var anzSekunden = "" + ((relSekunden > 9) ? relSekunden : "0" + relSekunden);
// 		var anzMinuten = "" + ((relMinuten > 9) ? relMinuten : "0" + relMinuten);
// 		var anzStunden = "" + ((absStunden > 9) ? absStunden : "0" + absStunden);
// 		if (absStunden >= 1) {
// 			document.getElementById('Anzeige2').innerHTML = anzStunden + ":" + anzMinuten + ":" + anzSekunden;
// 		} else {
// 			document.getElementById('Anzeige2').innerHTML = anzMinuten + ":" + anzSekunden;
// 		}
// 		setTimeout("ZeitAnzeigen()", 1000);
// 	}
// }
// 
// function ZeitBerechnen () {
// 	var Immernoch = new Date();
// 	return ((Immernoch.getTime() - login * 1000) / 1000);
// }
// 
// 
// // Uhr anzeigen:
// function UhrAnzeigen() {
// 	if (document.getElementById('Uhr_Anzeige2')) {
// 		realtime();
// 		window.setInterval("realtime()", 1000);
// 	}
// }
// 
// function realtime() {
// 	var now = new Date();
// 	hours = now.getHours();
// 	minutes = now.getMinutes();
// 	seconds = now.getSeconds();
// 
// 	thetime = (hours < 10) ? "0" + hours + ":" : hours + ":";
// 	thetime += (minutes < 10) ? "0" + minutes + ":" : minutes + ":";
// 	thetime += (seconds < 10) ? "0" + seconds : seconds;
// 
// 	element2 = document.getElementById("Uhr_Anzeige2").innerHTML = thetime;
// }

	

function jump(form) { 
	order = form.menu1.selectedIndex; 
	if (form.menu1.options[order].value != 0) { 
		ads(form.menu1.options[order].value);
	}  
} 


var ablauf2 = new Date();
var Minuten2 = ablauf2.getTime() + (360 * 24 * 60 * 60 * 1000);
ablauf2.setTime(Minuten2);
function jump2(form) {
	order = form.menu2.selectedIndex;
	if (form.menu2.options[order].value != 0) {
		var style = form.menu2.options[order].value;
		document.cookie="Style="+style+"; expires=" + ablauf2.toGMTString();
		window.location.reload();
	}
}

function setlang(lg) {
	document.cookie="lang="+lg+"; expires=" + ablauf2.toGMTString();
}

function playsound(typ) { // die standardkonforme Loesung fuer alle Browser
      if (document.getElementById('ton')) {
      	document.getElementById("ton").innerHTML = '<audio src="'+typ+'" autoplay controlslist="nodownload"></audio>';
      }
}

time1 = time_init;

function refresh_cb(new_data) {
	last_msg="";
	msg_pos = 0;
	teil_msg = "";
	if (typeof old_data == "undefined" || old_data == "--") {
		if (playsound) playsound('<?php echo $sound1 ?>'); // Sound bei reload
	} else {
		if (typeof handle != "string") {
			holeCookie("nick");

			msg_pos = new_data.lastIndexOf("color:");
			last_msg = new_data.substr(msg_pos);
				 
				 
			if (old_msg != last_msg && last_msg.indexOf("/pn") == -1) {
				if (iOS !==true) {
					playsound('<?php echo $sound4 ?>'); // Sound bei nicht /pn, kein Sound bei /pn - warum nicht?
				} else {
					playSprite('msg');
				}
					
				if (iOS !==true && style!= '12' && style !='11') {popup(new_data);}
			}
				 
			// wenn Admin pn kriegt, kein sound
			if (old_msg != last_msg && last_msg.indexOf(cookieWert) != -1) {
				if (iOS !==true) {
					playsound('<?php echo $sound4 ?>'); // Sound bei /pn an mich
				} else {
					playSprite('msg');
				}
			}
                 

			if (isadmin == 1 && last_msg.indexOf("/pn") != -1) {
				if (iOS !==true) {
					playsound('<?php echo $sound4 ?>'); // Sound fuer Admin bei allen /pn
				} else {
					playSprite('msg');
				}
			}

			function alertMsg() {
				alert("Hallo! Aufwachen!\nHello! Wake Up!");
			}
                 
			// der Alarmruf:
			if (last_msg.indexOf("/alarm") != -1 && last_msg.indexOf(nick) != -1) {
				if (iOS !==true) {
					playsound('<?php echo $sound6 ?>');
				} else {
					playSprite('alarm');
				}
				setTimeout(alertMsg,3000);
			}


			// echter /kick:
			if (last_msg.indexOf("you've been kicked") != -1 && last_msg.indexOf(nick) != -1) {
				window.location.href = 'kick.php?nick='+nick;
			}

		}
	}

	old_msg = "";
	if (typeof last_msg == "string") old_msg = last_msg;
	handle = 1;

	if (document.getElementById("wall")) {document.getElementById("wall").innerHTML = new_data;}


	// ARIA
	if (document.getElementById("jaws")) {
		
	<?php	
	if (isset($display_reverse) && $display_reverse === true || $s == "12") {
	echo'		
		msg_pos = new_data.indexOf(": pointer");
		msg_pos1 = new_data.indexOf("</p>");
		last_msg = new_data.substr(msg_pos + 11,msg_pos1);
	';
	} else {
	echo'		
		msg_pos = new_data.lastIndexOf(": pointer");
		last_msg = new_data.substr(msg_pos + 11);
	';	
	}
	?>


	if (last_msg.indexOf("<img") != -1 && last_msg.indexOf("alt") != -1) { // alt-Attribut fuer ARIA aufbereiten
		start_img = strpos(last_msg, '<img', 0);
		sub0_aria = last_msg.substring(0,start_img); // alles vor <img
		start_alt = strpos(last_msg, 'alt=', 0);
		sub1_aria = last_msg.substring(start_alt +5); // alles nach alt=
		end_alt = strpos(sub1_aria, '"',0);
		sub2_aria = sub1_aria.substring(0,end_alt); // das komplette alt-Attribut
		rest = strpos(sub1_aria,'>',0);
		sub3_aria = sub1_aria.substring(rest + 1); // alles nach dem img
		last_msg = sub0_aria + sub2_aria + sub3_aria;
	}


	<?php	if (isset($display_reverse) && $display_reverse === true || $s == "12") {
	echo'		
		msg_pos1 = last_msg.indexOf("</p>");
		last_msg = last_msg.substr(0,msg_pos1);
	';
	}
	?>
	
//	if (last_msg.indexOf('x-shockwave-flash') == -1) {
		document.getElementById("jaws").innerHTML = '<p>' + last_msg + '</p>';
//	} else {
//		document.getElementById("jaws").innerHTML = '<p>Flash Video</p>';
//	}

	}



	function scroll_int(e) {
		elem = document.getElementById(e);
 
		if (reverse == "reverse") {	
				if (elem.scrollTop < 0.5) {
					elem.scrollTop=0;
					clearInterval(scroll_ready);
				}
			} else {
			if (elem.scrollHeight - elem.scrollTop - elem.clientHeight > 0.5) {
				// Scrolltempo degressiv:
				// delta = elem.scrollHeight - elem.scrollTop;
				// elem.scrollTop=elem.scrollTop + delta / 200;
				elem.scrollTop=elem.scrollTop + 3;
			} else {
				elem.scrollTop=elem.scrollHeight;
				clearInterval(scroll_ready);
			}

			}
		
		}



	setTimeout(function(){ 
		scroll_ready = setInterval(function(){ scroll_int('wall') }, 1);
	}, 400);




	old_data = new_data;
	time1 = time_init; // bei Eingang einer neuen Meldung wirds wieder schnell
	setTimeout("changed_data()", time1);

}


function scroll_click() {
	elem = document.getElementById('wall');
	if (reverse !== "reverse") {	
		elem.scrollTop=10000;
	}
}



// Filesize abfragen vor dem AJAX refresh
var old_size;
function set_file_changed(new_size) {



	
	// WOW! so lässt sich komfortabel der Verlauf lesen.
	elem = document.getElementById('wall');

//	console.log(elem.scrollHeight - elem.scrollTop - elem.clientHeight);
//	console.log (elem.scrollHeight +'-'+ elem.scrollTop +'-'+ elem.clientHeight);
//	console.log (elem.scrollHeight);		
//	console.log (elem.scrollTop);		
//	console.log (elem.clientHeight);		

	if (elem.scrollHeight - elem.scrollTop - elem.clientHeight <= 25 || reverse == "reverse" ) {

	elem.style.background = "none";
	if (document.getElementById('clickable')) {
		document.getElementById('clickable').style.visibility="hidden";
	}
	
		if ( typeof old_size == "undefined" || new_size != old_size) {
			old_size = new_size;
			x_refresh(refresh_cb);
		} else { // hierher die Waermestube!
			if (typeof time1 != "undefined" ) {
				if (isadmin != 1 && ismod != 1) {time1 = time1 * (1 + slowdown*0.0002);} // wenn nix los ist, wirds immer langsamer, bis zum timeout:
				if (time1 > disconnect) {
					/* time1 = disconnect * 0.6; macht mit logout keinen Sinn - zuruecksetzen und halbiert Zeit bis zum disconnect ab dem 2. mal  */
					waermestube();
					alert(meldung);
					location.href = "logout.php";
							 
					/* wozu war das?   if (light != "yes" && show_user != "no") u_online();   
					if (light != "yes" && show_user != "no" && sb != 1)u_online_room(); 
					*/
				}
				setTimeout("x_file_changed(set_file_changed)",time1);
				return;
			}
		}
	} else {
		if (reverse == "reverse") {
			// do nothing	
		} else {
			elem.style.background = "transparent url(\'img/arrow_dwn.png\') no-repeat 98% 98%";
			elem.style.backgroundSize = "20px";
			if (document.getElementById('clickable')) {document.getElementById('clickable').style.visibility="visible";}
		}
//		setTimeout("changed_data()",time1);
		setTimeout("x_file_changed(set_file_changed)",time1);
	}
}

function changed_data() {
	x_file_changed(set_file_changed);
}



function add_cb() {
	// we don't care..
}



var handle; // Var global wg. Klick on send
function add() {

	if (reverse == "reverse") {	
		elem = document.getElementById('wall');
		elem.scrollTop=0;;
	} else {
		elem = document.getElementById('wall');
		elem.scrollTop=elem.scrollHeight;	
	}
	line = document.getElementById("line").value;
	away_msg == "";
	
	holeCookie("watch");
	
	if (location.search.indexOf('room=Info') == -1) {
		if (away_msg == "weg"  && (isadmin < 1 || cookieWert != "on")) {line = "[hello2][<?php echo _AWAY_MSG; ?>][/hello2] ";}
		if (away_msg == "warm" && (isadmin < 1 || cookieWert != "on")) {line = "[hello2][<?php echo _WARM_MSG; ?>][/hello2] ";}
		if (away_msg == "re"   && (isadmin < 1 || cookieWert != "on")) {line = "[hello][<?php echo _RE_MSG; ?>][/hello] "; document.location.reload(false);}
	}

	if (cookieWert == "on" && line.indexOf("afk") != -1 ) {
		alert ("Away from keyboard (afk) nicht verwenden, wenn ghost-mode on.");
		document.getElementById("line").value = "";
		return;
	}


	handle = document.getElementById("handle").value;

	// Fluestern nur erlauben, wenn ein Admin beteiligt ist
	var user_whisper = "<?php if(isset($user_whisper)) echo $user_whisper; ?>";
	if (user_whisper == "admin") {
		if (line.indexOf("/pn") != -1) {
			if (isadmin != 1 ) { // der Admin darf alle anfluestern
				// suchen, ob einer der Admins angesprochen wird
				var at_admin = 0;
				for (var i = 0; i < all_admins.length; i++) {
					if (line.indexOf('@'+all_admins[i]+' ') != -1) {
						var at_admin = 1;
					}
				}
				if (at_admin != 1) {
					alert("<?php echo _WHISPERNOTALLOWED ?>");
					return;
				}
			}
		}
	}


	// nicht an mehrere Empfänger flüstern
	// und auch /pn @user1 @user2 bla bla unterbinden
	var count2 = (line.match(/@/g) || []).length;
	if (line.indexOf("/pn") != -1 && count2 >= 2) {
		alert ("Achtung! Du versuchst, mit mehr als einem User gleichzeitig zu flüstern! Das ist hier nicht erlaubt.");
		line = "";
	}


	// keine leere Nachricht zulassen:
	if (line == "" || line == "(<?php echo _MESSAGE; ?>)" ) {
		return;
	}
	
	if (line.indexOf("file://") != -1) {
		alert ("<?php echo _CHARNOTALLOWEDMSG; ?>");
		if (document.getElementById("line")) document.getElementById("line").value = "";

		return;
	}


	if (isadmin != 1) {
		if (line.indexOf("/add") != -1) { //muss hier bereits abgefangen werden wg. folgendem if
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
	}

	if (line.indexOf("/add ") != -1 && isadmin == 1 && allow_url_fopen != 1) {
		alert ("Dein Server erlaubt das leider nicht (allow_url_fopen=off)");
		if (document.getElementById("line")) document.getElementById("line").value = "";
		return;
	}


	// die Versionsanzeige
	<?php
	if (file_exists("chtver.php")) {
		include("chtver.php");
		$version = $chtver;
	} else {
		$version = "not defined";
	}
	?>

	if (line.indexOf("/pn") != -1 && line.indexOf("afk") != -1 ) {
		alert ("Away from keyboard (afk) darf nicht geflüstert werden.");
		document.getElementById("line").value = "";
		return;
	}
		  

	if (line.indexOf("/version") != -1) {
		alert ("Chat by webdesign.weisshart.de \nVersion: <?php echo $version; ?>");
		document.getElementById("line").value = "";
		return;
	}

	if (line.indexOf("/usr_smileys.php#") != -1 || line.indexOf("#a") != -1 ) {
		alert ("Drag & Drop von Smileys geht nur aus dem Nachrichtenfenster, \naber nicht von der Smiley-Leiste oder dem More Smileys Fenster.");
		document.getElementById("line").value = "";
		return;
	}


	var user_whisperroom = "<?php if(isset($user_whisperroom)) echo $user_whisperroom; ?>";
	if (user_whisperroom == "admin") {
		if (line.indexOf("_pr") != -1 && isadmin != 1) {
			alert ("<?php echo _WHISPERROOMSNOTALLOWED; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";
			return;
		}
	}

	var guest_write = "<?php if(isset($guest_write)) echo $guest_write; ?>";
	if (guest_write == "no" ) {
		var nickname = "<?php if(isset($nickname)) echo $nickname ?>";
		if (nickname.indexOf("Gast") !== -1) {
			alert ("<?php echo _READONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
	}



	Check = "true";
	if (isadmin == 1  && line.indexOf("/del ") != -1) {
		Check = confirm("<?php echo _DELROOM; ?>");
		if (Check == false) {
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
	}

	// mehr als 4 mal das gleiche Zeichen oder die gleiche Zeichenfolge (z.B. smileys) zurueckweisen und umwandeln
	if (isadmin != 1) {
		var re = new RegExp("(\.+)\\1{"+flood_test+",}"); 
		if (line.search(re) != -1 && line.indexOf("#") == -1  && line.indexOf("youtube") == -1) {
			alert("<?php echo _CHARREP; ?>");
			return;
		}
	}

	// mehr als 4 mal Leerraum oder Zeilenschaltung zurueckweisen und umwandeln
	if (isadmin != 1) {
		var re = new RegExp("(\\n+)\\1{"+flood_test+",}"); 
		if (line.search(re) != -1) {
			alert("<?php echo _CHARREP; ?>");
			return;
		}
	}


	// Schreien (nur Grossbuchstaben) zurueckweisen:
	if (isadmin != 1 && line.indexOf(")") == -1 && line.indexOf("(") == -1) {
		  
		line_no_digits = line.replace(/[0-9]/g, '');
		upper_line_no_digits = line.toUpperCase();
		if (line_no_digits === upper_line_no_digits && line.length > flood_test ) {
			alert("<?php echo _UPPERCASE; ?>");
		}
	}


	// Mehrfacheingabe von Upload oder sonstiger Links unterbinden
	if (line.lastIndexOf("http:") - line.indexOf("http:") > 0 && line.indexOf("smileys")  == -1  ) {
		alert("<?php echo _MULTURL; ?>");
		return;
	}


	if (line.indexOf("/away") != -1 ) { away();return false }

	if (line.toUpperCase().indexOf(" AFK") !== -1 || line.toUpperCase().indexOf(" A F K") !== -1 && line.indexOf(" ist ") == -1 && line.indexOf(" is ") == -1 && line.indexOf(" iss ") == -1 || line.toUpperCase() == "AFK" || line.toUpperCase() == "A F K" ) { away(); return false}

	if (line.indexOf("/ip") != -1) {
		document.cookie="showip=on; expires=" + ablauf2.toGMTString();
		document.location.reload(false); 
	}

	if (line.indexOf("/noip") != -1) {
		document.cookie="showip=off; expires=" + ablauf2.toGMTString();
		document.location.reload(false); 
	}

	if (line.indexOf("/go") != -1) {
//		document.cookie="stop=go";
		document.location.reload(true);
	}

      
	if (line.indexOf("/topic") != -1) {
		newline = str_replace("/topic","",line );

		if (document.getElementById('topic')) {
			document.getElementById('topic').innerHTML = newline;
		}
	}

	if (line.indexOf("/topicscroll") != -1 ) {
		newline = str_replace("/topicscroll","",line );

		if (document.getElementById('topic')) {
			document.getElementById('topic').innerHTML = '<span class="marquee"><span>' + newline + '</span></span>';
		}
	}


	// bestimmte Befehle zurueckweisen, wenn nicht Admin oder Mod:
	if (isadmin != 1 && ismod !=1) {
		if (line.indexOf("/ban") != -1
		|| line.indexOf("/kick") != -1
		|| line.indexOf("you've been kicked") != -1
		|| line.indexOf("/maulkorb") != -1
		|| line.indexOf("/maul") != -1
		) {
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
		
		p_room = "<?php if(isset($_SERVER['HTTP_REFERER'])) echo $_SERVER['HTTP_REFERER'] ?>";
		if (line.indexOf("/clear") != -1 && p_room.indexOf("_pr") == -1) {
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
		
	}
		
	// bestimmte Befehle zurueckweisen, wenn nicht Admin:
	if (isadmin != 1) {
		if (line.indexOf("/ghost") != -1
		|| line.indexOf("/peep") != -1
		|| line.indexOf("/nopeep") != -1
		|| line.indexOf("/ip") != -1
		|| line.indexOf("/noip") != -1
		|| line.indexOf("/approve") != -1
		|| line.indexOf("/offline") != -1
		|| line.indexOf("/del") != -1
		|| line.indexOf("/del_smiley") != -1
		|| line.indexOf("/archiv") != -1
		|| line.indexOf("/topic") != -1
		|| line.indexOf("/pixel") != -1
		|| line.indexOf("/alarm") != -1
		|| line.indexOf("/showprofil") != -1				
		|| line.indexOf("/profil") != -1				
		) {
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
		
		
		
		
		if (line.indexOf("img ") != -1
		|| line.indexOf(" src") != -1
		) {
			alert("<?php echo _NOHTML; ?>");
			return;
		} 

			
	}

	if (isadmin != 1 && ismod !=1) {
		if (line.indexOf("/erase") != -1 ) {
			alert("<?php echo _JSADMINONLY; ?>");
			return;
		}
	}



//	if (line.indexOf("/stop") != -1 ) {
//		alert("<?php echo _STOP_MSG; ?>");
//	}
	  



	// nicht erlaubte IRC Befehle zurueckweisen:
		

	nick_angemeldet = holeCookie("nick");
	var nickname = "<?php if (isset($nickname))echo $nickname ?>";
	hello = "yes";
	hello = "<?php if(isset($show_hello)) echo $show_hello ?>";
	ankunft = holeCookie("greeted"); // ein eigenes cookie fuer die Begruessung
	

	if(hello != "no" && cookieWert != "yes" && isadmin != 1 && line.indexOf('youtu') == -1 && location.search.indexOf('room=Info') == -1 && line.indexOf('[hello2]')== -1) { // die Begruessung macht den youtube link kaputt + keine Hello wenn Wärmestube
		//document.cookie="nick="+nickname;
		document.cookie="greeted=yes"; // Firefox loescht u. U. cookie am Sitzungsende nicht.
		
		x_add_line(handle + ": " + line, add_cb);
	} else {
		x_add_line(handle + ": " + line, add_cb);
	}

	
	// Anwesenheitscookie erneuern beim Schreiben einer msg
	var ablauf = new Date();
	var Minuten = ablauf.getTime() + (10 * 60 * 1000); 
	ablauf.setTime(Minuten);


	if (document.getElementById("line")) document.getElementById("line").value = "";
	
}

// der Versuch, eine Sperrdatei abzufragen
// https://stackoverflow.com/questions/3646914/how-do-i-check-if-file-exists-in-jquery-or-pure-javascript/11223909#
function UrlExists(url) {
	if(url){
		var req = new XMLHttpRequest();
		req.open('GET', url, false);
		//req.open('HEAD', url, false);
		req.send();
		return req.status==200;
	} else {
		return false;
	}
}





// http://hendi.name/2006/04/08/str_replace-fur-javascript/
// wird fuer die folgende function set_user benoetigt
function str_replace(search, replace, subject) {
	return subject.split(search).join(replace);
}

function set_user(result) {
//	if (UrlExists('lock_fh.txt')!== false) {	// wenn das Lockfile existiert, also immer, wenn nicht gerade jmd die function user_online() ausführt
		if (document.getElementById('uo')) {
			document.getElementById('uo').innerHTML = result;
		}
//	} 
}

function u_online() {
//	if (UrlExists('lock_fh.txt')!== false) {	// wenn das Lockfile existiert, also immer, wenn nicht gerade jmd die function user_online() ausführt
		x_user_online(set_user);
//	}
	
	// if (time1 < disconnect)	setTimeout("u_online()", time1 * 5.33); //dynamisch
	setTimeout("u_online()", 2000 * 3.33); //statisch

}


function set_user_room(result1) {
	if (document.getElementById('user_pro_room')) document.getElementById('user_pro_room').innerHTML = result1;
}

function u_online_room() {
	// per cookie den refresh vermeiden:
	// if (holeCookie) holeCookie("stop");
	// if (cookieWert != "stop") {
		x_user_room(set_user_room);
		setTimeout("u_online_room()", time1 * 8.33); //dynamisch
	// }
}


function ads(smiley) {
      if (document.getElementById('line').value.indexOf('<?php echo _MESSAGE; ?>') !== -1) {
		document.getElementById('line').value = "";
	}
	document.getElementById('line').focus();
	document.getElementById('line').value = document.getElementById('line').value + ' ' + smiley + ' ';
}

function max(e) {
	e.style.maxHeight="300px";
}


function pinnwand1 () {
    if (localStorage) {
		var w = localStorage.getItem("pop1_width") || 520;
		var h = localStorage.getItem("pop1_height") || 700;
		var l = localStorage.getItem("pop1_left") || 10;
		var t = localStorage.getItem("pop1_top") || 30;
		window.open("pinns/pinnwand1.php", "pinnwand1", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h +"");
	} else {
		window.open("pinns/pinnwand1.php", "pinnwand1", " width=520, height=700");
	}
}	

function pinnwand2 () {		
    if (localStorage) {
	var w = localStorage.getItem("pop2_width") || 520;
		var h = localStorage.getItem("pop2_height") || 700;
		var l = localStorage.getItem("pop2_left") || 10;
		var t = localStorage.getItem("pop2_top") || 30;
		window.open("pinns/pinnwand2.php", "pinnwand2", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h +"");
	} else {
		window.open("pinns/pinnwand2.php", "pinnwand", " width=520, height=700");
	}
}	

function smileybox () {	
	if (localStorage) {
		var w = localStorage.getItem("box_width") || 340;
		var h = localStorage.getItem("box_height") || 600;
		var l = localStorage.getItem("box_left") || screen.width * .7;
		var t = localStorage.getItem("box_top") || screen.height * .2;
		window.open("usr_smileys1.php", "smileybox", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h +"");
	} else {
		window.open("usr_smileys1.php", "smileybox", " width=340, height=600");
	}
}	

function prbox(e) {
	
	if (iOS !==true) { // do not use chat_pr on mobile, use skin7 instead
		e = e.replace("chat.php", "chat_pr.php");
	}
	
	if (localStorage) {
		var pw = localStorage.getItem("prbox_width") || 450;
		var ph = localStorage.getItem("prbox_height") || 600;
		var pl = localStorage.getItem("prbox_left") || screen.width * .5;
		var pt = localStorage.getItem("prbox_top") || screen.height * .2;
		window.open(e, "prbox", "top=" + pt + ", left=" + pl + ", width=" + pw + ", height=" + ph +"");
	} else {
		window.open(e, "prbox", " width=450, height=600");
	}
	
}

function load() {

	if (document.getElementById('jaws')) {
		//document.getElementById('jaws').setAttribute('aria-relevant', 'all');
		document.getElementById('jaws').setAttribute('aria-live', 'assertive');
	}
	var show_user;
	show_user = "<?php echo $show_user ?>";

	var show_rooms;
	show_rooms = "<?php echo $show_rooms ?>";

	var raum;
	if (window.location.search.indexOf("_pr") !== -1) raum = "pr";


//	setTimeout("changed_data()",1000);
	setTimeout("x_file_changed(set_file_changed)",1000);

	klapp('ae');


	var u_on_room = 1;
	if (sb == 1) u_on_room = 0;
	if (light == "yes") u_on_room = 0;
	if (show_rooms == "no") u_on_room = 0;
	if (raum == "pr" && show_rooms == "no" && isadmin != 1 ) u_on_room = 0;
	if (u_on_room == 1) u_online_room();


	var u_on = 1;
	//      if (sb == 1) u_on = 0;  // in der SB u_online zeigen, weil sonst ghost
	if (light == "yes") u_on = 0;
	if (show_user == "no") u_on = 0;
	if (u_on == 1) u_online();

//	if (light != "yes" && sb != 1) ZeitAnzeigen();

//	if (light != "yes" && sb != 1) UhrAnzeigen();
  
  
}


function ProfilOeffnen (Adresse) {
	var seconds = new Date().getTime() / 1000;
	MeinFenster = window.open(Adresse+"&test="+seconds, "Zweitfenster", "width=500,height=500,left=100,top=100");
	MeinFenster.focus();
}

function toggle_vid(e) {
	if (e.paused) {
		e.play();
	} else {
		e.pause();
		e.removeAttribute('playsinline');
	}
}


holeCookie("arrival");
if (cookieWert != "") {
	window.onload=load;
	  
} else {
	document.write('<p style="font-weight:bold; color:red"><br /><br /><?php echo _NOCOOKIE; ?><br /></p>');
}

if (document.getElementById("topicscroll")) {
	var laufschrift = document.getElementById("topicscroll");
	len = laufschrift.innerHTML.length;
	room = document.getElementById("wrapper").clientWidth;
		
	// console.log(room);	
	// console.log(len);
		
	if (len < (room / 7)) {
		document.getElementById("topicscroll").getElementsByTagName("span")[0].style.paddingLeft="0";
		document.getElementById("topicscroll").getElementsByTagName("span")[0].style.animation="0";	
	}
}
