function micoxUpload2(form,timeout,loading,callback,max_img_size,mp3allow,vidallow){
/**
* micoxUpload2 - Submete um form para um iframe oculto e pega o resultado. Consequentemente pode
*               ser usado pra fazer upload de arquivos de forma assíncrona.
* Versão: 2.0 - 02/01/2008
* Autor: Micox - www.elmicox.com - elmicox.blogspot.com
* Licença: Creative Commons - http://creativecommons.org/licenses/by/2.5/br/
* Some Rights Reserved - http://creativecommons.org/licenses/by/2.5/
**/

	// vor dem Upload die zulaessige Groesse checken:
	
	// Opera Mini und Coast frieren nach dem Alert ein
	var n = navigator.userAgent.indexOf("OPiOS"); 
	var m = navigator.userAgent.indexOf("Coast"); 
	
	
    var input = document.getElementById("file");
    // check for browser support (may need to be modified) IE? Chrome?
	
    if(input.files && input.files.length == 1 && n == -1 && m == -1) {           
        if (input.files[0].size > max_img_size*1.024*1024)  {
            alert("Die Datei darf nicht größer sein als " + (max_img_size/1024*1.024) + " MB");
            return false;
        }
		
        if (input.files[0].type != "audio/mpeg" && input.files[0].type != "audio/mp3" && input.files[0].type != "video/mp4" && input.files[0].type != "video/quicktime" && input.files[0].type != "image/png" && input.files[0].type != "image/gif" && input.files[0].type != "image/jpeg" && input.files[0].type != "image/pjpeg" && input.files[0].type != "image/bmp"   && n == -1 && m == -1  )  {

            alert("Dieser Dateityp (" + input.files[0].type + ") kann hier nicht hochgeladen werden.");
            return false;
        }				
		
        if ((input.files[0].type == "audio/mpeg" || input.files[0].type == "audio/mp3")   && mp3allow !=1 && n == -1 && m == -1)  {
            alert("Audios hochladen ist dir hier nicht erlaubt.");
            return false;
        }				

        if ((input.files[0].type == "video/mp4" || input.files[0].type == "video/quicktime")   && vidallow !=1 && n == -1 && m == -1)  {
            alert("Videos hochladen ist dir hier nicht erlaubt.");
            return false;
        }				
    }
	
	var $gE, addEvent, removeEvent, periodic, loadAnim, loaded, abortFrame; //small functions
	var error_prog = []; //errors by programer	
	var new_form, loading_msg, loadpos=0; //the new form that will replace old form AND loading msg
	var z, old_action, concat, timeload, timecounter=0, iframe, name;
	var loads = ['&nbsp;&nbsp;&nbsp;','.&nbsp;&nbsp;','..&nbsp;','...']; //loading animation
	
	/*** small functions */
	$gE = function(quem){ return document.getElementById(quem) }
	addEvent = function(obj, evType, fn){
		if (obj.addEventListener){ obj.addEventListener(evType, fn, true) ; }
		if (obj.attachEvent) { obj.attachEvent("on"+evType, fn);}
	}
	removeEvent = function( obj, type, fn ) {
		if ( obj.detachEvent ) { obj.detachEvent( 'on'+type, fn ); }
		if ( obj.removeEventListener ) { obj.removeEventListener( type, fn, false ); }
	} 
	loadAnim = function(){ //get animation of array loads
		if(loading.indexOf('<img')<0){ // 3 dots just if no image
			if(loadpos>loads.length - 1){ loadpos = 0; }
			return loads[loadpos++] + ' ';
		}else{ return '';}	
	}
	periodic = function(){
		timecounter++ ;
		if(timecounter/2 > timeout && timeout > 0){ //timeout expired (timeout = 0 is infinite)
			clearInterval(timeload); //fim do contador
			abortFrame(name);
			loaded('timeout');
		}
// wdw 12.11.09:		loading_msg.innerHTML = loading + ' ' + loadAnim();
//		loading_msg.innerHTML = "<img src=\"img/waiting.gif\">";
	}
	abortFrame = function(o_frame){ //stop iframe
		var o_frame = typeof(o_frame)=="string" ? $gE(o_frame):o_frame;
		if(!o_frame){ return false; }
		try{ o_frame.contentWindow.stop(); //FF e OP
		}catch(e){ 
			try{ o_frame.contentWindow.document.execCommand('stop');//IE
			} catch(e){ 	o_frame.src = ''; /* tenta parar mermo */ }
		}
	}
	cloneEvents = function(source2,target,recursive){
		for(var p in source2){ //all params
			try{if(source2[p].constructor==Function){
					target[p] = source2[p]
			}}catch(e){}
		}
		if(recursive){
			for(var el=0; el<source2.childNodes.length; el++){
				var elem = source2.childNodes[el]
				var elem_target = target.childNodes[el]
				if(elem.nodeType==1){
					cloneEvents(elem,elem_target);
				}
			}
		}
	}


	//testing callback
	if(typeof(callback)!='function'){ error_prog.push("The 'callback' parameter must be a function") }
	
	//testing if 'form' is a html object or a id string
	form = typeof(form)=="string" ? $gE(form):form;
	if(form.nodeName.toUpperCase()!='FORM'){
		error_prog.push("The first parameter must be a form element ID or a form element reference") }
		
	//testing if form have some input file
	var input_file = false;
	var infile = form.getElementsByTagName('input')
	for(z in infile){
		if(infile[z].type=='file'){
			if(infile[z].value==''){ 
//				alert("The input is empty. I cant upload this.")
				return true;
			}else{
				input_file = infile[z];
			}
		}
	}
	if(input_file==false){ error_prog.push("The form must be a input type file") }
	
	//exit if programmer errors
	if(error_prog.length>0) {
		alert("Error in parameters of micoxUpload:\n\n" + error_prog.join('\n'));
		/* uncoment this if you want use try-catch-throw
		throw(error_prog.join('\n'))		*/		
		return true;		
	}
		
	//random id for multiple calls
	rand = (m=Math).round( 20 * m.random() );
	
	//adding callback function to global scope
	//window['micoxCallbackTemp' + rand] = callback
	
	//creating the iframe
	name = "micox-temp" + rand;
	iframe = document.createElement("iframe");
	iframe.setAttribute("id",name);
	iframe.setAttribute("name",name);
	iframe.setAttribute("width","0");
	iframe.setAttribute("height","0");
	iframe.setAttribute("border","0");
	iframe.setAttribute("style","width: 0; height: 0; border: none;");
	//add to document
	form.parentNode.appendChild(iframe);
	window.frames[name].name = name; //ie sucks
		
	//event after load
	loaded = function(){
		//var iframe2 = $gE(name);
		clearInterval(timeload); //fim do contador
		//first, removing the event of iframe
		removeEvent(iframe,'load',loaded)
		//removind loading msg
		loading_msg.parentNode.removeChild(loading_msg);
		//removing old form
		//form.parentNode.removeChild(form);	
		
		//calling callback with the return
		if(arguments[0]!='timeout'){
			callback(iframe.contentWindow.document.body.innerHTML);
		}else{
			callback('Timeout expired. ' + timeout + ' secs.');
		}
		
		//removing old iframe
		abortFrame(iframe);
		iframe.src=''; //to stop 'loadind' in FF. bug.
		iframe.parentNode.removeChild(iframe);
		delete iframe;
	}
	//adding the event
	addEvent(iframe,'load',loaded)
	
	//properties of form to a normal upload
	form.setAttribute("target",name);
	form.setAttribute("method","post");
	form.setAttribute("enctype","multipart/form-data");
	form.setAttribute("encoding","multipart/form-data");
	//aditional information if micoxUpload
	old_action = form.action;
	if(form.action.indexOf('?')>1){ concat = '&' } else { concat = '?' }
// wdw 12.11.09:	form.setAttribute("action",form.action + concat + 'micoxUpload=1');
	form.setAttribute("action",form.action);

	//submit
	form.submit();
	
	//make loading
	loading_msg = document.createElement('div');
// wdw 12.11.09:	loading_msg.innerHTML = loading;
   loading_msg.innerHTML = "<img src=\"img/waiting.gif\" alt=\"\" border=\"0\" width=\"95\" height=\"11\" />";

	form.parentNode.insertBefore(loading_msg,form);
	//making new form and hidden old form
	input_file.value='';
	form.reset();
	new_form = form.cloneNode(true);
	cloneEvents(form,new_form,true);
	new_form.reset();
	new_form.action = old_action;
	form.style.display = 'none';
	form.parentNode.insertBefore(new_form,form);
	//if you want new input file before the 'loading div', use this above (invert the comment)
	//form.parentNode.insertBefore(new_form,loading_msg);
	

// if (navigator.userAgent.toLowerCase().indexOf('opera') !== -1) {
//    alert("Upload starten - Hinweis ist nur fuer Opera erforderlich - Paranoia");
// }
	timeload = setInterval(periodic,500);
	
	//no submit default
	return false;
	
}