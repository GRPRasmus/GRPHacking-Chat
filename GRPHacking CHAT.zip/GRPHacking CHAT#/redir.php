<?php	
header('Content-type: text/html; charset=utf-8');

if (isset($stil) && $stil <> 0) {
        $s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
        $s = $default_skin;
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">

<head>
<meta http-equiv="content-type" content="application/xhtml+xml;charset=utf-8" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" /> 
<title>Der Chat von webdesign.weisshart.de</title>
<link rel="shortcut icon" href="favicon.ico" /> 
<link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" />
<link rel="stylesheet" type="text/css" title="handheld" media="handheld" href="chatcss7.php" />

<style type="text/css">
       body {margin: 10px;}
</style>

</head>
<body>
<?php
if(isset($_GET["l"])) {
	if ($_GET["l"] != "") {
		$link = $_GET["l"];
		echo "<p>Du verl&auml;sst jetzt den Chat.</p>";
		echo "<p><br />Bitte klick den folgenden Link: <a href=\"$link\">$link</a></p>";
		echo "<p>Oder hier, um den Link in einem neuen Fenster zu &ouml;ffnen: <a href=\"$link\" target=\"_blank\">$link</a></p>";
		echo "<p style = \"margin: 2em 0\"><a href=\"javascript:history.back()\">zur&uuml;ck zum Chat</a> (oder dieses Fenster / diesen Tab schlie&szlig;en, wenn ein neues Fenster / neuer Tab ge&ouml;ffnet wurde.)</p>";


	}
}
?>
<p class = "klein">Hinweis: Der Umweg &uuml;ber diese Seite ist erforderlich, um den Namen des privaten Raums geheim zu halten.</p>
</body>
</html>