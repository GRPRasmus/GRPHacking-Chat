<?php
########################################
# die Konfigurationsdatei für den Chat von webdesign.weisshart.de
# NUR mit einem Texteditor bearbeiten!
#
# bitte zuerst den Chat zum Laufen bringen wie in der readme. txt beschrieben!
# dann diese Konfigurationsdatei am besten der Reihe nach bearbeiten
# und nach JEDER Änderung testen.
# (Zeilen, die mit # beginnen, sind Kommentarzeilen ohne Funktion)
# (alles, was hinter // kommt, ist Kommentar)
# ... und die Kommentare hab ich nicht geschrieben, weil mir langweilig war, sondern damit du sie liest!
#
# wenn du etwas PHP kannst, dann lies bitte zuerst den Hinweis ganz am Ende dieser Datei!
# ---------------------------
# This is the configuration file for the webdesign.weisshart.de chat
# To edit it use a plain text editor!
#
# Before editing anything, make sure that the chat is installed as described in the readme_en.txt and functioning properly
# Edit step by step and check the functioning after every change.
# (Lines beginning with # are comment lines)
# (everything that is behind // is a comment)
#
# if you know some PHP, please read the note at the end of this file!
########################################

#########################################
# Die Admins. Jede Zeile steht für einen Admin.
# du kannst beliebig viele Namen hinzufügen oder löschen.
# Achtung: die letzte Zeile ohne Komma am Ende!
# Achtung! Jeden Admin zusätzlich mit Passwort registrieren, um Missbrauch zu vermeiden.
# -----------
# Admin nicks. One line per admin nick.
# Important: no closing comma in last line!
# Important! Register every admin nick in reg.php to avoid misuse! 


$admins = array(
    'Max',
    'Moritz',           
    'Heidi'              
);


#########################################
# wie sollen Admins in der user online Anzeige gekennzeichnet werden:
# ---------
# Labeling admins in the user online display:

$admin_mark = "[Admin]";                // $admin_mark = ""; kennzeichnet die Admins nicht speziell // $admin_mark = ""; no admin label
$mod_mark = "[Mod]";                // $mod_mark = ""; kennzeichnet die Mods nicht speziell // $mod_mark = ""; no mod label


#########################################
# jetzt grundlegende Einstellungen - das Aussehen des Chat
#########################################

#########################################
# Welche Sprachen sollen angezeigt werden (Sprachumschaltung mit Flaggensymbolen)
# bisher verfügbar: Deutsch (de), Englisch (en), Spanisch (es)
# --------
# Language switching
# available: German (de), English (en), Spanish (es)

$languages = array(
   'de',
   'en'             // und wieder: die letzte Zeile ohne Komma! // no closing comma in last line!
);

# wenn in diesem array nur eine Sprache steht, werden keine Flaggen zur Sprachumschaltung angezeigt
# If only one language is in the array no flags for languge switching will be shown


#########################################
error_reporting(0);

# (E_ALL) um alle Fehlermeldungen anzuzeigen.
# Diese Fehlermeldungen sind insbesondere bei Supportanfragen hilfreich.
# (0) um alle Fehlermeldungen auszublenden
# ----------
# (E_ALL) show all error messages.
# may be helpful in case you need support
# (0) show no error messages

#########################################


date_default_timezone_set("Europe/Berlin");


# der Skinswitcher:

$stil = 0;

# 0: Skinswitcher einschalten (user kann den Skin wählen) - skinswitcher enabled

# 3 bis 13: Skin fest eingestellt und vom user nicht wählbar
# ------
# 3 thru 13: Skin preset, skin switcher disabled

#   3: Skin Web2
#   4: Skin Black
#   5: Skin Stage
#   6: Skin Flowers
#   7: Skin Mobil (wird auf PDAs und Handys immer automatisch verwendet!)
#   8: Skin Firebox
#  10: Skin Sky
#  11: Skin Invers
#  12: Skin bf-Linear
#  13: Skin Messenger

$default_skin = 8;  // dieser Skin wird voreingestellt, wenn $stil = 0, und solange der user keinen anderen Skin wählt.
					// default skin if $stil = 0, i.e. with skin switcher enabled

# Achtung! Wenn der Skin 12 fest oder voreingestellt wird, dann MUSS der Chat mit /chat-bf.php aufgerufen werden!


#########################################
# Die Überschrift - damit Deine Besucher wissen, wo sie sind ;-)
# Headline

$titel = "Unser Chat";

# wenn $titel = ""; dann wird der Titel nicht angezeigt.
# If $titel = ""; no headline is shown                        


#########################################
$chat_light = "no";	   // yes, dann hast Du einen Chat-light ohne Räume und ohne Optionen // if "yes": chat light w/o rooms and options
#########################################

# weitere Einstellungen zum Aussehen:
# Design:

$hoehe = 22;	        // Die Höhe des Chatfensters in Zeilen (circa - Wert, nicht alle Styles) // heigth in lines (approx.) most styles
                        // bitte setze diesen Wert nicht zu hoch: nicht jeder hat einen 20 Zoll Bildschirm!

$anz_msg = "40";		// Anzahl der angezeigten Meldungen (mit Scrollen) // number of messages displayes w/ scrolling - max. 100
						// wenn das Nachrichtenfenster nicht mehr richtig scrollt, dann hast Du hier wahrscheinlich übertrieben

				   
$user_hoehe = 14;       // einige Skins verwenden diesen Wert für die Höhe der user online Anzeige // height of user online display in some skins

$max_length = 500;		// Max. Anzahl Zeichen pro Nachricht // max. length of message

$anz_rooms = 3;		    // max. Anzahl der ohne Scrollen angezeigten (öffentlichen) Räume (nur einige Skins) // number of rooms displayed w/o scrolling (some skins)
						// wenn 0, dann wird Raumliste nicht angezeigt. Performace-Verbesserung // if 0, hide romm list.

$show_rooms = "yes";    // "yes/no" - Die Raumliste auch in privaten Räumen zeigen (wenn nur ein Raum existiert, ist die Raumliste immer ausgeschaltet)
                        // Admin sieht die Raumliste immer
						// show list of rooms when in a private room 
						// list of rooms always visible to admin

$show_user = "yes";     // "yes/no" - Ausschalten kann sinnvoll sein z. B. in moderierten Chats. Bei "no" greift Begrenzung durch $maxuser nicht!
                        // "no" can make sense in moderated chat rooms 
$maxuser = 15;          // maximale Anzahl erlaubter user // limit of users allowed to login


$hilfetexte = "on";	    // "on/off" - Hilfe anzeigen - aber wenn du die Hilfe ausschaltest, dann frag bitte auch nicht, wie dieser oder jener Befehl lautet.
						// show online help


$nickcolors = "on";	    // "on/off" - Ausklappmenü für Nickfarben anzeigen // enable dropdown menu nick colors

//$schrift = 100;		// nicht mehr verwendet. Schriftgroesse wird vom User eingestellt.

$ip = "on";             // "on/off" - IP anzeigen // display IP

$time_offset = 0;       // Zeitverschiebung gegenüber Serverzeit in Stunden // set server time offset

$smileys = "on";		// "on/off" - Smileys zulassen // show smileys

$more_smileys = "on";	// "on/off" - more_smileys zeigen // show/hide more_smileys

$more_smiley_width = 0.45;  // die Breite des more smiley popup // width of more smilies popup
$more_smiley_height = 0.75; // und die Hoehe // heigth of more smilies popup

$show_sb = true;		// schreibt (sb) hinter jede Nachricht aus der Shoutbox // add (sb) behind shoutbox messages

$display_reverse_user = true; // fuegt die Anzeigeoption "Eingabezeile oben/unten" hinzu



##########################################
# die Sounds:
# die mp3 Dateien durch eigene ersetzen, oder aus den verfügbaren Dateien im Ordner /sounds wählen.
# einzelne Sounds ausschalten durch $soundx = "0.mp3";

# --------------
# choose event sounds from the sounds available in the directory /sounds
# disable individual sounds by setting $soundx = "0.mp3";


$sound1 = "sounds/reload2.mp3";   // Du betrittst einen Raums // you enter a room, or a file upload is ready
$sound2 = "sounds/sound21.mp3";  // User betritt den Raum // another user enters
$sound4 = "sounds/eingang.mp3";   // Eingang einer anderen Meldung // new message
$sound5 = "sounds/sound10.mp3";   // User verlaesst den Raum // user quits room
$sound6 = "sounds/alarm3.mp3";    // der Alarm // not used




#########################################
# die Moderatorfunktion: alle Beiträge müssen vom Admin mit /approve freigegeben werden, siehe Hilfe.
# Anm.: die Moderatorfunktion ist nur für die kommerzielle Lizenz auf Anforderung verfügbar.
# ---------------
# moderated rooms: messages must be released by admin - feature only availabe w/ commercial licence
#########################################



##########################################
# was ist erlaubt / verboten - allowed / forbidden
##########################################


$allowguest = "yes";          // no: nur registrierte user zulassen
                              // yes: auch Gäste zulassen

# verbotene Nicks /unabhaengig von Gross-/Kleinschreibung):
# Admins und registrierte user sind automatisch verboten
# ----
# forbidden nicknames, case insensitive
# registerd admin nicknames are automatically forbidden

$nicknotallowed = array(
    'admin',
    'nickname',
    'nick',
	'gast',
    'einandererverbotenernick'                   // wie immer: letzte Zeile kein Komma!
);

$imginclude = "yes";          // "yes/no" Bilder einbinden zulassen, und das Upload Feld anzeigen. // allow images and show upload field
                              // Admin kann immer Bilder einfügen/ Dateien uploaden // admin may upload no matter how this variable is set.
                              // Achtung! das Einbinden von Bildern erzeugt hohe CPU Last auf dem Server und beim Besucher!
							  // Note: images create heavy CPU load on the server as well as on the client side!
                              
$imginclude_pr = "yes";        // wie $imginclude, für private Räume // same as $imginclude but for private rooms


$maxwidth = 250;              // die max. angezeigte Breite der eingefügten Bilder // max width of inline display of images - max. 400
$maxheight = 120;             // die max. angezeigte Höhe // max height - max. 200

$show_x = 800;                // die max. Breite des Popups der eingefügten Bilder // max width of imaged popup - max. 1200
$max_y = 600;                 // die max. Höhe // max height - max. 900


$maxsize = 2000;              // max. Dateigröße für Upload (Bilder und mp3) in kB // max upload file size 
                              // bitte beachte die max. Upload-Größe deines Servers (Voreinstellung oft 2000 kB) // max server side upload file size applies. Common default value: 2000 kB 
                              // und memory_limit.
                              // $maxsize sollte nicht größer sein als 20% von memory_limit // $maxsize should not exceed PHP 20% of PHP memory_limit

 
$links = "yes";               // "yes/no" Links erlauben (in privaten Räumen sind Links immer erlaubt) // allow links

$mp3allow = "";           	  // "alle" - Alle dürfen in allen Räumen mp3 hochladen // mp3 upload allowed in all rooms/all users
                              // "clean" - mp3 hochladen erlaubt in privaten Räumen und "Clean Rooms", Admins in allen Räumen 
							  // mp3 upload in clean rooms and private rooms only (admins all rooms)
							
                              // "admins" - nur Admins dürfen mp3 hochladen (in allen Räumen) // mp3 upload admmins only
                              // "" - kein mp3 Uplodad // mp3 upload not allowed

$vidallow = "clean";         // "alle" - Alle dürfen in allen Räumen Videos hochladen
                            // "clean" - Videos hochladen erlaubt in privaten Räumen, clean rooms, Admins in allen Raeumen
                            // "admins" - nur Admins dürfen Videos hochladen (in allen Räumen)
                            // "" - kein Video Uplodad

$show_player = true;		  // mp3 Player anzeigen // show mp3 player
$gema = false;				  // true: es wird immer nur 1 mp3 angezeigt, damit der guenstigste GEMA Tarif beantragt werden kann // applicable for german GEMA only

// wenn mehr als 1 Smiley-Verzeichnis benutzt werden soll 
$smiley_dirs = array(
   'Smileys 1',
   'Smileys 2',
   'Smileys 3'
);



##########################################
# weitere Einstellungen
##########################################

$show_hello ="yes";           // "yes/no" - Begruessungstext zeigen 

$logfile = "off";               // "on/off" - Logfiles schreiben, wenn die Anzahl gespeicherter Meldungen überschritten ist.
                                // Achtung! Logfiles können SEHR viel Speicher belegen, und werden erst nach 180 Tagen automatisch gelöscht
                                // Achtung! bitte Logfiles nur bei echtem Bedarf aktivieren, kann auf schwachen Servern zu Problemen führen
                                // zum komfortablen Lesen der Logfiles gibt es für lizensierte User ein Script. Bitte anfragen
                                // ----------
								// create Logfiles. Note: disable logfiles to decrease server load
								
$clean = 720*3;   		  // nach so vielen Stunden Inaktivität öffentliche Räume löschen // hours before public rooms are deleted
$clean_priv = 0.5;	        // nach so vielen Stunden Inaktivität private Räume löschen // hours before private rooms are deleted


# der Chatraum soll nach dem Einloggen erst mal leer sein:
# der Admin sieht natürlich auch alte Beiträge
# --------
# show blank room after log in. (Admin sees old messages)
$blankrooms = "no";            // "yes/no" - "yes": alle Räume sind nach dem Login leer

$blankroom = array(            // nur die hier gelisteten Räume sind nach dem Login leer // define individual rooms to be blankrooms
    'CleanRoom',
    'NochnRaum'               // wie immer: letzte Zeile kein Komma!
);



$flood = 1;	       		 // Floodingsperre in Sekunden. // flooding protection in seconds
                               // 0 = Floodingsperre aus // flooding protection off
                               // beim Admin greift die Floodingsperre natürlich nicht // flooding protection does not apply to admins

$standard = "Standard";        // der Name des Standardraums // name of standard room
                               // Achtung! der Raum muß bereits angelegt sein. Wie das geht, steht in der Hilfe
							   // Attention. The room must exist before setting it here. Refer to online help to create rooms

$bantime = 3;		       // Dauer des bans oder kicks in Minuten, wenn keine Zeit angegeben wird // dafault ban time in mins
                               // siehe Hilfe // refer to online help
                                
$new_win = "yes";	             // "yes/no" - Links in einem neuen Fenster öffnen // open links in a new window/tab

$noframe = true;               // Der Framebuster: falls  der Chat in einem Frame angezeigt wird
                               // und Frameset und Chat auf dem gleichen Server laufen, auf true belassen
                               // false: wenn Frameset und Chat auf verschiedenen Servern laufen.
							   // ab Firefox-Version 22 IMMER auf TRUE belassen, weil Firefox 22 keine Cookies von Drittanbietern mehr akzeptiert, 
							   // und der Chat dann nicht mehr läuft! 	
							   // ---------
							   // framebuster if chat is displayed in a frame
							   // set to true, if chat and frameset run on the same server, false if different servers


$pnlivetime = 60;             // Lebensdauer von privaten Nachrichten in Sekunden. // private message live time

$closepr = "no";               // "yes/no" sollen mit /offline auch private Räume gesperrt werden? // disable private rooms with /offline command

$refresh = 2000;               // das refresh-Intervall in Millisekunden // refresh in millisecs
                               // ACHTUNG! kleine Werte treiben den Traffic in die Höhe! // lower values increase traffic
                               // Sinnvolle Werte: 500 bis 2000 // recommended: 500 to 2000

$slowdown = 3;                 // Der Chat wird bei Inaktivität (niemand schreibt) immer langsamer,
                               // und je nach dem eingestellten Wert deaktiviert (die "Wärmestube").
							   // Details hierzu: https://forum.weisshart.de/index.php?id=4
                               // (jede geschriebene Nachricht macht den Chat wieder schnell)
                               // dies spart Traffic auf dem Server und beim user
                               // mit $slowdown = 0; wird diese Funktion deaktiviert.
							   // ---------
							   // decrease traffic thru gradual decrease of refresh, when chat is inactiv (no messages posted)
							   // after $slowdown chat will be deactivated (no traffic at all)
							   // new message reactivates the chat.
							   // $slowdown = 0; disables this feature


// $klapp_options = true;         // true/false Die Anzeigeoptionen klappbar machen // toggle dropdown view of options
$onmouseoveroptions = false;   // true: onmouseover für Anzeigeoptionen // enable on mouse over toggle display of options 

$ip_write = false;			   // true: IP für Admin in die Nachricht schreiben. // append IP to message, admin only


##########################################
# wenn du dir eine solche personal_config_inc-Datei auch anlegst,
# und dort nur die von dir geänderten Variablen reinstellst,
# dann kannst du bei zukünftigen updates die Konfigurationsdatei chat_inc.php (diese Datei) auch überschreiben lassen.
# deine privaten Einstellungen bleiben dann erhalten
# ein Beispiel liegt bei als personal_muster_config_inc.php.
# In diese Datei kopiere alle Variablen, die du anpassen willst, und benenne die Datei dann in personal_config_inc.php um.
# ----
# A config file named personal_config_inc.php will only hold your modifications.
# This is usefull in case you update the chat to a new version, because the personal_config_inc.php will not be overwritten by the update.
# To create a personal config_inc.php you could start with the personal_muster_config.php, 
# modify it to your needs, i.e. copy every variable you want to modify from the chat_config.php, set it to to your preference, 
# and rename it to personal_config_inc.php 
##########################################

if (file_exists("personal_config_inc.php")){include ("personal_config_inc.php");}
?>