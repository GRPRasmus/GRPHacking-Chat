<?php

// Sendezeitbeschr�nkung Bilder:
$jmstv_start = 22; // ab dieser Uhrzeit werden Bilder unverpixelt gezeigt
$jmstv_end   = 6;  // ab dieser Uhrzeit werden Bilder verpixelt


?>