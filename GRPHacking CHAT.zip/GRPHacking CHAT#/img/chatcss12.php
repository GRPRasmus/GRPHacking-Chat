<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");


$font_size = "1";
if (isset($_COOKIE["size"]) && $_COOKIE["size"] == "200") {
	$font_size = "1.7";
} elseif (isset($_COOKIE["size"]) && $_COOKIE["size"] == "300") {
	$font_size = "2.5";
} elseif (isset($_COOKIE["size"]) && $_COOKIE["size"] == "100") {
	$font_size = "1";
}


?>

/* CSS fuer Skin 12 Linear */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol, span, form, li, fieldset, input {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #06AEFF; /* die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */

}


img {
	border:0;
	margin:0;
	padding:0;
}

html {
	padding: 10px 10px 0 10px;
	/* overflow: auto; */ /* verhindert zwar den Geisterscrollbalken im IE, macht aber sonst nur Aerger */
}

body {
	font-size:<?php $size= $schrift * $font_size * 1.4; echo $size; ?>.01%;
	background:#000; 	/* hier die Hintergrundfarbe fuer die Seite */
}



h1 {
font-size:.9em;
letter-spacing: 1px;
color: #ff7;
margin-bottom: 0 !important;
max-width: 100% !important;
}
h1 span {color:#06AEFF}

h2 {
	font-size:.8em;
	line-height:125%;
}

.rooms h2 {margin-top:1em;}

/*.bg {background:#2a2a2a}*/

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #help tr, #upload input  {
	font-size:.8em;
	margin-bottom: .1em;
}

fieldset fieldset a {text-decoration:none;}

a {color:#fff}
a:link, a:visited {}
a:focus, a:hover {background:#00f;}

:focus {
outline: 2px solid #ff7;
}

.away,
#addsmileys a:visited span{display:none !important}
#addsmileys a:hover {background:none}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
}

#user_pro_room em:after { /* das geht natuerlich im IE nicht */
	content:"\00A0\221A";
}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}


ul {
	font-size:.8em;
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}

hr {
	display:none;
}


fieldset {
	clear: right;
	margin:0 0 3px 0;
	padding: 3px;
	width: 99% !important;
}



/* Op hack: */
html:first-child>b\ody fieldset fieldset {
	 /* margin-left: 79%; */
}


#wrapper {
	padding-top: 8px;
	border:1px solid #888;
}

#wrapper:after, #opt:after { /* der Konq braucht das 1., der Op das 2. */
	content : ".";		
	display : block; 
	height : 0; 
	clear : both; 
	visibility : hidden;
}

/* Hides from IE-mac \*/
* html #opt {height: 1%;}
/* End hide from IE-mac */
/* End Op hacks */


.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #aaa;
}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {
	margin: 0 3px 3px 0;
	width: 98% !important;
	
}

#wall {
	height: <?php echo $hoehe-8 - 3*$font_size ?>em;
	height: <?php echo 18 - 5*$font_size ?>em;
	width: 98% !important;
	
	background:#000;		/* die Hintergrundfarbe fuer das Nachrichtenfenster */
	overflow: auto;
	margin: -1em 1em 1em 0;
	padding: .3em;
	line-height: 1em;
}

#wall p {
        /* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 .8em;
	text-indent: -.8em;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#line {
	width: 72%;
}



#ton {
	width: 0;
	height: 0;
}


#uo {
	display: inline;
	margin-top: .3em;
}

html:first-child>b\ody #uo { /* Opera Hack */
      overflow: auto;
}

#uo ul, #uo ul li {
	/* display: inline; */
	font-size:100%;
}
#uo ul, #user_pro_room ul, #opt form p {
	padding: .2em 0 .25em 0;
}
#uo span {margin-right: 5em} /* Hack, um <br> zu emulieren */


#user_pro_room ul li {
        padding:0;
        line-height:1.3em;
}
* html #user_pro_room ul li {
        line-height:1.2em;
}

#addsmileys {
	float:left;
	margin: 5px 0 0 15px;
}


dfn, .dot, #upload {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


#f {margin-left:10px;}

#opt input[type=submit] {margin-top:3px}


/* so wills der IE */
#talk input, .rooms input {
       color:#fff;
       background:#333;
       border:1px solid #888;
}

input.button {
       cursor:pointer;
}


#datum, #uhr, #sound, #nickfarben {
      border: 0;
      background: transparent;
}

#line, #handle, #room {
       border: 1px solid #888;
       padding: 2px 0 2px 3px;
       color:#fff;
       background:#000;
       cursor:text;
}

label, select {
       cursor:pointer;
}
label {margin:0 3px}


#menu1 {float: left;}
x#menu2 {float:left; margin-right: 1em;}


.uolist {display:none;}
#upload {padding:3px 0 0 9px; margin-top: 10px;}

#logout, .logout {
        text-align:center;
        margin:4px 18px 4px 0;
        border: 2px outset #eee;
        background-color: #000;
		width: 13em;
}
#logout a, .logout a {
        display:block;
        text-decoration:none;
        padding:0 0 2px 0;
}

.button {padding: 1px; margin-left:3px;}

/* die Einstellungen fuer high contrast */
#wrapper,
#wall
{background: #004}

/* p {color:#000} */

#wrapper p,
#wrapper p span,
legend,
#uo li,
#uo span,
#uo a,
#user_pro_room a
{color: #ff8 !important; line-height:1.5em;}


#wall p, #wall p span
{line-height: 1.8em !important;}

#uo,
#user_pro_room em,
#f p span {color:#f60 !important}

legend {padding:0}

h2 {font-size: .9em; margin-bottom: .3em;}
h2, h2 span {color: #ddd !important}

p span span,
#wall p span span span,
#wall p span span
{color: #ff8 !important; background: #00f !important}

#form {display:none}


/* .bg {background: #006} */

#file {
        background: transparent !important;
        border:2px solid transparent !important;
}
* html #file {border: 2px solid #004 !important}

fieldset #upload {
margin-left: 10px;
padding: 5px;
border: 1px solid #888;
}
* html fieldset #upload {margin-left: 5px;}
.helplinks p, .helplinks p a {background: black; color:white;}
.helplinks p a:focus,
.helplinks p a:hover,
.helplinks p a:active
 {background: #00a; text-decoration:none;}

#wall p span span {background-color: transparent !important}

select {
color:white;
background:black;
}

.helplinks p a{margin-bottom:1em;}

/* Zusatz fuer css12
#talk {
width: 100% !important
}
*/

.rooms {
margin-left: 7px;
width: 15em;
}

#uo, #user_pro_room {
height: auto;
}

/* speziell fuer stark Sehbehinderte mit Lupe:
ersetzt durch immer Eingabe oben

#jaws {
position: static !important;padding-left:10px !important;
width: 80%;
}
*/


#f p span,
#addsmileys,
.rooms img
 {display:none}

#line, #menu2, #room, .button, #handle {
font-size: 100%;
}
#mp3 {
margin: .5em;
}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio_neg.gif);
background-repeat:no-repeat;
background-position: 0 50% ;
}


#upload, #upload2,.opt, x#einaus_ae {display:none !important}

#topic {
margin:0 0 5px 12px;
font-weight:bold;
}

.sizer h3 {display:inline-block; color:#eee;}
.sizer a, .sizer span {margin-left:.3em;}
.sizer span {color: #555;}

textarea{font-size: <?php echo $font_size; ?> !important;