<?php
// Hier kannst du smileys und andere Tastaturkuerzel hinzufuegen, aendern oder loeschen:
// als erstes das Tastaturkuerzel.
// am einfachsten fuegst du neue Zeilen an den Beginn des Arrays ein.
// einfach die Zeile mit dem ersten Kuerzel nach oben kopieren
// (dazu hab ich schon zwei Zeilen freigehalten)
//und nach deinen Wuenschen aendern.

$arrSearch = array(


	' ka ',
	' kA ',
	' afk',
	' btk',
	' omg ',
	' wlkikiv',
	' rtfm',
	':br:',
	'vllt ',
	'vlt ',
	'funz',
	'Funz',
	'FUNZ',
	'evtl. ',
	'evtl ',
	'&lt;-',
	' -&gt;',
	' readme.txt',
	' help.php',
	' faq.php',
	' /forum',
	'[en]',
	'[/en]',
	'[hello]',
	'[/hello]',
	

	';-)',
	':-)',
	':evil',
	':? ',
	'8-)',
	':8)',
	':-(',
	':( ',
	':D ',
	':-D',
	':p ',
	':P ',
	':oops',
	':=)',
	':rofl',
	':cry',
	':lol',
	':bussi',
	':-*',
	':wand',
	':wink',
	':bye',
	':emo',
	':anders',
	'##:santa',
	':bier ',
	':wein ',
	':bayern ',
	':deutsch ',
	':warten ',
	':bass ',
	':band ',
	':baby ',
	':help ',
	':snoopy',
	':bahnhof ',
	':fcb',
	':tel ',
	':gruebel ',
	'/time ',
	'/hallo ',
	'^^',
	'weiblich',
	'männlich',
	':ghost',
	'v.1.',
	':schnitzel ',
	'&lt;3',


	':) '
);










// jetzt einfuegen, womit das Tastaturkuerzel ersetzt werden soll. Entweder einen Text, oder ein Bild.
// such eine passende Musterzeile, kopiere sie gleich an den Anfang des Arrays, und passe sie entsprechend an.
// und wenn du nicht die gleiche Reihenfolge wie im ersten Array einhaeltst, dann faellt dir der Himmel auf den Kopf ;-)
// dass die Datei mit dem entsprechenden smiley auf deinem Server liegen muss, is eh klar :-)
// HInweis: die Ersetzungen stehen GENAU 100 Zeilen tiefer als das zu ersetzende Kuerzel
// so findet man die zusammengehoerigen Paare leichter.


$arrReplace = array(


	' <abbr title =" keine Ahnung" style="cursor:help; border-bottom: 1px dashed #555;"> kA </abbr>',
	' <abbr title =" keine Ahnung" style="cursor:help; border-bottom: 1px dashed #555;"> kA </abbr>',
	' <abbr title =" away from keyboard" style="cursor:help; border-bottom: 1px dashed #555;"> afk </abbr>',
	' <abbr title =" back to keyboard" style="cursor:help; border-bottom: 1px dashed #555;"> btk </abbr>',
	' <abbr title =" oh my god" style="cursor:help; border-bottom: 1px dashed #555;"> omg </abbr>',
	' <abbr title =" Wer lesen kann ist klar im Vorteil" style="cursor:help; border-bottom: 1px dashed #555;"> wlkikiv </abbr>',
 	' <abbr title =" read the f*** manual" style="cursor:help; border-bottom: 1px dashed #555;"> rtfm </abbr>',
	'<br />',
	'vielleicht ',
	'vielleicht ',
	'funktionier',
	'Funktionier',
	'FUNKTIONIER',
	'eventuell ',
	'eventuell ',
	'<span style="font-family:Arial">◄</span>',
	'<span style="font-family:Arial"> ►</span>',
	' <a href="http://webdesign.weisshart.de/chat/readme.txt" target="_blank">readme.txt</a>',
	' <a href="http://webdesign.weisshart.de/chat/help.php" target="_blank">Hilfe</a>',
	' <a href="http://webdesign.weisshart.de/chat-faq.php" target="_blank"><abbr lang="en" title="frequently asked questions">FAQ</abbr></a>',
	' <a href="http://webdesign.weisshart.de/forum" target="_blank"> Support Forum</a>',
    '<span lang="en">',
    '</span>',
	'<span class="hello">',
	'</span>',


	' <img src="img/smile_zwinker.gif" title="zwinkert" alt="Smiley: zwinkert" width="15" height="15"/> ',
	' <img src="img/smile.gif" title="lacht" alt="Smiley: lacht" width="15" height="15"/> ',
	' <img src="img/evil.gif" title="b&ouml;se" alt="Smiley: b&ouml;se" width="15" height="15"/> ',
	' <img src="img/confused.gif" title="verdutzt" alt="Smiley: verdutzt" width="15" height="15"/> ',
	' <img src="img/cool.gif" title="cool" alt="Smiley: cool" width="15" height="15"/> ',
	' <img src="img/cool.gif" title="cool" alt="Smiley: cool" width="15" height="15"/> ',
	' <img src="img/sad.gif" title="traurig"alt="Smiley: traurig" width="15" height="15"/> ',
	' <img src="img/sad.gif" title="traurig" alt="Smiley: traurig" width="15" height="15"/> ',
	' <img src="img/broadsmile.gif" title="Smiley: lacht laut" alt="lacht laut" width="15" height="15"/> ',
	' <img src="img/broadsmile.gif" title="Smiley: lacht laut" alt="lacht laut" width="15" height="15"/> ',
	' <img src="img/zunge.gif" title="verschmitzt" alt="Smiley: verschmitzt" width="15" height="15"/> ',
	' <img src="img/zunge.gif" title="verschmitzt" alt="Smiley: verschmitzt" width="15" height="15"/> ',
	' <img src="img/redface.gif" title="verlegen" alt="Smiley: verlegen" width="15" height="15"/> ',
	' <img src="img/mrgreen.gif" title="bleckt die Z&auml;hne" alt="Smiley: bleckt die Z&auml;hne" width="15" height="15"/> ',
	' <img src="img/kopf.gif" title="steht Kopf" alt="Smiley: steht Kopf" width="15" height="15"/> ',
	' <img src="img/crying2.gif" title="heult" alt="Smiley: heult" width="15" height="15"/> ',
	' <img src="img/lol.gif" title= "lacht schallend" alt="Smiley: lacht schallend" width="15" height="15"/> ',
	' <img src="img/bussi.gif" title= "Bussi" alt="Smiley: Bussi" width="34" height="15"/> ',
	' <img src="img/bussi.gif" title= "Bussi" alt="Smiley: Bussi" width="34" height="15"/> ',
	' <img src="img/wand.gif" title= "rennt mit dem Kopf gegen die Wand" alt="Smiley: rennt mit dem Kopf gegen die Wand" width="25" height="20"/> ',
	' <img src="img/wink.gif" title= "winkt" alt="Smiley: winkt" width="25" height="15"/> ',
	' <img src="img/wink.gif" title= "winkt" alt="Smiley: winkt" width="25" height="15"/> ',
	' <img src="img/emo.gif" title= "sehr traurig" alt="Smiley: sehr traurig" width="15" height="15"/> ',
	' <img src="img/anders.gif" title= "sehr b&ouml;se" alt="Smiley: sehr b&ouml;se" width="16" height="14"/> ',
	' <img src="img/santa.gif" title= "Santa Claus" alt="Smiley: Santa Claus" width="21" height="24"/> ',
	' <img src="img/bier.gif" title= "Prost" alt="Smiley: Prost" width="60" height="20"/> ',
	' <img src="img/wein.gif" title= "sauf nicht so viel" alt="Smiley: sauf nicht so viel" width="57" height="28"/> ',
	' <img src="img/bayern.gif" title= "Bayern" alt="Smiley: Bayern" width="45" height="35"/> ',
	' <img src="img/deutsch.gif" title= "Deutschland" alt="Smiley: Deutschland" width="24" height="31"/> ',
	' <img src="img/warten.gif" title= "ich warte" alt="Smiley: ich warte" width="27" height="19"/> ',
      ' <img src="img/bass.gif" title= "der Bassist" alt="Smiley: der Bassist" width="52" height="40"/> ',
	' <img src="img/band.gif" title= "die Band" alt="Smiley: die Band" width="117" height="32"/> ',
	' <img src="img/rollbaby.gif" title= "Baby kugelt sich" alt="Smiley: Baby kugelt sich" width="33" height="26"/> ',
	' <img src="img/help.gif" title= "help" alt="Smiley: help" width="67" height="46"/> ',
	' <img src="img/snoopy.gif" title= "snoopy" alt="Smiley: snoopy" width="32" height="32"/> ',
	' <img src="img/bahnhof.gif" title= "ich versteh nur Bahnhof" alt="Smiley: ich versteh nur Bahnhof" width="60" height="48"/> ',
	' <img src="img/fcb.gif" title= "FC Bayern" alt="Smiley: FC Bayern" width="46" height="46"/> ',
	' <img src="img/tel.gif" title= "telefoniert" alt="Smiley: telefoniert" width="45" height="19"/> ',
	' <img src="img/gruebel.gif" alt="Smiley: kratzt sich am Kopf" title= "kratzt sich am Kopf" width="19" height="17"/> ',
      '<object type="application/x-shockwave-flash" data="relog.swf" style="-moz-user-focus:ignore; width:200px; height: 130px;"><param name="movie" value="relog.swf" /><param name="wmode" value="transparent" /></object>',
      '/me <strong>hat den Raum betreten.</strong>',
	' <img src="img/eyes.gif" alt="Smiley: guckt verdutzt" title= "guckt verdutzt" width="18" height="18"/> ',
	' <img src="img/gender_fem.gif" alt="Smiley: weiblich" title= "weiblich" width="9" height="15"/> ',
	' <img src="img/gender_masc.gif" alt="Smiley: männlich" title= "männlich" width="13" height="13"/> ',
	' <img src="img/geist.gif" alt="Smiley: Geist" title= "Geist" width="15" height="15"/> ',
	' v.l.',
	' <img src="img/schnitzel.gif" alt="Smiley: wirft ein Schnitzel" title= "Schnitzel" width="70" height="35"/> ',
	' <img src="img/coeuranime.gif" alt="Smiley: Herzen" title= "Herzen" width="25" height="16"/> ',
	

	' <img src="img/smile.gif" title="lacht" alt="Smiley: lacht" width="15" height="15"/> '
);
$msg_explode[1] = str_replace($arrSearch, $arrReplace, $msg_explode[1]);
// um das Pseude-clear durch wiederholte :br: zu unterbinden:
if (strpos($msg_explode[1],"Profil von") === false) {
    if (substr_count ($msg_explode[1],"<br />") > 4) $msg_explode[1] = str_replace("<br />"," - ",$msg_explode[1]);
}
?>
