<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
$hoehe_ie = $hoehe * 1.05;
if (!isset($user_hoehe)) $user_hoehe = 14;
?>

/* CSS fuer Skin 2 Boxes */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	/* color: #343; die Schriftfarbe fuer alle Texte, kann fuer jedes Element individuell ueberschrieben werden */
}

html {
	/* padding: 10px; */
	/* overflow-y: scroll;  macht einen permanenten Geisterscrollbalken auch im Fx und Op, leider nicht valid */
}

body {
        width: 95%; max-width:70em;
        margin: 10px auto;
	background-color:#fff !important; 	/* hier die Hintergrundfarbe fuer die Seite */

}



h1 {
	font-size:1.4em;
	color:#373;		/* dies ist ein Beispiel fuer eine spezielle Schriftfarbe fuer die Ueberschrift */
	line-height:125%;
	position: relative; top: .5em;
}
h1 span {color:#373}

h2 {
	font-size:.8em;
	line-height:125%;
        margin: 1em 0 .3em 0;
}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #help tr  {
	font-size:.8em;
}


#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
	position:relative; top:.15em; /* hm? */
}

#user_pro_room em:after { 
/*	content:"\00A0\221A"; */
	content:" ✔︎";
}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}
object {margin: 5px 0 0 5px;}


ul {
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}

table { /* für flirtchat */
/*	background:white; */
	max-height: 56%;
	display: block;
	overflow-y: scroll;
/*	overflow:-webkit-paged-x; */
}


fieldset {
	clear: right;
	background: #f1f1f1;		/* die Hintergrundfarbe fuer das Chatfenster */
	margin:0 0 0 0;
	padding: 10px;
	border-width:1px;
	/* min-width: 8em; */
}

fieldset fieldset {
         background: #fafafa;	/* die Hintergrundfarbe fuer die Optionsfelder */
	 padding: 2px 10px 10px 10px;
	 margin-bottom: 3px;
	 font-size:92%;
}

.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #888;
}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#wrapper {height: 85% !important;min-height: 27em;}
#talk {
	margin: 0 6px 0 0;
}

#wall {
	height: 70% !important;	
	background:#fff;		/* die Hintergrundfarbe fuer das Nachrichtenfenster */
	overflow: auto;
	margin: 0 0 15px 0;
	border: 1px solid #888;
	padding: 3px;
	line-height: 1.1em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
}
* html #wall { height: <?php echo $hoehe_ie ?>em; }

#wall p {
        /* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 3.8em;
	text-indent: -3.4em;
	margin-bottom: 2px;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#wall .whisper, #wall .at {color:red; background: yellow}

#line {
	width: 72%; font-size:1em; border:1px solid #888;
}
input#line {position:relative; top: -7px;}


#op {margin:3px 0}

#ton {
	width: 0;
	height: 0;
}


#uo ul, #uo ul li {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	} ?>
	font-size:100%;
	margin: 0; 
	padding:0 .1em;
}
#uo ul, #user_pro_room ul {
	background:#fff;
	border: 1px solid #888;
	padding: .2em 0 .25em .2em;
	line-height:1.3em;
	margin-top:5px;
}

#user_pro_room ul {font-size:.8em;}

#addsmileys {
/*	float:left; */
	margin: 3px 0 0 5px;
	font-size: .8em;
}

dfn, .dot, #sr {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}


.bg {background:#fafaee;}  /* der Hintergrund fuer den Admin */

.rooms form p span {
        display:block;
        background:#fafaee;
        font-size:115%;
        font-weight:bold;
        text-align:center;
        margin: 3px 0;
        padding:1px 25px 3px 0;
        border:1px solid #888;
}

label,
select,
input {
cursor: pointer; font-size:1em;
}

* html .button {padding:0;}
*+html .button {padding:0;}


label {margin:0 3px}


#line, #handle, #room {
       background:#fff;
       cursor:text;
}


input {
      /* background:#fafafa;  wg upload wegkommentiert */
      margin: 0 0 0 0;
      padding-bottom: 2px;    /* um die Fx Rechtschreibpruefung zu sehen */
}

.away { border: 1px solid #888;  padding: 2px 4px;}


#menu1, #menu2, #room {width:65%; display:block; clear:both;}



<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
   echo '#menu2 {width: 100%}';
   echo '* html #menu3 {width:96%}';
}
?>

<?php
if ($stil != 0) {
   echo '#menu1 {width: 100%}';
   echo '* html #menu1 {width:96%}';
}
?>

#opt2 {clear:left; padding-top: 5px}
.opt {
     margin: 0 0 2px 0;
     padding: 0;
}
* html .opt {margin: 0 0 -4px 0;}
.uolist {display:none;}
#upload {margin:8px 5px 3px 0; clear:left;}
#upload_2 p {margin: 5px 0;}
#addsmileys ul li a:visited span {color:#f1f1f1}
#addsmileys ul li a:hover span{color: #555; background: #fafaee}

#logout, .logout {
        text-align:center;
        margin:4px 1px 0 0;
        padding:3px 8px;
        border: 2px outset #eee;
        background-color: #ddd;
}
.logout a {text-decoration:none;}

.helplinks{margin:10px;}
.helplinks p a{margin-bottom: 5px;}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50%  !important;
}

a.stop {
color:#fff;
background: #888 !important;
text-decoration:none;
font-size: 80%;
padding: 0 2px;
}
#ae {margin-bottom:.5em;}

.hello {color: #888; font-size: 80%; font-weight:bold; font-style:italic;}

#mp3 {display:block;}
#r_player a, #player a {color: #222;font-size: .8em;}

#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 3px auto;}

#topic {
color:red;
margin:0 0 5px 9px;
font-weight:bold;
}

#nickname {position:relative;bottom: 5px; color:red; margin-left: 2px;}

#footerlink a{color:#888 !important}

.ip {font-size: .8em; color: #aaa;}
.ip:before {	content:" IP:\00a0";}

.yta {color:black;font-weight:bold; font-family:Arial narrow; font-size: 1.2em;}
.ytb {font-family:Arial narrow; background:red;color:white;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}

/* Avatar */
.av {position:relative; left:-7px; top: 4px; margin-right: -7px;}

#webradio {text-align:center;}
#audio-controls {margin-top: .5em;}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;}
input[type="image"]:hover, input[type="image"]:focus { background: #ddd}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
