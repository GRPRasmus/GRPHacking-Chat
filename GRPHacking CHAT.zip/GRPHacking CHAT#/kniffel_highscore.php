<?php

if ((isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'],'chat.php') !== false || strpos($_SERVER['HTTP_REFERER'],'kniffel_highscore.php') !== false || strpos($_SERVER['HTTP_REFERER'],'kniffel.php') !== false) && isset($_COOKIE["nick"])) {
//	$nickname = htmlspecialchars($_COOKIE["nick"]);
} else {
	echo "Bitte Kniffel nur aus dem Chat aufrufen!";
	exit;
}

?>

<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
	html {
		padding:1em 1em 4em 1em;
		font-family:Verdana, Arial, sans-serif;
		font-size: 90%;
		color: #fff;
/*		line-height: .6em;*/
		background: #28241c url(img/stage_bg.jpg)
	}
	p {margin:3px;}
	#footer {
		width:100%;
		position:fixed;
		bottom: 0;
		left: 0;
		height: 2em;
		text-align: center;
		background: rgb(23,23,23,0.6);
		padding-top:1em;
	}
	a {color:#fff;}
		
</style>	

<title>Kniffel Highscore</title>

</head>
<body onkeydown="kp()">

<h1 style="line-height: 1.2em;">Kniffel Highscore</h1>

<p style="font-size:80%; margin: -1em 0 2em">(max. möglich: 375)
► <a href="http://www.brefeld.homepage.t-online.de/kniffel.html" target="_blank">Strategie-Tipps</a></p>


<?php 

error_reporting(E_ALL);

$raw = file("kniffel_hs.txt");

for ($m = 0; $m < count($raw); $m++) {
	if (strpos($raw[$m],"NaN") === false ) {
		$file[] = $raw[$m];	
	}		  
}
rsort($file);


for ($i = 0; $i < count($file); $i++) {
	$nicknames[] = trim(substr($file[$i],4));
} 

$unique = array_count_values($nicknames);
$zahl = array_values($unique);

$nicknames = array_keys(array_flip($nicknames));


$names = array();
for ($i = 0; $i < count($file); $i++) {
	
	$line = trim(substr($file[$i],4));
	
	if (in_array($line,$names) !== true) {
		$nicks[] = $file[$i];		
	}
		
	$names[] = $line;

}	

$min = 150;
$weitere = 0;
for ($i = 0; $i < count($nicks); $i++) {
	if (intval(substr($nicks[$i],0,3)) >= $min) {
		echo "<p>$nicks[$i] ($zahl[$i])</p>";
		$weitere = count($nicks) - $i - 1;
	}
}
if ($weitere == 1) {
	echo "<br><p>… und ein Spieler mit weniger als&nbsp;".$min."&nbsp;Punkten.</p>";
}
if ($weitere > 1) {
	echo "<br><p>… und ".$weitere." Spieler mit weniger als&nbsp;".$min."&nbsp;Punkten.</p>";
}




?>

<p id="footer">
<a style="font-size: .9em;" href="javascript:self.close()">Fenster&nbsp;schlie&szlig;en</a>
 | 
<a style="font-size: .9em;" href="kniffel.php">Neues&nbsp;Spiel</a>

</p>

<script>
	function kp(e){if (!e) e=window.event;if (e.keyCode==27 && !e.shiftKey){self.close();}}window.onkeypress=kp;
</script>	


</body>
</html>
