

<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>Kick</title>

</head>
<body>



<?php
	

$nickban = $_GET["nick"];
$bantime = time() + (3600 * 24) ;
$banip = $_SERVER['REMOTE_ADDR'];

$banstrg = $nickban."****".$bantime."++++".$banip."\n";

$banned = "user/ban.txt";
$fb = fopen($banned, "a+");
chmod ($banned, 0646);
fwrite($fb, $banstrg);
fclose($fb);

header("Location: logout.php?ref=kicked");

?>
	
</body>
</html>