<?php 

@include("chat_config.php");

//if ($admintrue || modtrue) {
if (strpos($msg_explode[1],"/ban ") !== false
	// || strpos($msg_explode[1],"/kick ") !== false
	|| strpos($msg_explode[1],"/maulkorb ") !== false) {

	if (strpos($msg_explode[1],"/ban ") !== false) $mess = "you're banished";
	// if (strpos($msg_explode[1],"/kick ") !== false) $mess = "you've been kicked";
	if (strpos($msg_explode[1],"/maulkorb ") !== false) $mess = "you're muzzled";


	$banmsg = trim($msg_explode[1]);
	$banmsg = preg_replace("/\s+/"," ", $banmsg); // mehrfache Leerzeichen weg

	$banned_nick = explode(" ",$banmsg);
	$banned_nick = str_replace("@","",$banned_nick);

	$nickban = $banned_nick[1];
	
	// Admins können nicht gebannt werden:		
	foreach($admins as $key => $val) {
		if (utf8_decode($nickban) == trim(utf8_decode($val))) {exit;}
	}
	// Mods können nicht gebannt werden:		
	foreach($mods as $key => $val2) {
		if (utf8_decode($nickban) == trim(utf8_decode($val2))) {exit;}
	}
	

	// jetzt noch die ban Zeit:
	$banparts = $banned_nick[2];
	

	if ($banparts < .1) $banparts = $bantime; // Vorgabezeit für ban, wenn keine Zeit angegeben
	
	if (!is_numeric($banparts)) { 		
		$banparts = preg_replace('/[^0-9]/', '', $banparts);  
	}

	if ($banparts > 43200) $banparts = 43200; // banzeit max. 30 Tage

	$bantime = time() + 60*$banparts;


	// und jetzt die IP zum nick suchen:
	$roomid = str_replace("rooms/","_",$room);
	$ipfile = 'user/ip'.$roomid.'.txt';

	$lines = file($ipfile);
	$ipparts = "";
	foreach ($lines as $line_num => $line) {
		if (strpos($line,$nickban) !== false) {
			$ipparts = explode("****", $line);
			$banip = $ipparts[0];
		}
	}


	$banstrg = $nickban."****".$bantime."++++".$banip."\n";

	if (strpos($msg_explode[1],"/maulkorb") !== false) {
		$banned = "user/maulkorb.txt";
	} else {
		$banned = "user/ban.txt";
	}
	$fb = fopen($banned, "a+");
	chmod ($banned, 0646);
	fwrite($fb, $banstrg);
	fclose($fb);

	$msg_explode[1] = ' <span style="display:none">/pn @'.$nickban.' </span> '.$mess;


} elseif (strpos($msg_explode[1],"/kick ") !== false) {

	$banmsg = trim($msg_explode[1]);
	$banmsg = preg_replace("/\s+/"," ", $banmsg); // mehrfache Leerzeichen weg

	$banned_nick = explode(" ",$banmsg);
	$banned_nick = str_replace("@","",$banned_nick);

	$nickban = $banned_nick[1];
	
	// Admins können nicht gebannt werden:		
	foreach($admins as $key => $val) {
		if (utf8_decode($nickban) == trim(utf8_decode($val))) {exit;}
	}
	// Mods können nicht gebannt werden:		
	foreach($mods as $key => $val2) {
		if (utf8_decode($nickban) == trim(utf8_decode($val2))) {exit;}
	}
	
	
	// kein /kick fuer gebannte User
	if (file_exists("user/ban.txt")) {
		$banned = file("user/ban.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);
			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $_SERVER['REMOTE_ADDR'];

	      		if ($part1[0] == $nickban || (trim($rip) == trim($part2[1]) ))  {
					exit();
				}
			}
		}
	}
	
	// kein /kick fuer muzzled User
	if (file_exists("user/maulkorb.txt")) {
		$banned = file("user/maulkorb.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);
			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $_SERVER['REMOTE_ADDR'];

	      		if ($part1[0] == $nickban || (trim($rip) == trim($part2[1]) ) )  {
					exit();
				}
			}
		}
	}

	// und jetzt die IP zum nick suchen (nur Anwesende können gekickt werden):
	$roomid = str_replace("rooms/","_",$room);
	$ipfile = 'user/ip'.$roomid.'.txt';

	$lines = file($ipfile);
	$ipparts = "";
	foreach ($lines as $line_num => $line) {
		if (strpos($line,$nickban) !== false) {
			$ipparts = explode("****", $line);
			$banip = $ipparts[0];
		}
	}
	if ($banip =="") {
		$mess = "Fehler! Nur anwesende User können gekickt werden. <br>Versuche es mit /ban, um einen abwesenden User zu bannen. ";
		$msg_explode[1] = ' <span style="display:none">/pn </span> '.$mess;
	} else {
		$mess = "you've been kicked";
		$msg_explode[1] = ' <span style="display:none">/pn @'.$nickban.' </span> '.$mess;
	}

}





//}

?>
