<?php
header('Content-type: text/html; charset=utf-8');
// error_reporting(E_ALL);
ob_start();

if (isset($_GET['ref'])) {
if ($_GET['ref'] == "kicked") {$kicked = "kicked";}
}

if (!isset($_SESSION)){session_start();}
session_destroy(); // destroy session
setcookie("PHPSESSID","",time()-3600,"/"); // delete session cookie  
//unset($_SESSION['login']);

// alle $woarraival cookies löschen:
// löscht cookies nur von noch existierenden Räumen

$dir3 = 'rooms/';
if ($handle = opendir($dir3)) {
   while (false !== ($file = readdir($handle))) {
         $woarrival = $file.'arrival';
         setcookie($woarrival,"");
   }
}


include("chat_config.php");

// Ghost-Status abfragen:
if (isset($_COOKIE["watch"])) {
	$watch = "on";
} else {
	$watch = "";	
}


// Sprache abfragen und lang-file includen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
      $lang = $languages[0];
}
$lang_file = 'lang'.strtoupper($lang).'_inc.php';
include ($lang_file);


if (isset($stil) && $stil <> 0) {
        $s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
        $s = $default_skin;
}

// cookie nick holen fuer ban und maulkorb:
$nickname ="";
if (isset($_COOKIE["nick"])) {
	$nickname = $_COOKIE["nick"];
}

// kein Logout fuer gebannte User
if (file_exists("user/ban.txt")) {
	$banned = file("user/ban.txt");
	foreach ($banned as $c) {
		$part1 = explode("****",$c);
		$part2 = explode("++++",$part1[1]);
		if (strlen($c) > 1 && $part2[0] > time()) {
			$rip = $_SERVER['REMOTE_ADDR'];

      		if ($part1[0] == $nickname || (trim($rip) == trim($part2[1]) ))  {
				echo "<h1>You're banished";
				exit();
			}
		}
	}
}

// kein Logout fuer muzzled User
// if (file_exists("user/maulkorb.txt")) {
// 	$banned = file("user/maulkorb.txt");
// 	foreach ($banned as $c) {
// 		$part1 = explode("****",$c);
// 		$part2 = explode("++++",$part1[1]);
// 		if (strlen($c) > 1 && $part2[0] > time()) {
// 			$rip = $_SERVER['REMOTE_ADDR'];
//
//       		if ($part1[0] == $nickname || (trim($rip) == trim($part2[1]) ) )  {
// 				echo "<h1>You're muzzled";
// 				exit();
// 			}
// 		}
// 	}
// }


// íp_file saeubern beim Logout
// $newline = "";
// $show_dir = 'user/';
// $dir=opendir($show_dir);
// while (false !== ($file = readdir($dir))) {
// 	if(strpos($file,"ip_") !== false) {
// 		$userfile = $show_dir.$file;
//        	$user = file($userfile);
//
// 		foreach ($user as $u) {
// 			$part2 = explode("++++",$u);
//       		if (trim($part2[1]) != trim($nickname)) {
// 				$newline .= $u;
// 			}
// 		}
// 		$handler = fopen($userfile, "w");
// 		fwrite($handler , $newline);
// 		fclose($handler);
// 	}
// }

// Hinaus-Meldung schreiben:
// if ((!isset($_COOKIE["nick"]) || !in_array($_COOKIE["nick"], $admins)) && $show_hello == "yes" && !isset($kicked)) {
// if ((!isset($_COOKIE["nick"]) || $watch !== "on") && $show_hello == "yes" && !isset($kicked)) {
if ($watch !== "on" && $show_hello == "yes" && !isset($kicked)) {
	
	if ((isset($_SESSION["chatuser"]) && file_exists('profile/'.$_SESSION["chatuser"].'.jpg'))) {
		$prof_link ='<span class="av_link"><a href="popprof.php?profil='.$_SESSION["chatuser"].'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$_SESSION["chatuser"].' anschauen (Popup)"  > <img class="av" src="profile/'.$_SESSION["chatuser"].'.jpg" alt="" height="32"></a></span>';
	} else {
		$prof_link = "";
	}
	
	if (isset($_COOKIE["nick"])) {
		$eigener = $_COOKIE["nick"];
	} else {
		$eigener= "User";
	}

	$hinaus ='<p><span class="dt">'.date("d\.m\.").'</span> <span class="uz">'.date("H:i:s").'</span><span class="tr"> | </span> '.$prof_link.' <span class="hello" oncontextmenu="ads(\'/erase '.date("H:i:s").'\'); return false;" onclick="ads(\'\u0040'.$eigener.'\'); return false; "  title ="'.date("d\.m\. H:i:s").'" style="color:#888; cursor: pointer"> ['.$eigener.'</span>  <span class="hello">'._LOGOUT3.'] </span> </p>'.PHP_EOL;	

	if (isset($_SERVER['HTTP_REFERER'])) {
		parse_str(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_QUERY), $queries);
	}
	if (isset($queries['room'])) {
		$file5 = 'rooms/'.$queries['room'];	
	} else {
		$file5 = 'rooms/'.$standard;
	}
	
	
	if ($eigener != "User" ) { // keine Meldung, falls keine Cookies
				
			if (@$queries['room'] != 'Info' && @$queries['room'] != 'Moderiert' && @$queries['room'] != 'Intern' && @$queries['room'] != 'Flirtchat' && strpos(@$queries['room'],'_pr') === false
//				&& strpos(file_get_contents('rooms/'.$standard),$eigener.'</span>  <span class="hello">hat sich ausgeloggt') === false
			) {
				$open5 = fopen($file5, "a");
				fwrite($open5,$hinaus);
				fclose($open5);
			}
	}
}


// http://aktuell.de.selfhtml.org/artikel/css/mobile-endgeraete/
if(file_exists("check_mobile.php")) {


	require('check_mobile.php');
	if(check_mobile()) {
		// echo "mob"; exit;

		$s = 7;
		echo '<style type="text/css">';
		echo 'img {display:none;}';
		echo '</style>';
		
	} elseif ($s == 7) {
		echo '<style type="text/css">';
		echo 'body {width: 23em;}';
		echo '</style>';
	}
}
?>


<?php
//Redirect zum login:
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra1 = 'login.php';

header("Location: //$host$uri/$extra1");
exit();
?>

