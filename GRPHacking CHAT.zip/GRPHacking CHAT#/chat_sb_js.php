<?php
session_start();
//ob_start('ob_gzhandler'); // das macht Probs mit Session im IE
header('Content-Type: text/javascript');

// gegen�ber der chat_js.php geaendert:
// function load() u_online_room(); wegkommentierT
// time_init = 5000;
//  var  cookieWert;



@include("chat_config.php");
$registered = 0;
if(isset($_SESSION['login']) && $_SESSION['login']==1 || isset($_COOKIE["nick"])) $registered = 1;



if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}

switch ($lang) {
        default: include("langDE_inc.php");
        break;
        case "de": include("langDE_inc.php");
        break;
        case "en": include("langEN_inc.php");
        break;
        case "es": include("langES_inc.php");
        break;
}

?>


var check_n = 0;
var old_data = "--";
var old_result = 1;

var cookieWert;



// die Javascript Funktionen zur Steuerung des emff-Players:
function playmp3(typ) {
        if (flashinstalled == 2) {
        	document.getElementById("mp3").innerHTML = '<object data="emff_standard.swf?src='+typ+'&amp;autostart=yes" type="application/x-shockwave-flash" style="-moz-user-focus:ignore; width:1px; height:1px;"><param name="movie" value="emff_standard.swf?src='+typ+'&amp;autostart=yes" /><\/object>';
        } else {
               // neues Fenster, wenn kein Flash installiert:
               playerwindow = window.open(typ, "Player");
               playerwindow.focus();
        }
}



// bei Inaktivit�t wird der Chat immer langsamer, und disconnected nach einiger Zeit:
// die Variablen f�r den disconnect:


//time_init = <? if (isset($refresh)) {echo $refresh;} else {echo "2000";} ?>;
//if (time_init < 500) time_init = 500;

time_init = 3000;

disconnect = 10000; // disconnect bei Erreichen dieses refresh Wert
slowdown = 3; // 10: disconnect nach ca. 15 Minuten, 2: nach 75 min. (0 = nie)
meldung = '<? echo _TIMEOUT; ?>' ;

function holeCookie(Keksname) {
	alleCookies=document.cookie;	
	cookieArr=alleCookies.split(";");
      var cookieWert;
	for(var i=0;i<cookieArr.length;i++) {
		if(cookieArr[i].split("=")[0].replace(/\s+/,"") == Keksname) {
			cookieWert=cookieArr[i].split("=");
			cookieWert=decodeURIComponent(cookieWert[1].replace(/\+/g," "));
			return true;
		}
	}
	return false;
}


// die Anzeige der online-Zeit bei reloads oder Raumwechsel nicht zur�cksetzen:

var Jetzt = new Date();
holeCookie("Ankunft");

if (cookieWert) {
	login = cookieWert;
} else {
	login = Jetzt.getTime();
}

// erst nach 10 Min. Inaktivit�t startet ein reload oder Raumwechsel die online Zeit neu:
var ablauf = new Date();
var Minuten = ablauf.getTime() + (10 * 60 * 1000); 
ablauf.setTime(Minuten);
document.cookie="Ankunft="+login+"; expires=" + ablauf.toGMTString();

function ZeitAnzeigen () {
         if (document.getElementById('Anzeige')) {
        	 var absSekunden = Math.round(ZeitBerechnen());
        	 var relSekunden = absSekunden % 60;
        	 var absMinuten = Math.abs(Math.round((absSekunden - 30) / 60));
        	 var relMinuten = absMinuten % 60;
        	 var absStunden = Math.abs(Math.round((absMinuten - 30) / 60));
        	 var anzSekunden = "" + ((relSekunden > 9) ? relSekunden : "0" + relSekunden);
        	 var anzMinuten = "" + ((relMinuten > 9) ? relMinuten : "0" + relMinuten);
        	 var anzStunden = "" + ((absStunden > 9) ? absStunden : "0" + absStunden);
                	 if (absStunden >= 1) {
                        	 document.getElementById('Anzeige').Zeit.value = anzStunden + ":" + anzMinuten + ":" + anzSekunden;
                         } else {
                                       	 document.getElementById('Anzeige').Zeit.value = anzMinuten + ":" + anzSekunden;
                         }
        	 setTimeout("ZeitAnzeigen()", 1000);
         }
}

function ZeitBerechnen () {
	 var Immernoch = new Date();
	 return ((Immernoch.getTime() - login) / 1000);
}
	

function jump(form) { 
	order = form.menu1.selectedIndex; 
	if (form.menu1.options[order].value != 0) { 
		addsmile(form.menu1.options[order].value);
	}  
} 


var ablauf2 = new Date();
var Minuten2 = ablauf2.getTime() + (30 * 24 * 60 * 60 * 1000);
ablauf2.setTime(Minuten2);
function jump2(form) {
	order = form.menu2.selectedIndex;
	if (form.menu2.options[order].value != 0) {
               var style = form.menu2.options[order].value;
               document.cookie="Style="+style+"; expires=" + ablauf2.toGMTString();
               window.location.reload();
	}
}

function setlang(lg) {
               document.cookie="lang="+lg+"; expires=" + ablauf2.toGMTString();
}

function playsound(typ) { // die standardkonforme L�sung f�r alle Browser
	document.getElementById("ton").innerHTML = '<object data="'+typ+'" type="application/x-shockwave-flash" width="0" height="0"><param name="movie" value="'+typ+'" /><\/object>';
}

time1 = time_init;


function refresh_cb(new_data) {
	if (typeof old_data == "undefined" || old_data == "--") {

                playsound('<?php echo $sound1 ?>'); // Sound bei reload
	} else {
		if (typeof handle != "string") 	playsound('<?php echo $sound4 ?>'); // Sound bei Eingang, nicht bei eigenen Meldungen
	}
	handle = 1;

	document.getElementById("wall").innerHTML = new_data;

	setTimeout('document.getElementById("wall").scrollTop = 9999',500);
	old_data = new_data;
      time1 = time_init; // bei Eingang einer neuen Meldung wirds wieder schnell
	setTimeout("changed_data()", time1);
}

// Filesize abfragen vor dem AJAX refresh
var old_size;
function set_file_changed(new_size) {

    // per cookie den refresh vermeiden:
    holeCookie("stop");
    if (cookieWert != "on") {
         if ( typeof old_size == "undefined" || new_size != old_size) {
                 old_size = new_size;
                 x_refresh(refresh_cb);
         } else { // hierher die Waermestube!
                if (typeof time1 != "undefined") {
                        time1 = time1 * (1 + slowdown*0.001); // wenn nix los ist, wirds immer langsamer, bis zum timeout:
                        if (time1 > disconnect) {
                      		 alert(meldung);
                                 time1 = disconnect*0.5;     // es bleibt rel. langsam, umd der Alert kommt schneller
                                 u_online();                // k�nnte man so nach dem Alert die user wieder anzeigen?
        	                 u_online_room();
                        }
                        setTimeout("x_file_changed(set_file_changed)",time1);
                }
         }
     } else {
         setTimeout("changed_data()",time1);
     }
}

function changed_data() {
	x_file_changed(set_file_changed);
}



function add_cb() {
	// we don't care..
}



var handle; // Var global wg. Klick on send
function add() {
      playsound('<?php echo $sound3 ?>'); // Ton beim Abschicken eigener Meldungen: hierher, damit der IE nicht mehr flacker

	var line;
	handle = document.getElementById("handle").value;


      // alles mit login fastreg abgleichen:
	handle = handle.replace(/[ \t]+$/,''); // trim nick, damit Vgl. mit cookie klappt
	handle = handle.replace(/^ /g,'');  // Leerzeichen am Anfang l�schen
	handle = handle.replace(/\s/g,'_'); // Leerzeichen im Nick in _ umwandeln


        // unerlaubte Zeichen per alert zur�ckweisen (mit login fastreg abgleichen):
        if (handle.indexOf("?") != -1
            || handle.indexOf(":") != -1
            || handle.indexOf(";") != -1
            || handle.indexOf("\"") != -1
            || handle.indexOf("'") != -1
            || handle.indexOf("<") != -1
            || handle.indexOf(">") != -1
            || handle.indexOf("|") != -1
            || handle.indexOf("&") != -1
            || handle.indexOf("*") != -1
            || handle.indexOf("+") != -1
        ) {
           alert ("<?php echo _CHARNOTALLOWED; ?> (0)");
           document.getElementById("handle").focus();
           return;
        }

        <?php

        // Nicks, die den Admin Namen (case insensitiv) enthalten, zur�ckweisen:
        // nur noch identisch case insensitiv           if (handle_a.indexOf("'.strtolower($admins[$i][1]).'") != -1 ) {
        for ($i = 0; $i < count($admins); $i++) {
               echo'
       	       handle_a = handle.toLowerCase(handle);
       	       if (handle_a == "'.strtolower($admins[$i][1]).'") {
                        alert("'._NICKNOTALLOWED.' (1)");
                        document.getElementById("handle").focus();
                        return;
                   }
                   ';
        }


        // weitere verbotene Nicks:
        for ($n = 0; $n < count($nicknotallowed); $n++) {
               echo'
       	       handle_s = handle.toLowerCase(handle);
                   if (handle_s.indexOf("'.strtolower($nicknotallowed[$n]).'") != -1 ) {
                        alert("'._NICKNOTALLOWED.' (2)");
                        document.getElementById("handle").focus();
                        return;
                   }
                   ';
         }

         // und nun registrierte Namen schuetzen:
         // nur noch identisch case insensitiv    if (handle_s.indexOf("'.strtolower(trim($reguser[0])).'") != -1 ) {
         if (file_exists("user/user.txt")) {
                 $angemeldet = "user/user.txt";
                 $lines = file($angemeldet);

                 foreach ($lines as $line_num => $line) {
                       $reguser = explode("****",$line);
                       if($registered == 0) {
                               echo'
                               handle_s = handle.toLowerCase(handle);
                                    if (handle_s == "'.strtolower(trim($reguser[0])).'") {
                                           alert("'._NICKNOTALLOWED.' (3)");
                                           document.getElementById("handle").focus();
                                           return;
                                    }
                               ';
                       }
                 }
         }


         ?>

      // bereits anwesende Nicks nicht zulassen:
      // hilft nicht bei Wiederkommern, wenn der doppelte nick bereits per cookie gespeichert ist

      xanwesend = document.getElementById("uo").innerHTML;
      anwesend = xanwesend.toLowerCase(xanwesend);

      handle_s = handle.toLowerCase(handle)+"</a>"; // </a> damit der Nickeigner schreiben kann
      if ( anwesend.indexOf(handle_s) != -1 ) {
            alert("<?php echo _DBLUSER; ?>");
            document.getElementById("handle").focus();
            return;
      }


      // keine leere Nachricht zulassen:
	line = document.getElementById("line").value;
	if (line == "" || line == "(<? echo _MESSAGE; ?>)" ) {
		document.getElementById("line").focus();
		return;
	}

      // mehr als 4 mal das gleiche Zeichen oder die gleiche Zeichenfolge (z.B. smileys) zur�ckweisen und umwandeln
      if (line.search(/(.+)\1{4,}/) != -1) {
         alert("<?php echo _CHARREP; ?>");
         document.getElementById("line").focus();
         return;
         // line = line.replace(/(.)\1{4,}/g, "*");
      }


      // bestimmte Befehle zurueckweisen, wenn nicht Admin:
     	line = document.getElementById("line").value;
      if (handle.indexOf("<?php echo $admin_pw; ?>") == -1) {
            if (line.indexOf("/ban") != -1
                  || line.indexOf("/kick") != -1
                  || line.indexOf("/maulkorb") != -1
                  || line.indexOf("/maulkick") != -1
                  || line.indexOf("/ghost") != -1
                  || line.indexOf("/peep") != -1
                  || line.indexOf("/approve") != -1
                  || line.indexOf("/add") != -1
                  || line.indexOf("/offline") != -1
                  || line.indexOf("/del") != -1
                  || line.indexOf("/archiv") != -1
            ) {
                  alert("<?php echo _JSADMINONLY; ?>");
      		document.getElementById("line").focus();
      		return;
      	}

            if (line.indexOf("/erase") != -1 ) {
                  alert("<?php echo _JSERASE; ?>");
      		document.getElementById("line").focus();
      		return;
      	}

      	// nicht erlaubte IRC Befehle zurueckweisen:
            if (line.match(/^\/\S+/)
                  && line.indexOf("/me") == -1
                  && line.indexOf("/pn") == -1
                  && line.indexOf("/clear") == -1
                  && line.indexOf("/color") == -1
                  && line.indexOf("/ignore") == -1
                  && line.indexOf("/show") == -1
                  && line.indexOf("/stop") == -1
                  && line.indexOf("/go") == -1
                  && line.indexOf("/help") == -1
                  && line.indexOf("/hilfe") == -1
                  && line.indexOf("/list") == -1
                  && line.indexOf("/nick") == -1
                  && line.indexOf("/name") == -1
                  && line.indexOf("/who") == -1
                  && line.indexOf("/msg") == -1
                  ) {
                  alert("<?php echo _JSIRC; ?>");
      		document.getElementById("line").focus();
      		return;
      	}
      }





      cookie_allowed = holeCookie("test");

	cookieWert = "1";
	holeCookie("nick");

        if (cookieWert =="1" && typeof user_name == "undefined") { // wenn kein cookie gesetzt/erlaubt:
       		x_add_line("<? echo _NEWUSER; ?> \"" + handle +"\": " + line, add_cb);
       		// http://www.liesong.de/js/scripts/alertumlaute.html
//                if (typeof cookie_allowed == "undefined") {
//                    alert('<? echo _NOCOOKIEALERT; ?>');
//                }
                user_name = handle;
        }

       	else if (handle == cookieWert || user_name == handle) {      // cookie oder variable gesetzt
      		x_add_line(handle + ": " + line, add_cb);
       	}

        else if (cookieWert == 1 && user_name != handle) {           // nick ge�ndert ohne cookies
       		x_add_line( user_name + " <? echo _RENAME; ?> \"" + handle +"\": " + line, add_cb);
                user_name = handle;
       	}

        else if (handle != cookieWert && cookieWert != "1" || user_name != handle) { // nick ge�ndert mit cookies
       		x_add_line(cookieWert + " <? echo _RENAME; ?> \"" + handle +"\": " + line, add_cb);
       	}



	// Anwesenheitscookie erneuern beim Schreiben einer msg
	varJetzt = new Date();
	//var login = Jetzt.getTime(); // nein, die alte Startzeit �bernehmen
	var ablauf = new Date();
	var Minuten = ablauf.getTime() + (3 * 60 * 1000);
	ablauf.setTime(Minuten);
	document.cookie="Ankunft="+login+"; expires=" + ablauf.toGMTString();

	document.getElementById("line").value = "";
	document.getElementById("line").focus();
}


function set_user(result) {
        if (document.getElementById('uo')) document.getElementById('uo').innerHTML = result;

        if (typeof old_result != "undefined") {
        	if (result.length > old_result.length) {
        		playsound('<?php echo $sound2 ?>'); // sound wenn user in den Raum kommt, und bei Betreten eines Raumes, in dem user sind.
        	}
	}
       	old_result = result;
}

function u_online() {
	x_user_online(set_user);
        if (time1 < disconnect)	setTimeout("u_online()", 4444);
}


function set_user_room(result1) {
        if (document.getElementById('user_pro_room')) document.getElementById('user_pro_room').innerHTML = result1;
}

function u_online_room() {
	x_user_room(set_user_room);
        if (time1 < disconnect)	setTimeout("u_online_room()", 3333); // darf nicht dynamisch genacht werden, da in der inc feste Lebensdauern
}


function addsmile(smiley) {
      if (document.getElementById('line').value.indexOf('<? echo _MESSAGE; ?>') !== -1) {
		document.getElementById('line').value = "";
	}
	document.getElementById('line').value = document.getElementById('line').value + ' ' + smiley + ' ';
	document.getElementById('line').focus();
}


function load() {
      <?php
//           global $anz_rooms, $shoutbox;
//           if ($show_rooms_form == "yes" && $shoutbox !== true) echo 'u_online_room();';  // wer no einstellt, hat wohl nur einen room
      ?>
	changed_data();
	
	u_online();
	//if (focus != 0) document.getElementById('line').focus();
//	ZeitAnzeigen();
}



window.onload=load;
