
Der Chat von http://webdesign.weisshart.de


                            |         |          _)
             \ \  \   / _ \ __ \   _` |  _ \  __| |  _` | __ \
              \ \  \ /  __/ |   | (   |  __/\__ \ | (   | |   |
               \_/\_/ \___|_.__/ \__,_|\___|____/_|\__, |_|  _|  _)
                                                   |___/
                      _)           |                |             |
        \ \  \   / _ \ |  __|  __| __ \   _` |  __| __|        _` |  _ \
         \ \  \ /  __/ |\__ \\__ \ | | | (   | |    |         (   |  __/
          \_/\_/ \___|_|____/____/_| |_|\__,_|_|   \__|  _)  \__,_|\___|


                                                  http://webdesign.weisshart.de
###############################################################################

Mit jeglicher Verwendung des Scripts anerkennen Sie folgende Bedingungen:

webdesign weisshart ist nicht f�r de Einsatz des Scripts verantwortlich. 
Alle f�r den Betrieb des Scripts zutreffenden rechtlichen Obliegenheiten
sind allein in der Verantwortung des Betreibers.

Sie k�nnen dieses Script auf nicht kommerziellen Seiten kostenlos benutzen,
solange Sie den Link auf webdesign.weisshart.de
inclusive umgebendem Text und dem Kaufen-Button unver�ndert, intakt und sichtbar lassen.
Diese Einschr�nkung gilt f�r jegliche Verwendung, also z.B. auch in Intranets.

F�r den Einsatz auf einer kommerziellen Seite ist eine gewerbliche Lizenz erforderlich.
Dies gilt auch und insbesondere f�r Agenturen und Webdesigner, die den Chat auf Kundenseiten einsetzen.

Kommerziell ist jede Seite mit Gewinnerzielungsabsicht.
Entscheidend ist die Absicht, nicht der realisierte Gewinn.
Werbung auf der Seite deutet in aller Regel auf Gewinnerzielungsabsicht.

Wenn Sie das Script auf einer kommerziellen Seite einsetzen wollen,
und/oder den Link auf webdesign.weisshart.de entfernen wollen,
k�nnen Sie hier eine Lizenz erwerben:
http://webdesign.weisshart.de/chat-lizenz.php


F�r evl. auftretende Sch�den, die durch die Verwendung dieses Scripts entstehen,
kann webdesign weisshart nicht haftbar gemacht werden.
Die Benutzung erfolgt auf eigene Gefahr des Anwenders.
Kl�ren Sie insbesondere vorab, ob Ihr Webhoster den Betrieb des Scripts zul�sst.


Der Original-Quelltext darf nicht weiter gegeben werden, und nicht zum Download angeboten werden.
Ein Download ist nur von der Seite des Anbieters erlaubt: http://webdesign.weisshart.de/chat.php


Der Verkauf dieses Scripts, auch in modifizierter Form, ist ohne vorherige
Absprache ausdr�cklich untersagt!

Es ist ausdr�cklich verboten, das Script zum Gelderwerb einzusetzen,
z. B. durch den Betrieb eines kostenpflichtigen Chats.
Bitte fragen Sie, bevor Sie versuchen, mit dem Script Geld zu verdienen.



#############################################

Voraussetzungen serverseitig:
Der Server muss PHP ab Version 5 unterst�tzen.
�ltere Versionen von PHP (mindestens 4.3.0) erm�glichen keinen Dateiupload und keine Profile.
F�r den Uplaod von Dateien muss die GD-Library in PHP geladen sein.
Eine Datenbank ist nicht erforderlich.
Wichtig! Der Server muss .htaccess Dateien verarbeiten, um den Zugriff auf verschiedene Bereiche zu beschr�nken
   Hinweis f�r Windows Server:
   Der Windows IIS Server erlaubt, anders als der Apachae, keine .htaccess Dateien.
   Bei Verwendung eines Windows IIS Servers alle .htaccess Dateien in allen Ordnern l�schen.
   Ein gew�nschter Zugriffsschutz muss dann anderweitig sichergestellt werden.


Voraussetzungen clientseitig:
Javascript muss beim Benutzer verf�gbar und aktiviert sein.
Cookies werden f�r verschiedene Funktionen gesetzt, und m�ssen beim Benutzer zugelassen sein.
Der Referrer darf im Browser des Benutzers nicht geblockt sein.


Voraussetzungen adminseitig:
ACHTUNG!
Wenn du eine der obigen Voraussetzungen nicht verstanden hast,
oder nicht weisst, was ein FTP Programm und CHMOD ist,
dann solltest du das Script besser nicht installieren ;-)


#############################################
Installation:

1. zip entpacken (NICHT direkt auf dem Server entpacken, sondern lokal!)
   Darauf achten, dass die Ordnerstruktur (Unterverzeichnisse) beim Entpacken beibehalten wird.
   
2. alles in ein eigenes Verzeichnis namens /chat auf den Server uploaden.

3. Aufruf mit http://www.Pfad_zum_Verzeichnis/login.php
   z.B. http://www.meineSeite.de/chat/login.php
   Die erste Anmeldung kann auch als Gast erfolgen.

   Falls du im Chat nichts schreiben kannst (und nur dann!):
   CHMOD f�r die Ordner "rooms", "user" "admin", "upload", "tn_upload", "smileys", "sounds" und "logs": 777
   CHMOD f�r die Datei Standard im Ordner "rooms" 666
   CHMOD f�r die Datei clear.txt (im Stammordner) 666
   CHMOD f�r die Datei user.txt im Ordner "user" 666
   CHMOD f�r die Datei flood.txt im Ordner "user" 666

4. Wenn geschrieben werden kann (und ERST DANN):
   Anpassung: die Datei chat_config.php mit einem Texteditor bearbeiten.
   dort erst einmal die Namen f�r die Admins festlegen: $admins = array( ...
   ACHTUNG! Der Editor von Windows macht die chat_config.php kaputt. Nach dem Login erscheint dann nur eine wei�e Seite,
   oder allerhand Doppelpunkte auf der Seite.
   In diesem Fall bitte einen anderen Editor verwenden. Ich empfehle Notepad++ http://notepad-plus-plus.org/
   
   Hinweis:
   Alle anderen Dateien nicht �ndern! Mit unbedachten �nderungen kann der Chat schnell kaputt ge�ndert werden!

5. WICHTIG! Die Admin Namen sch�tzen:
   Rufe die Datei login.php auf. (im Browser!) Das geht auch per X...Logout im Chat, dann "zum Login ..." und dort "zur Registrierung"
   Jetzt jeden Admin Namen mit einem eigenen Passwort registrieren (auch nicht benutzte Admin Namen!).

   Hinweise:
   - Erkennbar ist der Admin-Status in der Eingabezeile an einem angeh�ngten [A] nach dem Nick
   - Die Hilfe f�r die Admin-Befehle wird nur angezeigt, wenn du Admin bist!

6. WICHTIG! Sch�tze die Ordner /admin und /logs per .htaccess!
   F�r den Ordner /admin ist bereits ein Passwortschutz eingerichtet. 
   ACHTUNG! Dort unbedingt die Zugangsdaten �ndern! Zumindest das Passwort in der Datei /admin/.htpasswd 
   Siehe z. B. http://www.htpasswdgenerator.de/
   
   Hinweis: Der Passwortschutz ist f�r Apache-Server eingerichtet. Wenn der Chat auf einem nginx-Server l�uft, muss der Passwortschutz entsprechend angepasst werden!

7. Registrierungen verwalten:
   Zum L�schen von Registrierungen und weitere Verwaltungsaufgaben steht die Datei pfad_zum_chat/admin/admin.php zur Verf�gung. (im Browser aufrufen)
   Um diese Datei aufzurufen, brauchst du das im Schritt 6 von dir ge�nderte Passwort.
   
8. In der Datei pfad_zum_chat/admin/admin.php kannst du unter anderem auch Mods festlegen.

9. Weitere Konfigurationsm�glichkeiten sind in der Datei chat_config.php beschrieben.
   Anpassungen am besten immer nur einen Schritt, und dann das Ergebnis testen.
   Bitte beachte den Hinweis am Ende der chat_config.php

10. Anpassung von Farben usw.: chatcss1.php bis chatcss13.php - aber nur, wenn Du etwas CSS kannst!
   - chatcss1:  Shoutbox
   - chatcss2:  Skin Boxes
   - chatcss3:  Skin Web2
   - chatcss4:  Skin Black
   - chatcss5:  Skin Stage
   - chatcss6:  Skin Flowers
   - chatcss7:  Skin Mobil - wird auf Smartphones automtisch verwendet
   - chatcss8:  Skin Firebox
   - chatcss10: Skin Sky
   - chatcss11: Skin Invers - optimiert auf Lesbarkeit
   - chatcss12: Skin BF-Linear - wie Invers, jedoch zus�tzlich optimiert f�r starke Schriftvergr��erung
   - chatcss13: Skin Messenger

11. Upload von mp3 BITTE GENAU LESEN UND BEACHTEN!

	Wenn du mp3 Upload im Chat erlauben willst, dann beachte bitte:

	F�r die Ver�ffentlichung von urheberrechtlich gesch�tzten Werken ist VORAB eine Lizenz zu erwerben.
	In Deutschland ist hierf�r die GEMA zust�ndig.
	https://www.gema.de/


	Nachdem du die Lizenz erworben hast, kannst du mp3 Uploads in der chat_config.php freischalten:

	$mp3allow = "xxx";             

	an Stelle von "xxx" schreibe:
	"alle" - Alle d�rfen in allen R�umen mp3 hochladen
	"clean" - mp3 hochladen erlaubt in privaten R�umen, Admins in allen R�umen
	"admins" - nur Admins d�rfen mp3 hochladen (in allen R�umen)
	"" - kein mp3 Uplodad
	
	Tipp: Die Einstellung "clean" und "admins" erm�glicht dem Admin eine bessere Kontrolle �ber die hochgeladenen mp3.
	

	Nachmals:
	F�r die korrekte Lizenzierung von mp3 Uploads ist ausschlie�lich der Chatbetreiber verantwortlich!
	


#############################


HINWEIS: vor du fragst: "wie geht ...." lies bitte erst mal
- diese readme.txt
- die Kommentare in der chat_config.php
- die Hilfe (Link im Chat)
- die FAQ: http://webdesign.weisshart.de/chat-faq.php

Support:
http://webdesign.weisshart.de/forum

- die neueste Version? -> http://webdesign.weisshart.de/chat.php


#############################
Zus�tzliche Funktionen - nur f�r Admins mit guten HTML/PHP/Javscript Kenntnissen:
Diese Funktionen erst dann installieren, wenn der Chat l�uft!
Und wenn du glaubst, "relative Adressierung" spart Briefporto,
dann solltest du die Installation dieser Funktionen eventuell nochmal �berdenken ;-)

ACHTUNG! F�r diese Funktionen gibt es keinerlei Support.
Ich freue mich aber, wenn mir bugs gemeldet werden.


######### Shoutbox ###########
- einfach chat_shoutbox.php in einem iframe passender Gr��e aufrufen.
- Die shoutbox verwendet chatcss1.php. Dort k�nnen weitere Einstellungen vorgenommen werden.
- Hinweis: Auch die Shoutbox erzeugt Traffic und Serverlast, auch beim blo�en Mitlesen!
  �berlege also genau, auf wie vielen Seiten du die shoutbox einbauen willst.
##############################




###### offline Schaltung #####
- Eingabe von /offline schaltet den Chat offline
- in der chat_config.php kannst du einstellen, ob bei offline Schaltung auch private R�ume offline geschaltet werden.
- wenn der Chat offline ist, kannst du in den Raum "Offline" zus�tzliche Informationen eingeben,
  die dann den Besuchern angezeigt werden.
- wieder online schalten: L�schen des Raumes Offline, z.B. durch Eingabe von /del Offline
##############################




######## logfiles ############
- Wenn in der chat_config.php $logfile = "on"; gesetzt ist, werden alte Nachrichten im Ordner /logs gespeichert.
- WICHTIG! den Ordner /logs per .htaccess sch�tzen
- Ein Programm zum Anzeigen der Logfiles gibt es f�r Inhaber einer kommerziellen Lizenz.
- mit der Druckfunktion deines Browsers kannst du die Logfiles ausdrucken
- Achtung! Logfiles k�nnen sehr schnell sehr gro� werden, und viel Speicherplatz belegen.
- Logfiles werden nach 180 Tagen automatisch gel�scht.
##############################


##### user online Anzeige ####
1.   Wenn die Seiten mit der user online Anzeige auf dem gleichen Server liegen, auf dem der Chat l�uft:

1.1. Nur die Gesamtzahl der user anzeigen:

     Hierf�r sind die beiden AJAX Dateien anw_anz.js und anw_anz.php zust�ndig.

     Mit diesem Code wird die Anzahl angezeigt:
     <span id="anw"></span>
     und ans Ende der Datei (unmittelbar vor </body>:
     <script type="text/javascript" src ="pfad_zum_Chat/anw_anz.js"></script>

     User in privaten R�umen k�nnen wahlweise angezeigt werden oder nicht.
     Dazu in der anw_anz.php die Zeile   && strpos($file,"_pr") === false weg-/oder entkommentieren.
     
     Achtung! unter Umst�nden muss die Datei anw_anz.js angepasst werden:
     Die Zeile
         loadurl2('http://' + document.domain + '/chat/anw_anz.php');
     durch den kompletten Pfad ersetzen.


1.2. user pro Raum namentlich auflisten:

     Aufruf mit http://www.Pfad_zum_Verzeichnis/whoson.php
     HINWEIS: Dies kann jeder sehen, der die Adresse aufruft.
     Wenn du das nicht willst: Entweder die Datei whoson.php per .htaccess sch�tzen, oder die Datei whoson.php l�schen 


1.3. die obige Anzeige in einem popup:
     ACHTUNG! hier wird unterstellt, dass die Datei mit dem Aufruf des popup 1 Verzeichnisebene h�her steht als der Chat selbst.
     die Datei whoson.php muss also vom Verzeichnis /chat ins Verzeichnis ./ verschoben werden!
     <a  title="Wer ist online?" href="whoson.php" target="detail" onclick="javascript:window.open('','detail','width=175, height=120, toolbar=no, location=no, menubar=no, scrollbars=yes, status=no, resizable=yes, dependent=no')">die Anzeige der aktuell anwesenden Besucher in einem popup</a>


2.   Anzeige auf einem anderen Server:

     Der Chat schreibt auf Wunsch die Gesamtzahl anwesender user in die Datei user_anw.txt
   
     Der Inhalt dieser Datei user_anw.txt kann nun per Javascript abgefragt und angezeigt werden:
     <script type="text/javascript" src ="http://pfad_zum_chat/user_js.php"></script>
     Diese Anzeige refreshed nicht automatisch.
     
     Anm.: Jeder, der diesen Code kennt, kann damit deine User anzeigen.
           Deshalb ist in der Datei chat_inc.php  der folgenden Abschnitt standardm��ig wegkommentiert
           
     // die Gesamtzahl anwesender user in ein file schreiben fuer externe Abfrage:
     // nicht aktiv. Wer die Funktion will: die folgenden 4 Zeilen entkommentieren
     // $file4 = 'user_anw.txt';
     // $open4 = fopen($file4, "w");
     // fwrite($open4,$countall);
     // fclose($open4);
           

#################################

