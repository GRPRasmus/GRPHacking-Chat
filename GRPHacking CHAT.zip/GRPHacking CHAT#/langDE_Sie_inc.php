<?php
@include("chat_config.php");

########### chat.php: ##############
define("_BLINDHELP",  "Hinweise f&uuml;r blinde Benutzer");
define("_HELP",       "Hilfe");
define("_HELPTITLE",  "Allgemeine Hilfe zum Chat");
define("_MESSAGE",    "Ihre Nachricht");
define("_NICK",       "Name");
define("_SUBMIT",     "Los");
define("_PR",         "Sie sind jetzt im Privatraum ");
define("_ROOM",       "(Fl&uuml;ster-)Raum");
define("_YOUROOM",    "Sie sind im Raum ");
define("_NOROOM",     "<em style=\"color:red\">Dieser Raum existiert nicht!</em><br />Bitte w&auml;hlen Sie einen der &ouml;ffentlichen R&auml;ume aus der Liste." );
define("_NEWROOM",    "Existierenden Raum betreten oder privaten Raum anlegen ");
define("_COMEIN",     "hinein ");
define("_OPT",        "Anzeigeoptionen <dfn>(zum &Ouml;ffnen klicken)</dfn>");
define("_OPT_TITLE",   "Anzeigeoptionen w&auml;hlen");

define("_FONTSIZE",   "Schriftgr&ouml;&szlig;e");
define("_REVERSE",    "Eingabezeile&nbsp;oben&nbsp;");
define("_REVERSEOFF",    "Eingabezeile&nbsp;unten&nbsp;");
define("_INPUT",      "Eingabe&nbsp;einzeilig");
define("_TEXTAREA",   "Eingabe&nbsp;mehrzeilig");

define("_DATEOFF",    "Timeline Datum&nbsp;ausschalten&nbsp;");
define("_TIMEOFF",    "Timeline Zeit&nbsp;ausschalten&nbsp;");
define("_SOUNDOFF",   "T&ouml;ne&nbsp;ausschalten&nbsp;");
define("_COLOROFF",   "Fettschrift&nbsp;");
define("_COLOR2OFF",   "Farben&nbsp;aus&nbsp;");
define("_ONLINEOFF",  "Online-Zeit&nbsp;ausschalten&nbsp;");
define("_HOUROFF",    "Uhrzeit&nbsp;ausschalten&nbsp;");

define("_DATEON",    "Timeline Datum&nbsp;anzeigen&nbsp;");
define("_TIMEON",    "Timeline Zeit&nbsp;anzeigen&nbsp;");
define("_SOUNDON",   "T&ouml;ne&nbsp;spielen&nbsp;");
define("_COLORON",   "Fettschrift&nbsp;aus&nbsp;");
define("_COLOR2ON",   "Farben&nbsp;ein&nbsp;");
define("_ONLINEON",  "Online-Zeit&nbsp;anzeigen&nbsp;");
define("_HOURON",    "Uhrzeit&nbsp;anzeigen&nbsp;");

define("_NICKCOLOR",  "Nickfarbe");
define("_NICKCOLORLABEL",          "Die Farbe f&uuml;r eigene Nachrichten w&auml;hlen");
define("_COL1",       "blau");
define("_COL2",       "rot");
define("_COL3",       "pink");
define("_COL4",       "gold");
define("_COL5",       "gr&uuml;n");
define("_COL6",       "t&uuml;rkis");
define("_COL7",       "hellbraun");
define("_COL8",       "dunkelgrau");
define("_SKIN",       "Seitenstil");
define("_SKINS",      "Skin");
define("_SKINLABEL",  "Den Stil der Seite w&auml;hlen");
define("_ONTIME",     "Online-Zeit");
define("_REALTIME",   "Es ist jetzt");
define("_NOJS",       "Bitte aktivieren Sie Javascript, um den Chat zu betreten!");
define("_NOCOOKIE",   "Ohne cookies l&auml;uft der Chat leider nicht. Bitte erlauben Sie cookies in Ihrem Browser.");
define("_SMIL",       "<span lang=\"en\">Smileys</span> zum Einf&uuml;gen in die Nachricht");
define("_WHERE",      "Wo bin ich?");
define("_REGUSER",    "Sie sind angemeldet als ");
define("_UPLOADLEGEND",    "Datei-Upload");
define("_UPLOADLABEL",    "Das Formular zur Dateisuche zum Hochladen von Bildern und mp3");
define("_YOUR_IP",    "Ihre IP: ");
define("_NO_MP3",    "Verlinken von mp3 ist hier leider nicht erlaubt.");
define("_DOWNLOAD",    "Download");
define("_HIDE_PICS",    " Bilder &amp; Smileys verbergen");
define("_SHOW_PICS",    " Bilder &amp; Smileys zeigen");
define("_HIDE_AVATAR",    " Avatare verbergen");
define("_SHOW_AVATAR",    " Avatare zeigen");
define("_HIDE_POPUP",    " Popup deaktivieren");
define("_SHOW_POPUP",    " Popup aktivieren");
define("_STATION",    "Radiosender w&auml;hlen");
define("_AWAY1",    "Sie sind jetzt (vor&uuml;bergehend) vom Chat abgemeldet, und f&uuml;r andere nicht mehr sichtbar,");
define("_AWAY2",    "solange bis Sie diese Meldung mit OK oder Enter best&auml;tigen.");
define("_SHOW_UP_PLAYER",    "Player [Uploads] zeigen");
define("_HIDE_UP_PLAYER",    "Player [Uploads] verbergen");
define("_SHOW_HTML5_PLAYER",    "Radio [noFlash] zeigen");
define("_HIDE_HTML5_PLAYER",    "Radio [noFlash] verbergen");

define("_TIT_REVERSE", "Das Eingabefeld oberhalb des Nachrichtenfensters platzieren, und die Nachrichten in umgekehrter Reihenfolge ordnen: Neueste Nachricht oben");
define("_TIT_TEXTAREA", "Das Eingabefeld mehrzeilig darstellen. Das mehrzeilige Eingabefeld kann durch Ziehen mit der Maus an der rechten unteren Ecke in der Größe angepasst werden.");
define("_TIT_DATEOFF", "Die Anzeige des Datums im Nachrichtenfenster ausblenden.");
define("_TIT_TIMEOFF", "Die Anzeige der Uhrzeit im Nachrichtenfenster ausblenden.");
define("_TIT_HIDE_PICS", "Die Anzeige aller Bilder, auch Smileys und Avatare, verbergen.");
define("_TIT_HIDE_AVATAR", "Die Anzeige von Avataren verbergen");
define("_TIT_SOUNDOFF", "Alle Benachrichtigungssounds deaktiveren");
define("_TIT_SHOW_POPUP", "Zeigt den Eingang einer Meldung in einem Popup an. Nützlich z. B. in lauter Umgebung. (Muss entsprechend konfiguriert sein.)");
define("_TIT_COLOROFF", "Alle Schriften fett anzeigen");
define("_TIT_COLOR2OFF", "Alle Nachrichten ohne farbliche Unterschiede zeigen");
define("_TIT_HOUROFF", "Die Anzeige der aktuellen Uhrzeit (unterhalb des Skinwählers) auschalten");
define("_TIT_ONLINEOFF", "Die Anzeige der online verbrachten Zeit ausschalten");
define("_TIT_SHOW_UP_PLAYER", "Zeigt einen Player mit den zuletzt hochgeladenen MP3");
define("_TIT_SHOW_HTML5_PLAYER", "Zeigt einen Radioplayer");


########## chat_inc.php: ###########
define("_ALLROOMS",   "R&auml;ume");
define("_PUBLROOMS",  "&Ouml;ffentliche R&auml;ume");
define("_ACTROOM",    "aktueller Raum");
define("_YOURINROOM", "Sie sind im Raum");
define("_ALONE",      "... nur Sie. ");
// define("_GUESTSLOGIN"," G&auml;ste beim Login");
// define("_GUESTLOGIN", " Gast beim Login");
define("_GUESTSLOGIN"," Leser in der Shoutbox (sb)");
define("_GUESTLOGIN", " Leser in der Shoutbox (sb)");

define("_BACKTOSTD",  "zur&uuml;ck in den Raum");
define("_INROOM",     "Derzeit im Raum");
define("_LNKNEWWIN",  "Link &ouml;ffnet in neuem Fenster");
define("_INVITEPR",   "Wollen Sie mit mir in einen privaten Raum?<br />Dann klicken Sie bitte hier: ");
define("_INVITEADVISE",   "Achtung! diese Einladung kann jeder lesen. Wenn Sie das nicht wollen, dann w&auml;hlen Sie einen neuen Namen f&uuml;r den privaten Raum, und schicken Sie die Einladung als private Nachricht (gefl&uuml;stert).");
define("_RENAME",     "nennt sich jetzt");

if (date('G') < 10) {
   $hourgreeting = 'Guten Morgen,';
} elseif (date('G') < 18) {
   $hourgreeting = 'Guten Tag,';
} else {
   $hourgreeting = 'Guten Abend,';
}
define("_NEWUSER", "hat den Chat betreten");


define("_DBLUSER",    " Ein User mit diesem Nick ist (oder war) bereits im Chat.");
//define("_ADMINNICK",  "Dieser nick ist f&uuml;r den Admin reserviert!");
//define("_RESERVED",   "Sorry, dies ist ein reservierter nick!");
define("_WHISPER",    "fl&uuml;stert");
define("_TO",         " mit ");
define("_APPLY",      "anwenden");
define("_CLEAR",      "hat hier mal aufger&auml;umt.");
define("_LOGIN",      " Hallo Gast,<br />bitte geben Sie einen Nicknamen ein,<br />und schicken Sie eine erste Nachricht als Begr&uuml;&szlig;ung,<br />um den Chatraum zu betreten.");
define("_HOURS",      " Uhr");
define("_WHISPERTO",  "Rechtsklick: Einladung in Privatraum. Linksklick: fl&uuml;stern mit ");
define("_NOCHEAT",    "  Bitte nicht gleichzeitig Nick &auml;ndern und fl&uuml;stern!");
define("_USERIMG",    "vom Besucher eingef&uuml;gtes Bild");
define("_FORMIMG",    "[img][/img] ist hier nicht n&ouml;tig, einfach den Link zum Bild eingeben.");
define("_FORMURL",    "Warum machst du dir so viel M&uuml;he mit einem Link, gib einfach die URL ein.");

if (isset($closepr) && $closepr != "yes") {
   define("_OFFLINE",    "Dieser Chatraum ist vor&uuml;bergehend geschlossen.<br />This chat room is temporarily closed. ");
} else {
   define("_OFFLINE",    "Dieser Chatraum ist vor&uuml;bergehend geschlossen.<br />This chat room is temporarily closed. ");
}

define("_CLOSED",    "Dieser Chatraum ist vor&uuml;bergehend geschlossen. &Ouml;ffnungszeit: ");

define("_NOMOD",    " Die Moderator Funktion ist nicht installiert.");
define("_NOLINK",    " Links sind hier nicht erlaubt! ");
define("_NOIMGLINK",    " Externe Bilder einblenden um diese Uhrzeit nicht erlaubt! ");
define("_NOTOPIC",    " Topic setzen ist in Fl&uuml;sterr&auml;umen nicht erlaubt! ");

define("_ROOM_NAME1",    "Achtung! Raumnamen d&uuml;rfen kein Leerzeichen enthalten! L&ouml;schen oder Umbenennen im Ordner /rooms.");
define("_ROOM_NAME2",    "Achtung! Raumnamen m&uuml;ssen mit einem Gro&szlig;buchstaben beginnen! L&ouml;schen oder Umbenennen im Ordner /rooms.");
define("_ROOM_NAME3",    "Ung&uuml;ltiges Zeichen in einem Raumnamen! L&ouml;schen oder Umbenennen im Ordner /rooms.");

define("_WAKEUP",    "Hey! Aufwachen! ");
define("_STOPMSG",    "hat jetzt vorübergehend die Aktualisierung deaktiviert.");


###### Chatbot: #########
define("_HELLO",      "Hallo ");
define("_KBBROKE",    ": was soll das? Immer wieder die gleichen Zeichen!<br /> Ist Ihre Tastatur kaputt?<br />&Uuml;brigens: Diese Meldung sehen nur Sie. Andere User koennen Sie damit nicht nerven.");
define("_FLOOD",      ": Sch&ouml;n dass Sie so schnell tippen koennen.<br />Damit ist aber jetzt mal f&uuml;r eine Weile Schluss! ");
define("_NICKIRC",    "Nein, dies ist kein IRC. Wenn Sie Ihren Nick &auml;ndern wollen, machen Sie das bitte im Eingabefeld f&uuml;r den Nicknamen, oder loggen Sie sich aus und neu ein.");
define("_WHOIRC",     "Nein, dies ist kein IRC. Wenn Sie wissen wollen, wer online ist: rechts oben steht das. Und wenn dort steht: \"... und ganz alleine hier\", dann sind Sie alleine hier.");
define("_MSGIRC",     "Nein, dies ist kein IRC. Private Nachrichten erstellt man durch Anklicken des Users in der Liste rechts oben.");
define("_HELPIRC",    "schauen Sie bitte mal hier: <a href=\"help.php\">Hilfe</a> - oder hier: <a href=\"http://webdesign.weisshart.de/chat-faq.php\">FAQ</a>");
// define("_README",     "ich denke, du solltest mal die <a href=\"http://webdesign.weisshart.de/chat/readme.txt\">readme.txt</a> lesen.");
define("_LICENCE",    "Sie wollen den Werbelink weg haben? <a href=\"http://webdesign.weisshart.de/chat-lizenz.php\">bitte, gern!</a>");

define("_PROFIL",    "Ihr Profil");
define("_XPROFIL",    "Registrierte User k&ouml;nnen hier ihr <a href=\"profil.php\">Profil bearbeiten</a>");
define("_SHOW_PROFIL",    "Nur registrierte User d&uuml;rfen Profile anschauen.");

define("_LISTIRC",    "Die Sache mit den R&auml;umen funktioniert hier etwas anders als im IRC: <a href=\"help.php#roomhelp\">Hilfe zu R&auml;umen</a>");
define("_AGEQUEST",   " wie alt ");
define("_AGE",        "Hi, ich bin der Chatbot, und ich bin ");
define("_AGE2",       " Sekunden alt.");
define("_GENDERQUEST"," m oder w");
define("_GENDER",     "Hi, ich bin der Chatbot, und ich bin <a href=\"http://de.wikipedia.org/wiki/Hermaphrodit\">Hermaphrodit.</a>");
define("_SORRY",      "<span lang=\"en\">Sorry</span>");
define("_ADMINONLY",  ", dieser Befehl steht nur dem Admin zur Verf&uuml;gung");
define("_MUZZLED",    ", Kurze Sendepause. Bitte nutzen Sie die Zeit, um &uuml;ber Ihr Verhalten nachzudenken.");
define("_ERASE",      "Wenn Sie fl&uuml;stern wollen, dann klicken Sie bitte einen Namen in der Liste der anwesenden User (rechts oben!).<br />Um einen User direkt anzusprechen, klicken Sie auf den Namen vor einer Nachricht, oder schreiben Sie einfach @Nickname in Ihren Text. Diese Nachricht wird dann beim Angesprochenen <span style=\"font-weight:bold; background:yellow\">so hervorgehoben</span>.");
define("_APPROVE",      ", so schaltet der Moderator Beitr&auml;ge frei. Aber eben NUR der Moderator.");
define("_YTERROR",      " Hinweis: Ein YouTube-Link darf keinen zus&auml;tzlichen Text enthalten! ");




########## chat_js.php: ###########
define("_NICKNOTALLOWED",   "Dieser Nick ist nicht erlaubt!");
define("_CHARNOTALLOWED",   "Nicht erlaubte Zeichen im Nick!");
define("_CHARNOTALLOWEDMSG",   "Nicht erlaubte Zeichen in der Nachricht!");
define("_ROOMNOTALLOWED",   "Nicht erlaubte Zeichen im Raumnamen!");
define("_TIMEOUT",    "..... Chat disconnected (timeout) \\n\\nHey, hier ist ein Chat, und keine \u00f6ffentliche W\u00e4rmestube!");
define("_NOCOOKIEALERT",   "Hinweis: \\nBitte cookies erlauben!\\nDann erscheint Ihr Nick auch in der Liste der online user,\\nund diese Meldung verschwindet.");
define("_JSADMINONLY",  "Dieser Befehl steht nur dem Admin zur Verf\u00fcgung!");
define("_NOHTML",  "Kein HTML hier!");

define("_JSERASE",      "Wenn Sie fl\u00fcstern wollen klicken Sie bitte einen Namen in der Liste der anwesenden User (rechts oben!).\\n\\nUm einen User direkt anzusprechen, schreiben Sie einfach @Nickname in Ihren Text,\\noder klicken Sie den Namen vor einer Nachricht.\\nDiese Nachricht wird dann beim Angesprochenen hervorgehoben.");
define("_JSIRC",      "HIer ist kein IRC!\\nBitte schauen Sie in der Hilfe, welche Befehle hier verf\u00fcgbar sind.");
define("_DELROOM",      "Wollen Sie den eingegebenen Raum wirklich l\u00f6schen und entfernen?\\n\\nHinweis: den Raum, in dem Sie sich befinden, k\u00f6nnen Sie nicht l\u00f6schen.");
define("_WHISPERNOTALLOWED",      "Fl\u00fcstern ist nur erlaubt, wenn ein Admin beteiligt ist.");
define("_WHISPERROOMSNOTALLOWED",      "Fl\u00fcsterr\u00e4ume darf nur der Admin \u00f6ffnen.");
define("_READONLY",      "Als Gast k\u00f6nnen Sie nicht schreiben.\\n\\nUm zu schreiben, loggen Sie sich bitte aus,\\nund melden sich mit Ihrem registrierten Nicknamen an,\\noder registrieren Sie sich.");
define("_CHARREP",      "Sieht so aus, als ob Ihre Tastatur klemmt?\\nBitte \u00fcberpr\u00fcfen Sie Ihre Eingabe.");
define("_MULTURL",      "Nur ein Link/Dateiupload pro Eingabe erlaubt!");
define("_NOBLANK",      "Keine Leerzeichen in Dateinamen erlaubt!");
define("_UPPERCASE",      "Sieht so aus, als ob Ihre Tastatur kaputt ist.\\nHat sie nur Gro\u00dfbuchstaben?\\nSo etwas gilt im Chat als unh\u00f6flich.");
define("_AWAY",    "Sie sind jetzt (vorübergehend) vom Chat abgemeldet, \\nund für andere nicht mehr sichtbar, \\nbis Sie diese Meldung bestätigen.");
define("_AWAY_MSG",    "ist jetzt mal afk");
define("_WARM_MSG",    "hat sich in die W\u00e4rmestube zur\u00fcckgezogen.");

########## upa.php ################
if (!isset($gifsize)) {$gifsize = 64;}

define("_UPDONE",     "Upload&nbsp;abgeschlossen.&nbsp;Klicken&nbsp;Sie&nbsp;hier,&nbsp;um&nbsp;die&nbsp;Datei&nbsp;einzuf&uuml;gen.");
define("_JPGERR",     "Fehlerhaftes&nbsp;jpg-Bild");
define("_TYPEERR",    "Ung&uuml;ltiges&nbsp;Dateiformat.&nbsp;Zul&auml;ssig&nbsp;sind&nbsp;nur&nbsp;jpg,&nbsp;png,&nbsp;bmp&nbsp;und&nbsp;gif&nbsp;sowie&nbsp;mp3&nbsp;Dateien.");
define("_SIZEERR",    "Datei&nbsp;zu&nbsp;gro&szlig;, max.&nbsp;$maxsize&nbsp;kB&nbsp;jpg/png/mp3&nbsp;bzw.&nbsp;$gifsize&nbsp;kB&nbsp;gif&nbsp;erlaubt.");
define("_SIZEERR1",    "Datei&nbsp;zu&nbsp;gro&szlig;, max.&nbsp;");
define("_SIZEERR2",    "&nbsp;kB&nbsp;jpg/png/mp3&nbsp;bzw.&nbsp;$gifsize&nbsp;kB&nbsp;gif&nbsp;erlaubt.");
define("_UPERR",      "Fehler&nbsp;beim&nbsp;Datei-Uplaod.");
define("_MP3ADMINONLY",      "nur&nbsp;der&nbsp;Admin&nbsp;darf&nbsp;mp3&nbsp;hochladen");
define("_SWFADMINONLY",      "nur&nbsp;der&nbsp;Admin&nbsp;darf&nbsp;Flash&nbsp;hochladen");

######### usr_smileys.php #########
define("_USR_SMILEY1",      "Einfach Smileys anklicken, dann erscheinen sie in der Nachrichtenzeile, und LOS oder Enter<br />Admin: Mehr Smileys? Einfach in den Ordner ");
define("_USR_SMILEY2",      " ... Fertig! - oder /add URL im Nachrichtenfeld.<br />Oder, noch einfacher: /add und drag&nbsp;&amp;&nbsp;drop.<br />Achtung! Keine Leerzeichen in Dateinamen erlaubt!");


######## login.php ###
define("_LOGIN_H1",     "Chat Login");

define("_LOGIN_FORM",     "Anmeldedaten angeben");
define("_LOGIN_FORM1",     "Gew&uuml;nschte Anmeldedaten angeben");
define("_LOGIN_FORM2",     "Passwort falsch!");
define("_LOGIN_FORM3",     "Dieser Nickname ist nicht registriert!");
define("_LOGIN_FORM4",      "Merken (cookie)");


define("_LOGIN_FORM_FORUM1",     "Bitte Anmeldedaten eingeben!");
define("_LOGIN_FORM_FORUM2",     "Es gibt bereits einen registrierten User mit diesem Nick!");
define("_LOGIN_FORM_FORUM3",     "Dieser Nick ist nicht erlaubt!");
define("_LOGIN_FORM_FORUM4",     "Nicht erlaubte Zeichen im Nick!");

define("_LOGIN_GUEST",     "Gastzugang ohne Registrierung");
define("_LOGIN_GUEST2",     "Nickname:");
define("_LOGIN_GUEST3",     "Passwort:");
define("_LOGIN_GUEST4",     "mit einem Gast-Zugang k&ouml;nnen Sie sofort loschatten.");
define("_LOGIN_GUEST5",     "Achtung! Mit einer Gast-Anmeldung k&ouml;nnen Sie nur lesen.<br />Bitte <a href='reg.php'>registrieren Sie sich</a>, um auch zu schreiben.");


define("_TO_REG",     "Registrieren Sie sich, um Ihren Nicknamen zu sch&uuml;tzen");
define("_TO_REG2",     " und Zugang zu Userprofilen zu erlangen");
define("_TO_REG3",     "zur Registrierung");

define("_WHOSON",     "wer ist gerade online? (Popup)");
define("_NO_REG",	"Nicht registriert?<br />Nickname ohne Passwort eingeben<br />oder <br />Nickname: Gast<br />Passwort: demo");
define("_NO_REG_NO_GUEST",	"Nicht registriert?<br />Einfach Passwortfeld leer lassen");
define("_LOG_FORM",     "Gast-Login m&ouml;glich ");
define("_SEC",     "&nbsp;Sekunden");



######## reg.php #####
define("_REG_H1",     "Chat Registrierung");

define("_REG_FORM",     "Kein Nickname eingegeben!");
define("_REG_FORM1",     "Nickname zu kurz!");
define("_REG_FORM2",     "Kein Passwort eingegeben!");
define("_REG_FORM3",     "Passw&ouml;rter stimmen nicht &uuml;berein!");
define("_REG_FORM4",     "Bitte g&uuml;ltige E-Mail eingeben!");
define("_REG_FORM5",     "Das folgende Feld muss leer bleiben:");
define("_REG_FORM6",     "Passwort wiederholen:");
define("_REG_FORM7",     "E-Mail (wird nicht angezeigt):");
define("_REG_FORM8",     "E-Mail (freiwillig, wird nicht angezeigt):");
define("_REG_FORM9",     "Registrieren");
define("_REG_FORM10",     "Registrierung m&ouml;glich ");


define("_REG_HINWEIS",     "Erlaubt sind nur Buchstaben, Ziffern und der Unterstrich ( _ ) keine Leerzeichen!");
define("_REG_HINWEIS1",     "ACHTUNG! Das Passwort kann vom User nicht ge&auml;ndert werden. Nur der Admin kann es zur&uuml;cksetzen!");
define("_REG_HINWEIS2",     "registrierte User");
define("_REG_HINWEIS3",     "(Testregistrierungen sind hier in der Demo erlaubt, werden aber gelegentlich kommentarlos gel&ouml;scht.)");

define("_TO_LOGIN",     "zur Login Seite");

####### logout.php ####

define("_LOGOUT",     "Danke f&uuml;r deinen Besuch im Chat.");
define("_LOGOUT1",     "Du kannst dieses Fenster jetzt schlie&szlig;en.");
define("_LOGOUT2",     "Zur Chat-Infoseite");
define("_LOGOUT3",     "hat sich aus dem Chat ausgeloggt");



?>