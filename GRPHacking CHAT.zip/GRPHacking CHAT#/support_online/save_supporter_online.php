<?php
	$d = fopen("support_on.txt","w");
	fwrite($d, "y",1);
	fclose($d);
?>