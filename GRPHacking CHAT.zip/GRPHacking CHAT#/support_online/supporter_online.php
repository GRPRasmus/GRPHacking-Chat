<!DOCTYPE html>
<html lang="de">	
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />

<!-- favicon Standard nicht rot damit nicht eingeloggter status erkennbar -->
<!-- <link rel="icon" href="offline.png" type="image/png"> -->

<title>Supporter anwesend?</title>
<style>
form#manuell input:hover, label:hover {cursor:pointer;color:red;}
</style>
</head>
<body>
	
<h1>Support im Chat verfügbar?</h1>
<p>Wenn die folgende Checkbox aktiviert wird, kann in einer beliebigen externen Datei angezeigt werden, dass ein Supporter im Chat verfügbar ist.
<br />Deaktivieren der Checkbox, oder Schließen dieser Datei zeigt den Support als "nicht verfügbar".
<br />Die Datei support.html im Ordner /chat dient als Demo. (Die Aktualisierung der Anzeige kann dort bis zu 20 Sekunden verzögert sein.) Im Quelltext dieser Datei ist die Verwendung der Funktion beschrieben. 
<p>Hinweis: "Support verfügbar" wird auch angezeigt, wenn die Funktion $supporter (chat_config) benutzt wird, und ein Supporter im Chat ist.
<hr />
<form id="manuell">
	<input type="checkbox" id="data" onchange="shave();" />
	<label for ="data" > als verfügbar anzeigen </label>
</form>

<div id="ton"></div>

<script>
// https://gist.github.com/mathiasbynens/428626
// HTML5™, baby! http://mathiasbynens.be/notes/document-head
document.head = document.head || (document.getElementsByTagName('head')[0]);

function changeFavicon(src) {
	
	if (src.indexOf('online') == -1) { // verhindert Flackern des favicons
		src = src+'?='+Math.random(); // so wird das cachen zuverlässig vermieden
	}
	var link = document.createElement('link'),
	oldLink = document.getElementById('dynamic-favicon');
	link.id = 'dynamic-favicon';
	link.rel = 'icon';
	link.href = src;
	if (oldLink) {
		document.head.removeChild(oldLink);
	}
	document.head.appendChild(link);
	
}

var anw;
var anw_alt;

function playsound(src) {
	if (document.getElementById('ton')) {
		document.getElementById("ton").innerHTML = '<audio src="'+src+'" autoplay ></audio>';
	}
}

var update_refresh;
var update_shave;
/* http://techslides.com/save-file-with-ajax-and-php */
function shave(){
	if (document.getElementById("data").checked == true) {
		anw = 1;
		if (anw != anw_alt) {
			playsound('support_online.mp3');
			anw_alt = 1;
		}
		clearTimeout(update_refresh); // damit die Einstellung nicht von update überschrieben wird - dauerhaft
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.open("GET","save_supporter_online.php",true);
		xmlhttp.send();
		changeFavicon('online.png');
		document.title = "Support verfügbar";
		update_shave = setTimeout('shave()', 5000); // hier muss die Funktions-Klammer - Paranoia
		
	} else {
		anw =	 0;
		if (anw != anw_alt) {
			playsound('support_offline.mp3');
			anw_alt = 0;
		}	
		clearTimeout(update_refresh); // damit die Einstellung nicht von update überschrieben wird
		clearTimeout(update_shave); // damit die Einstellung nicht noch einmal abgefragt wird
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.open("GET","save_supporter_offline.php",true);
		xmlhttp.send();
		changeFavicon('offline.png');	
		document.title = "Support offline";	
		setTimeout(update,20000); // nach x sec wieder update aktivieren	
	}
}


/* Favicon ändern, wenn Supporter online: */
var testObj = null;
    testObj = new XMLHttpRequest();

function eineFunktion() {
    if (testObj.readyState == 4) {
//		alert (testObj.responseText);
		if (testObj.responseText.indexOf('1') != -1) {
			anw = 1;
			if (anw != anw_alt) {
				playsound('support_online.mp3');
				document.getElementById("data").checked = true;
				changeFavicon('online.png');
				document.title = "Support verfügbar";
				anw_alt = 1;
			}
			
		} else {
			anw =	 0;
			if (anw != anw_alt) {
				playsound('support_offline.mp3');
				document.getElementById("data").checked = false;
				changeFavicon('offline.png');	
				document.title = "Support offline";	
				anw_alt = 0;
			}
		}
    }
}

function update() {
    testObj.open("GET", "../support_online.php");
    testObj.onreadystatechange = eineFunktion;
    testObj.send(null);
	update_refresh = setTimeout(update,8000); // hier darf keine Funktions-Klammer - Paranoia
}

window.onload = update;

</script>

</body>
</html>