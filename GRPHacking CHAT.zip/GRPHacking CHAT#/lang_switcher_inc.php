<?php



// die Sprachumschaltung.
// http://start.grafikuniversum.de/flaggen/flaggen.htm
if (count($languages) > 1) {
      echo "<p>";

      switch ($lang) {
              default:
                         if(@in_array('en',$languages)) {
                              echo '<a class="flag" href="'.$_SERVER['PHP_SELF'].'" onclick=\'setlang("en")\'><img src="img/engl.gif" style="border:1px solid transparent" alt="Select language: English" title="English" width="31" height="20" /></a><span class="dot"> | </span>';
                         }
                         // if(@in_array('es',$languages)) {
                         // }
                         echo '<img class="flag" src="img/deu.gif" style="opacity:.2;border:1px solid transparent" alt="Aktuelle Sprache: Deutsch." title="Aktuelle Sprache: Deutsch" width="31" height="20" /><span class="dot"> | </span>';
              break;

              case "de":
                         if(@in_array('en',$languages)) {
                              echo '<a class="flag" href="'.$_SERVER['PHP_SELF'].'" onclick=\'setlang("en")\'><img src="img/engl.gif"  style="border:1px solid transparent" alt="Select language: English" title="English" width="31" height="20" /></a><span class="dot"> | </span>';
                         }
                         // if(@in_array('es',$languages)) {
                         // }
                         echo '<img class="flag" src="img/deu.gif" style="opacity:.2;border:1px solid transparent" alt="Aktuelle Sprache: Deutsch." title="aktuelle Sprache: Deutsch" width="31" height="20" /><span class="dot"> | </span>';
              break;

              case "en":
                         echo '<img class="flag" src="img/engl.gif" style="opacity:.2;border:1px solid transparent" alt="Current language: English." title="Current language: English" width="31" height="20" /><span class="dot"> | </span>';
                         // if(@in_array('es',$languages)) {
                         // }
                         if(@in_array('de',$languages)) {
                              echo '<a class="flag" href="'.$_SERVER['PHP_SELF'].'" onclick=\'setlang("de")\'><img src="img/deu.gif" style="border:1px solid transparent" alt="Sprache w&auml;hlen: Deutsch" title="Deutsch" width="31" height="20" /></a><span class="dot"> | </span>';
                         }
              break;

              // case "es":
              //            if(@in_array('en',$languages)) {
              //                 echo '<a class="flag" href="'.$_SERVER['PHP_SELF'].'" onclick=\'setlang("en")\'><img src="img/engl.gif" alt="Select language: English" title="English" width="31" height="20" /></a><span class="dot"> | </span>';
              //            }
              //            echo '<img class="flag" src="img/es_akt.gif" alt="Lengua actual: Español" title="Lengua actual: Español" width="31" height="20" /><span class="dot"> | </span>';
              //
              //            if(@in_array('de',$languages)) {
              //                 echo '<a class="flag" href="'.$_SERVER['PHP_SELF'].'" onclick=\'setlang("de")\'><img src="img/deu.gif" alt="Sprache w&auml;hlen: Deutsch" title="Deutsch" width="31" height="20" /></a><span class="dot"> | </span>';
              //            }
              // break;
              //

      }
      echo "</p>";
}
?>