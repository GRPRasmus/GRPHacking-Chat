<?php
// die /user/user.txt bereinigen:
include ('admin_schutz_abfragen.php');

$dateiname = "../user/user.txt"; // Name der Datei

if (isset($_GET['string'])) {
	$string = htmlentities($_GET['string']) ;
} else {
	$string ="xxxxx";
}


if (file_exists($dateiname)) {
	$change1 = false;
	$lines = file($dateiname);

	foreach($lines as $key => $val) {

		if ($string !="xxxxx") {
			if (strpos($val,$string) === false) {
				$newline .= $val;		 
			} else {
				$change1 = true; // eine Zeile wurde geloescht
			}
		}
	}

	if ($change1 === true) { // Datei nur neu schreiben, wenn mindestens eine Zeile geloescht wurde
		$handler = fopen($dateiname, "w");
		fwrite($handler , $newline);
		fclose($handler);
		$answer = "user.txt um $string bereinigt";
	} else {
		$answer = "keine Daten zum Bereinigen gefunden";
	}
}

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" /> <!-- iPhone -->
	
<title>user.txt bereinigen</title>	

<link rel="stylesheet" type="text/css" media="screen" href="admin.css" />
	

</head>
<body>

<h1>Registrierungsdatei user.txt bereinigen</h1>
<p>Beispiel: "02.2012" (ohne Anführungszeichen) löscht alle Registrierungen aus Februar 2012, die nach dem Februar 2012 nicht mehr im Chat waren.</p>


<form action="admin_reg.php" method="GET">
	<label for="string">zu löschender String:</label> <input type="text" name="string" value="" id="string">
</form>

<br />
<?php
if ($string !="xxxxx") {
	echo $answer;
}
?>


<?php include ("admin_inc.php")?>



</body>
</html>


