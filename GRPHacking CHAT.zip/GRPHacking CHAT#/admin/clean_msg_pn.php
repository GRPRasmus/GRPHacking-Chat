<?php
/* rooms bereinigen - (fl&uuml;stert  mit endgueltig loeschen:
Geloeschte Nachrichten werden dann auch nicht mehr ins Archiv uebernommen
*/

echo '<p><a href="admin.php">zurueck zu den Admin-Tools</a></p>';

if (isset($_GET['room'])) {
	$zu_bereinigen = $_GET['room'];
} 

	echo '<b>In welchem Raum sollen gefluesterte Nachrichten endgueltig entfernt werden?</b><br /><br />';
	// Verzeichnis Datei für Datei lesen
	$dirHandle = dir("../rooms/");
	$list="";
	while (($file = $dirHandle->read()) != false) {
		if($file != '.' && $file != '..' && $file != '.htaccess') {
			$list .= '<a href="clean_msg_pn.php?room='.$file.'">'.$file.'</a><br />';
		}
	}
	// Verzeichnis wieder schließen
	$dirHandle->close();
	echo $list;
	echo '<br />';


$clean_dir = '../rooms/';

// Ordner anlegen:
if(!is_dir("../rooms_sav")) {
	$old_umask = umask(0);
	mkdir ("../rooms_sav", 0777);
	umask($old_umask);
}

$sav_dir = '../rooms_sav/';
$log_dir=opendir($clean_dir);

while ($file = readdir ($log_dir)) {


if (isset($zu_bereinigen)) {
	if ($file == $zu_bereinigen) {


		$room_dateiname = $clean_dir.$file; // Name der Datei
		if (file_exists($room_dateiname)) {
			
			// Sicherungskopie erstellen:
			copy($room_dateiname,$sav_dir.$file);
			
			$change1 = false;
			$newline = "";
			$lines = file($room_dateiname);

			$i=0;
			foreach($lines as $key => $val) {
				if (strpos ( $val , '/pn' ) === false &&strpos ( $val , 'betritt' ) === false && strpos ( $val , 'betreten' ) === false && strpos ( $val , 'entered the chatroom' ) === false && strpos ( $val , 'ausgeloggt' ) === false && strpos ( $val , 'has logged off' ) === false && strpos ( $val , 'Wärmestube' ) === false && strpos ( $val , 'calefactory' ) === false  && strpos ( $val , 'away from keyboard' ) === false) {
					$newline .= $val;		 
				} else {
					$change1 = true; // eine Zeile wurde geloescht
					$i++;
				}
			}
		
			if ($change1 === true) { // Datei nur neu schreiben, wenn mindestens eine Zeile geloescht wurde
				$handler = fopen($room_dateiname, "w");
				fwrite($handler , $newline);
				fclose($handler);
			}
		}
	}
}
}

if (isset($zu_bereinigen)) {
	if ($change1 === true) {
		echo "$i Zeilen im Raum $zu_bereinigen endgültig gelöscht.";
	} else {
		echo "Keine Datei bereinigt - nichts zu bereinigen.";
	}
	echo '<p><a href="../chat.php">zurueck zum Chat</a></p>';
	
}

?>


