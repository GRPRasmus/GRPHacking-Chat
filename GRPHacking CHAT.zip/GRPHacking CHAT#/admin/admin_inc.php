<h2>Weitere Admin Tools</h2>
<p><a href="../chat.php">zum Chat</a></p>

<ul>

<?php
$a = $_SERVER['SCRIPT_NAME'];

if (strpos($a,'admin.php')!==false) {
	echo '<li>Registrierungs-Verwaltung zeilenweise</li>';
} else {
	echo '<li><a href="admin.php">Registrierungs-Verwaltung zeilenweise</a></li>';
}

if (strpos($a,'admin_reg.php')!==false) {
	echo '<li>Registrierung Batch-Bereinigung</li>';
} else {
	echo '<li><a href="admin_reg.php">Registrierung Batch-Bereinigung</a></li>';
}

if (strpos($a,'clean_user.php')!==false) {
	echo '<li>Alle Registrierungen letzter Besuch &auml;lter als 120 Tage l&ouml;schen OHNE R&Uuml;CKFRAGE! </li>';
} else {
	echo '<li><a href="clean_user.php">Alle Registrierungen letzter Besuch &auml;lter als 120 Tage l&ouml;schen OHNE R&Uuml;CKFRAGE!</a></li>';
}

if (file_exists("gema_q.php")) {
	echo '<li>Info: <a href="gema_q.php">Gestreamte mp3</a></li>';
}

if (strpos($a,'admin_ban.php')!==false) {
	echo '<li>Ban-Verwaltung </li>';
} else {
	echo '<li><a href="admin_ban.php">Ban-Verwaltung</a></li>';
}

if (strpos($a,'admin_maul.php')!==false) {
	echo '<li>Maulkorb-Verwaltung </li>';
} else {
	echo '<li><a href="admin_maul.php">Maulkorb-Verwaltung</a></li> ';
}

if (strpos($a,'admin_admins.php')!==false) {
	echo '<li>Admins verwalten </li>';
} else {
	echo '<li><a href="admin_admins.php">Admins verwalten</a></li> ';
}

if (strpos($a,'admin_mods.php')!==false) {
	echo '<li>Mods verwalten </li>';
} else {
	echo '<li><a href="admin_mods.php">Mods verwalten</a></li> ';
}

if (file_exists("../rooms/Intern")) {
	if (strpos($a,'admin_interne.php')!==false) {
		echo '<li>Zugang zu Sonderräumen verwalten </li>';
	} else {
		echo '<li><a href="admin_interne.php">Zugang zu Sonderräumen verwalten</a></li>';
	}
}
?>



</ul>

<h3>Räume bereinigen</h3>
<ul>

<li><a href="clean_msg_pn.php">Geflüsterte und gelöschte Nachrichten sowie "betritt..." usw. endgültig entfernen (und nicht archivieren).</a></li>
<li><a href="clean_msg_del.php">(Nur) gelöschte Nachrichten endgültig entfernen (und nicht archivieren).</a></li>

<li><a href="clean_cookies.php">Alle Cookies löschen. (Setzt OHNE RÜCKFRAGE! alle Optionen auf Standardwerte, und entfernt Müll.)</a></li>
</ul>