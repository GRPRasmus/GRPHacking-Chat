<?php
// die user.txt bereinigen, uralte inaktive Registrierungen loeschen (diese Datei im Browser aufrufen):

date_default_timezone_set('Europe/Berlin');

$tage = 120; // max. Alter von Registrierungen


// vorab backup erstellen

include 'backup_user.php';


$user_dateiname = "../user/user.txt"; // Name der Datei
if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {

		// das Datum des letzten Zugriffs
		$teile = explode("****", $val);
		$last_access = $teile[3];
		// vorbereiten f�r strtotime
		$datum_teile = explode(" ", $last_access);
		$datum_teile1 = explode(".", $datum_teile[0]);
		$last_access_new = $datum_teile1[2].'-'.$datum_teile1[1].'-'.$datum_teile1[0].' '.$datum_teile[1];
		// Unix Timestamp des letzten Zugriffs
		$access = strtotime($last_access_new);

		if (time() - $access < (60*60*24*$tage) || $teile[0] == 'Gast' ) {
			$newline4 .= $val;		 
		}
	}

	$handler4 = fopen($user_dateiname, "w");
	fwrite($handler4 , $newline4);
	fclose($handler4);
	
	echo "<br />Datei user/user.txt bereinigt. Alle Registrierungen &auml;lter als $tage Tage gel&ouml;scht.";
}
?>