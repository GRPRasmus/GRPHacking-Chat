<?php

// user.txt backupen:

$file = '../user/user.txt';
$newfile = '../user/user.txt_'.time().'.bak';


if (!copy($file, $newfile)) {
    echo "Sicherung der Dateu $file schlug fehl...\n";
} else {
    echo "Backup der Datei $file nach $newfile erfolgreich. \n";
}


?>