<?php

echo 'Alle Cookies wurden geloescht.';
echo '<p><a href="admin.php">zurueck zu den Admin-Tools</a></p>';
echo '<p><a href="../chat.php">zurueck zum Chat</a></p>';


$pfad = dirname($_SERVER['SCRIPT_FILENAME']);
$parts = explode('/',$pfad);
end($parts);
$install = '/'.prev($parts);

$chatcookies = array('showip',
'pop_up',
'showip',
'time_real',
'color',
'time_online',
'listen',
'size',
'Style',
'lang',
'LoginCookie',
'Login',
'watch',
'stop',
'Ankunft',
'bilder',
'chat_up_player',
'html5player',
'mehrzeilig',
'nickfarben',
'nickfarben2',
'reverse',
'sound',
'schrift'
		
);



if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
	
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
		
		if (in_array($name, $chatcookies) || strpos($name,'arrival') !== false) {
			unset($_COOKIE[$name]);
			$res = setcookie($name, '', time() - 3600,$install);
		}
    }
}
?>
