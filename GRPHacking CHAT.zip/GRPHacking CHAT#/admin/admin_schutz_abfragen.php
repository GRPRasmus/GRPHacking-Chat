<?php
if (!file_exists(".htaccess")) {
	echo 'Bitte vor dem Aufruf der Admin-Tools einen .htaccess-Passwortschutz auf diesen Ordner einrichten, 
	<br />oder zumindest das Setup fertigstellen, indem einmal <a href="../chat.php">chat.php</a> aufgerufen wird.
	<br />Eventuell muss auch die Datei setup.php aus dem Download-Archiv erneut auf den Server hochgeladen werden.
	';
	exit();
}
?>