<?php
##########################################
# wenn du diese Datei umbenennst in  personal_config_inc.php,
# und hier nur die von dir geänderten Variablen reinstellst,
# dann kannst du bei zukünftigen updates die Konfigurationsdatei chat_inc.php auch überschreiben lassen.
# deine privaten Einstellungen bleiben dann erhalten
##########################################






?>