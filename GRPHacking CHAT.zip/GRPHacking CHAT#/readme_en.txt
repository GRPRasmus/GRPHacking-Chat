The chat http://webdesign.weisshart.de

#############################################
Installation:

1. unzip the downloaded archive chat.zip (do not unzip on the server, but locally!)
   Make sure that the folder structure (subdirectories) will be maintained during extraction.
   
2. upload the unzipped files to a new directory called /chat on the server.

3. Invoke the chat in your browser with http://www.path_to_your_chat
   e.g. http://www.mydomain.de/chat/chat.php

   IMPORTANT! if you cannot write in the chat:
   CHMOD the directories "rooms", "user", "admin", "upload", "cache", "smileys", "sounds" and "logs": 777
   CHMOD the file Standard in directory /rooms: 666
   CHMOD the file clear.txt in the root directory /chat: 666
   CHMOD the file user.txt in the directory /user: 666
   CHMOD the file flood.txt in the directory /user: 666

4. Once you can write in the chat (and only if):
   Edit the file chat_config.php using a text editor.
   First thing to do: modify the nicknames of the admins: 
   $admins = array(
    'Max',
	...
	
5. IMPORTANT! protect the admin nicknames
   Call the file reg.php in a web browser.
   Alternatively this this can be done by clicking "X... Logout" in the chatroom, then "to login ..." and then "Registration".
   
   Now register every admin nick with its own password.
   IMPORTANT! Register every admin nick previously declared in the file chat_config.php!

   Notes:
   - If you log in as admin, [Admin] will show after your nick next to the Submit Button 
   - Avaiable admin commands will show in the online help if you're logged in as admin.

6. Edit registrations:
   To delete file registrations call path_to_chat/admin/admin.php in your browser.
   IMPORTANT! Protect the directory /admin using .htaccess  

7. Configuration options are described in the file chat_config.php.
   It's best to configure step by step, and test the result of every step.
   Please note the advice at the end of chat_config.php

8. Adjustment of colors, etc.: chatcss1.php to chatcss12.php
   - Chatcss1: Shoutbox
   - Chatcss2: Skin Boxes
   - Chatcss3: Skin Web2
   - Chatcss4: Skin Black
   - Chatcss5: Skin Stage
   - Chatcss6: Skin Flowers
   - Chatcss7: Skin PDA (automatically used on many mobile phones and PDAs)
   - Chatcss8: Skin Firebox
   - Chatcss9: Skin Castle
   - Chatcss10: Skin Sky
   - Chatcss11: Skin inverse - optimized for readability
   - Chatcss12: Skin linear - similar to inverse, optimized for accessibility


Support:
http://webdesign.weisshart.de/forum

- Download of most recent version -> http://webdesign.weisshart.de/chat.php

#############################
