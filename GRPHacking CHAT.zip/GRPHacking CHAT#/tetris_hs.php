<?php

include("chat_config.php");


if(isset($_POST['nick'])) {
	
	$number = $_POST['hs'];
	$length = 5;
	$string = substr(str_repeat(0, $length).$number, - $length);

	$inhalt = $string.' '.$_POST['nick']."\n";

	$handle = fopen ("tetris_hs.txt", "a+");
	fwrite ($handle, $inhalt);
	fclose ($handle);
	
	
	$herein ='<p><span class="dt">'.date("d\.m\.").'</span> <span class="uz">'.date("H:i:s").'</span><span class="tr"> | </span>'.$prof_link.' <span class="hello" oncontextmenu="ads(\'/erase '.date("H:i:s").'\'); return false;" onclick="ads(\'\u0040'.$_SESSION["chatuser"].'\'); return false; "  title ="'.date("d\.m\. H:i:s").'" style="color:#888; cursor: pointer">['.$_SESSION["chatuser"].'</span><span class="hello">Neuer Tetris-Score von '.$_POST["nick"].' eingetragen: '.$string.']</span> </span> '.$ip_login.'</p>'.PHP_EOL;	
	
	
	$file5 = 'rooms/'.$standard;
	$open5 = fopen($file5, "a");
	fwrite($open5,$herein);
	fclose($open5);
	
	
	
	
}

header("Location: tetris.php");

?>
