<?php

// Ordner anlegen:
if(!is_dir("rooms")) {
	$old_umask = umask(0);
	mkdir ("rooms", 0777);
	umask($old_umask);
}
if (!is_writable("rooms")) {
	if (true !== (@chmod ("rooms", 0777))) echo "<br>Bitte Ordner /rooms CHMOD 777 Rechte setzen";
}

if(!is_dir("user")) {
	$old_umask = umask(0);
	mkdir ("user", 0777);
	umask($old_umask);
}
if (!is_writable("user")) {
	if (true !== (@chmod ("user", 0777))) echo "<br>Bitte Ordner /user CHMOD 777 Rechte setzen";
}

if(!is_dir("logs")) {
	$old_umask = umask(0);
	mkdir ("logs", 0777);
	umask($old_umask);
}
if (!is_writable("logs")) {
	if (true !== (@chmod ("logs", 0777))) echo "<br>Bitte Ordner /logs CHMOD 777 Rechte setzen";
}

if(!is_dir("upload")) {
	$old_umask = umask(0);
	mkdir ("upload", 0777);
	umask($old_umask);
}
if (!is_writable("upload")) {
	if (true !== (@chmod ("upload", 0777))) echo "<br>Bitte Ordner /upload CHMOD 777 Rechte setzen";
}

if(!is_dir("tn_upload")) {
	$old_umask = umask(0);
	mkdir ("tn_upload", 0777);
	umask($old_umask);
}
if (!is_writable("tn_upload")) {
	if (true !== (@chmod ("tn_upload", 0777))) echo "<br>Bitte Ordner /tn_upload CHMOD 777 Rechte setzen";
}


if(!is_dir("smileys")) {
	$old_umask = umask(0);
	mkdir ("smileys", 0777);
	umask($old_umask);
}
if (!is_writable("smileys")) {
	if (true !== (@chmod ("smileys", 0777))) echo "<br>Bitte Ordner /smileys CHMOD 777 Rechte setzen";
}

if(!is_dir("tn_upload")) {
	$old_umask = umask(0);
	mkdir ("tn_upload", 0777);
	umask($old_umask);
}
if (!is_writable("tn_upload")) {
	if (true !== (@chmod ("tn_upload", 0777))) echo "<br>Bitte Ordner /tn_upload CHMOD 777 Rechte setzen";
}

if(!is_dir("profile")) {
	$old_umask = umask(0);
	mkdir ("profile", 0777);
	umask($old_umask);
}
if (!is_writable("profile")) {
	if (true !== (@chmod ("profile", 0777))) echo "<br>Bitte Ordner /profile CHMOD 777 Rechte setzen";
}

if(!is_dir("topics")) {
	$old_umask = umask(0);
	mkdir ("topics", 0777);
	umask($old_umask);
}
if (!is_writable("topics")) {
	if (true !== (@chmod ("topics", 0777))) echo "<br>Bitte Ordner /topics CHMOD 777 Rechte setzen";
}

if (!is_writable("clear.txt")) {
	if (true !== (@chmod ("clear.txt", 0666))) echo "<br>Bitte Datei clear.txt CHMOD 666 Rechte setzen";
}
if (!is_writable("fp.txt")) {
	if (true !== (@chmod ("fp.txt", 0666))) echo "<br>Bitte Datei fp.txt CHMOD 666 Rechte setzen";
}

if (!file_exists("user/user.txt")) {
	$text = "Gast****fe01ce2a7fbac8fafaed7c982a04e229\n"; // Dateiinhalt
	$dateiname = "user/user.txt"; // Name der Datei
	$handler = fOpen($dateiname , "a+"); // Datei öffnen, wenn nicht vorhanden dann wird die Datei erstellt.
	fWrite($handler , $text); // Dateiinhalt in die Datei schreiben
	fClose($handler); // Datei schließen
}

if (!is_writable("user/user.txt")) {
	if (true !== (@chmod ("user/user.txt", 0666))) echo "<br>Bitte Datei user/user.txt CHMOD 666 Rechte setzen";
}
if (!is_writable("user/flood.txt")) {
	if (true !== (@chmod ("user/flood.txt", 0666))) echo "<br>Bitte Datei user/flood.txt CHMOD 666 Rechte setzen";
}

// alle htaccess umbenennen in .htaccess
if (file_exists("htaccess")) {
	@rename("htaccess",".htaccess");
}
if (file_exists("profile/htaccess")) {
	@rename("profile/htaccess","profile/.htaccess");
}
if (file_exists("rooms/htaccess")) {
	@rename("rooms/htaccess","rooms/.htaccess");
}
if (file_exists("user/htaccess")) {
	@rename("user/htaccess","user/.htaccess");
}

// Default-Passwortschutz für /support_online einrichten:
$dir = dirname(__FILE__);
$dir = str_replace('/share/spool0_local/www','',$dir); //hm?

if (!file_exists("support_online/htaccess") && !file_exists("support_online/.htaccess")) {
$text2 = "AuthName 'Online Support verfuegbar'\nAuthType Basic\nAuthUserFile '".$dir."/support_online/.htpasswd\nrequire valid-user'";

$dateiname = "support_online/htaccess"; // Name der Datei
$handler = fOpen($dateiname , "a+"); // Datei öffnen, wenn nicht vorhanden dann wird die Datei erstellt.
fWrite($handler , $text2); // Dateiinhalt in die Datei schreiben
fClose($handler); // Datei schließen
}

if (file_exists("support_online/htaccess")) {
	@rename("support_online/htaccess","support_online/.htaccess");
}
if (file_exists("support_online/htpasswd")) {
	@rename("support_online/htpasswd","support_online/.htpasswd");
}

// Default-Passwortschutz für /admin einrichten:
//$dir = dirname(__FILE__);
//$dir = str_replace('/share/spool0_local/www','',$dir); //hm?

if (!file_exists("admin/htaccess") && !file_exists("admin/.htaccess")) {
$text2 = "AuthName 'Admin'\nAuthType Basic\nAuthUserFile '".$dir."/admin/.htpasswd'\nrequire valid-user";

$dateiname = "admin/htaccess"; // Name der Datei
$handler = fOpen($dateiname , "a+"); // Datei öffnen, wenn nicht vorhanden dann wird die Datei erstellt.
fWrite($handler , $text2); // Dateiinhalt in die Datei schreiben
fClose($handler); // Datei schließen
}


if (file_exists("admin/htaccess")) {
	@rename("admin/htaccess","admin/.htaccess");
}
if (file_exists("admin/htpasswd")) {
	@rename("admin/htpasswd","admin/.htpasswd");
}



?>