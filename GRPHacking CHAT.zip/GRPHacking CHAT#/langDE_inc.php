<?php
@include("chat_config.php");

########### chat.php: ##############
define("_BLINDHELP",  "Hinweise f&uuml;r blinde Benutzer");
define("_HELP",       "Hilfe");
define("_HELPTITLE",  "Allgemeine Hilfe zum Chat");
define("_MESSAGE",    "Schreib&apos; etwas!");
define("_NICK",       "Nickname");
define("_SUBMIT",     "Senden");
define("_PR",         "Du bist jetzt im Privatraum ");
define("_ROOM",       "(Fl&uuml;ster-)Raum");
define("_YOUROOM",    "Du bist im Raum ");
define("_NOROOM",     "<em style=\"color:red\">Dieser Raum existiert nicht!</em><br />Bitte w&auml;hle einen der &ouml;ffentlichen R&auml;ume aus der Liste,<br />oder gehe mit der Zur&uuml;ck-Funktion deines Browsers in den Standard-Raum zur&uuml;ck." );
define("_NEWROOM",    "Existierenden Raum betreten oder privaten Raum anlegen ");
define("_COMEIN",     "hinein ");
define("_OPT",        "Optionen ");
define("_OPT_TITLE",   "Verschiedene Anzeigeoptionen w&auml;hlen");

define("_FONTSIZE",   "Schriftgr&ouml;&szlig;e");
define("_REVERSE",    "Eingabefeld&nbsp;oben&nbsp;");
define("_INPUT",      "Eingabefeld&nbsp;einzeilig&nbsp;");
define("_TEXTAREA",   "Eingabefeld&nbsp;mehrzeilig");
define("_DATEOFF",    "Datum im Chat verbergen&nbsp;");
define("_TIMEOFF",    "Zeit im Chat verbergen&nbsp;");
define("_SOUNDOFF",   "Hinweist&ouml;ne&nbsp;ausschalten&nbsp;");
define("_COLOROFF",   "Fettschrift&nbsp;");
define("_COLOR2OFF",   "Schriftfarben ausschalten&nbsp;");
define("_ONLINEOFF",  "Online-Zeit ausschalten&nbsp;");
define("_HOUROFF",    "Uhrzeitanzeige ausschalten&nbsp;");
define("_NICKCOLOR",  "Nickfarbe");
define("_NICKCOLORLABEL",          "Die Farbe f&uuml;r eigene Nachrichten w&auml;hlen");
define("_COL1",       "blau");
define("_COL2",       "rot");
define("_COL3",       "pink");
define("_COL9",       "grün");
define("_COL4",       "gold");
define("_COL5",       "gr&uuml;n");
define("_COL6",       "t&uuml;rkis");
define("_COL7",       "hellbraun");
define("_COL8",       "dunkelgrau");
define("_SKIN",       "Seitenstil");
define("_SKINS",      "Skin");
define("_SKINLABEL",  "Den Stil der Seite w&auml;hlen");
define("_ONTIME",     "Online-Zeit");
define("_REALTIME",   "Es ist jetzt");
define("_NOJS",       "Du musst Javascript erlauben, um den Chat zu nutzen");
define("_NOCOOKIE",   "Ohne Cookies l&auml;uft der Chat leider nicht. Bitte erlaube Cookies in Deinem Browser.");
define("_SMIL",       "<span lang=\"en\">Smileys</span> zum Einf&uuml;gen in die Nachricht");
define("_WHERE",      "Wo bin ich?");
define("_REGUSER",    "Du bist angemeldet als ");
define("_UPLOADLEGEND",    "Datei-Upload: ");
define("_UPLOADLABEL",    "Das Formular zur Dateisuche zum Hochladen von Bildern und mp3");
define("_YOUR_IP",    "Deine IP: ");
define("_NO_MP3",    "Verlinken von mp3 ist hier leider nicht erlaubt.");
define("_DOWNLOAD",    "Hol' dir den Chat");
define("_HIDE_PICS",    " Bilder &amp; Smileys verbergen");
define("_SMALL_PICS",    " Bilder &amp; Smileys kleiner");
define("_HIDE_UO",    " User-Liste verbergen");
define("_HIDE_AVATAR",    " Avatare verbergen");
define("_SHOW_POPUP",    " Popup aktivieren");
define("_STATION",    "Radiosender w&auml;hlen");
define("_AWAY1",    "Du bist jetzt (vor&uuml;bergehend) vom Chat abgemeldet, und f&uuml;r andere nicht mehr sichtbar,");
define("_AWAY2",    "solange diese Meldung stehen bleibt, und nicht mit OK oder Enter geschlossen wird.");
define("_SHOW_UP_PLAYER",    "Player [Uploads] ");
define("_SHOW_HTML5_PLAYER",    "Radio [noFlash] ");

define("_TIT_REVERSE", "Das Eingabefeld oberhalb des Nachrichtenfensters platzieren, und die Nachrichten in umgekehrter Reihenfolge ordnen: Neueste Nachricht oben");
define("_TIT_TEXTAREA", "Das Eingabefeld mehrzeilig darstellen. Das mehrzeilige Eingabefeld kann durch Ziehen mit der Maus an der rechten unteren Ecke in der Größe angepasst werden.");
define("_TIT_DATEOFF", "Die Anzeige des Datums im Nachrichtenfenster ausblenden.");
define("_TIT_TIMEOFF", "Die Anzeige der Uhrzeit im Nachrichtenfenster ausblenden.");
define("_TIT_HIDE_PICS", "Die Anzeige aller Bilder, auch Smileys und Avatare, verbergen.");
define("_TIT_SMALL_PICS", "Alle Bilder, Smileys und Videos kleiner anzeigen. (Rechtsklick auf Bild zeigt es in Originalgröße)");
define("_TIT_HIDE_UO", "User-Liste verbergen, wenn sie zu sehr nervt");
define("_TIT_HIDE_AVATAR", "Die Anzeige von Avataren verbergen");
define("_TIT_SOUNDOFF", "Alle Benachrichtigungssounds deaktiveren");
define("_TIT_SHOW_POPUP", "Zeigt den Eingang einer Meldung in einem Popup an. Nützlich z. B. in lauter Umgebung. (Muss entsprechend konfiguriert sein.)");
define("_TIT_COLOROFF", "Alle Schriften fett anzeigen");
define("_TIT_COLOR2OFF", "Alle Nachrichten ohne farbliche Unterschiede zeigen");
define("_TIT_HOUROFF", "Die Anzeige der aktuellen Uhrzeit (unterhalb des Skinwählers) auschalten");
define("_TIT_ONLINEOFF", "Die Anzeige der online verbrachten Zeit ausschalten");
define("_TIT_SHOW_UP_PLAYER", "Zeigt einen Player mit den zuletzt hochgeladenen MP3");
define("_TIT_SHOW_HTML5_PLAYER", "Zeigt einen Radioplayer");

########## chat_inc.php: ###########
define("_ALLROOMS",   "R&auml;ume");
define("_PUBLROOMS",  "&Ouml;ffentliche R&auml;ume");
define("_ACTROOM",    "aktueller Raum");
define("_YOURINROOM", "Du bist im Raum");
define("_ALONE",      "... und leider im Moment alleine hier&nbsp;<img src=\"img/sad.gif\" alt=\"\" height=\"12\" width=\"12\"> ");
//define("_ALONE",      "... und hier ist leider wieder mal nichts los.");
// define("_GUESTSLOGIN"," G&auml;ste beim Login");
// define("_GUESTLOGIN", " Gast beim Login");
define("_GUESTSLOGIN"," Leser in der Shoutbox (sb)");
define("_GUESTLOGIN", " Leser in der Shoutbox (sb)");
define("_BACKTOSTD",  "zur&uuml;ck in den Raum");
define("_INROOM",     "Derzeit im Raum");
define("_LNKNEWWIN",  "Link &ouml;ffnet in neuem Fenster");
define("_INVITEPR",   "Klick hier für einen Privatraum ▶︎");
define("_INVITEADVISE",   "Achtung! diese Einladung kann jeder lesen. Wenn du das nicht willst, dann w&auml;hle einen neuen Namen f&uuml;r den privaten Raum, und schick' die Einladung als private Nachricht (gefl&uuml;stert).");
define("_RENAME",     "nennt sich jetzt");

if (date('G') < 10) {
   $hourgreeting = 'Guten Morgen,';
} elseif (date('G') < 18) {
   $hourgreeting = 'Guten Tag,';
} else {
   $hourgreeting = 'Guten Abend,';
}
define("_NEWUSER", " hat den Chat betreten");


define("_DBLUSER",    " Ein User mit diesem Nick ist (oder war) bereits im Chat. Versuch' es eventuell in einigen Minuten nochmal.<br />Besser: <a href='reg.php'>Registrier' dich!</a>");
//define("_ADMINNICK",  "Dieser nick ist f&uuml;r den Admin reserviert!");
//define("_RESERVED",   "Sorry, dies ist ein reservierter nick!");
define("_WHISPER",    "fl&uuml;stert");
define("_TO",         " mit ");
define("_APPLY",      "gew&auml;hlte Option anwenden");
define("_CLEAR",      "hat hier mal aufger&auml;umt.");
define("_LOGIN",      " Hallo Gast,<br />bitte gib einen Nicknamen ein,<br />und schick' eine erste Nachricht als Begr&uuml;&szlig;ung,<br />um den Chatraum zu betreten.");
define("_HOURS",      " Uhr");
define("_WHISPERTO",  "Rechtsklick: Einladung in Privatraum. Linksklick: fl&uuml;stern mit ");
define("_NOCHEAT",    "  Bitte nicht gleichzeitig Nick &auml;ndern und fl&uuml;stern!");
define("_USERIMG",    "Grafik");
define("_FORMIMG",    "[img][/img] ist hier nicht n&ouml;tig, einfach den Link zum Bild eingeben.");
define("_FORMURL",    "Warum machst du dir so viel M&uuml;he mit einem Link, gib einfach die URL ein.");

if (isset($closepr) && $closepr != "yes") {
   define("_OFFLINE",    "Dieser Chatraum ist vor&uuml;bergehend geschlossen.<br />This chat room is temporarily closed.<br /><br /> ");
} else {
   define("_OFFLINE",    "Dieser Chatraum ist vor&uuml;bergehend geschlossen.<br />This chat room is temporarily closed.<br /><br /> ");
}
define("_INTERN",    "Dieser Chatraum ist nur für den internen Gebrauch.<br />Bitte wende dich ggf. an den Administrator.");

define("_CLOSED",    "Dieser Chatraum ist vor&uuml;bergehend geschlossen. &Ouml;ffnungszeit: ");

define("_NOMOD",    " Die Moderator Funktion ist nicht installiert.");
define("_NOLINK",    " Links sind hier nicht erlaubt! ");
define("_NOIMGLINK",    " Externe Bilder einbinden ist um diese Uhrzeit leider nicht erlaubt - Jugendschutz! ");
define("_NOTOPIC",    " Topic setzen ist in Fl&uuml;sterr&auml;umen nicht erlaubt! ");

define("_ROOM_NAME1",    "Achtung! Raumnamen d&uuml;rfen kein Leerzeichen enthalten! L&ouml;schen oder Umbenennen im Ordner /rooms.");
define("_ROOM_NAME2",    "Achtung! Raumnamen m&uuml;ssen mit einem Gro&szlig;buchstaben beginnen! L&ouml;schen oder Umbenennen im Ordner /rooms.");
define("_ROOM_NAME3",    "Ung&uuml;ltiges Zeichen in einem Raumnamen! L&ouml;schen oder Umbenennen im Ordner /rooms.");

define("_WAKEUP",    "Hey! Aufwachen! ");
define("_STOPMSG",    "hat jetzt vorübergehend die Aktualisierung deaktiviert.");


###### Chatbot: #########
define("_HELLO",      "Hallo ");
define("_KBBROKE",    ": was soll das? Immer wieder die gleichen Zeichen!<br /> Ist deine Tastatur kaputt?<br />&Uuml;brigens: Diese Meldung siehst nur du. Andere User kannst du damit nicht nerven.");
// define("_FLOOD",      ": Sch&ouml;n, dass du so schnell tippen kannst. Weil das aber vermutlich nur Spam ist, ist jetzt mal f&uuml;r ".$bantime."&nbsp;Minute(n) Schluss damit. ");

define("_FLOOD",      ": <br>Du bist jetzt f&uuml;r einen Moment gesperrt. Das passiert automatisch, wenn du in weniger als 1 Sekunde mehrere Meldungen schickst. Und es ist leider nötig, weil es böse Menschen gibt, die so etwas absichtlich machen, um dir den Spaß im Chat zu verderben. <br>Wenn es nur ein Versehen war: bitte einfach etwas Geduld. <br>Gleich geht es wieder weiter.  ");


define("_NICKIRC",    "Nein, dies ist kein IRC. Wenn du deinen nick &auml;ndern willst log' dich bitte aus und neu ein.");
define("_WHOIRC",     "Nein, dies ist kein IRC. Wenn du wissen willst, wer online ist: rechts oben steht das. Und wenn dort steht: \"... und ganz alleine hier\", oder so ähnlich, dann bist du eben alleine hier.");
define("_MSGIRC",     "Nein, dies ist kein IRC. Private Nachrichten erstellst du durch Anklicken des Users in der Liste rechts oben.");
define("_HELPIRC",    "schau mal hier: <a href=\"help.php\">Hilfe</a> - oder hier: <a href=\"http://webdesign.weisshart.de/chat-faq.php\">FAQ</a>");
// define("_README",     "ich denke, du solltest mal die <a href=\"http://webdesign.weisshart.de/chat/readme.txt\">readme.txt</a> lesen.");
define("_LICENCE",    "Hier gibt es die  <a href=\"http://webdesign.weisshart.de/chat-lizenz.php\">Lizenz</a>");

define("_PROFIL",    "Dein Profil");
define("_XPROFIL",    " Registrierte User k&ouml;nnen hier ihr <a href=\"profil.php\">Profil bearbeiten</a>");
define("_SHOW_PROFIL",    "Nur registrierte User d&uuml;rfen Profile anschauen.");

define("_LISTIRC",    "Die Sache mit den R&auml;umen funktioniert hier etwas anders als im IRC: <a href=\"help.php#roomhelp\">Hilfe zu R&auml;umen</a>");
define("_AGEQUEST",   " wie alt ");
define("_AGE",        "Hi, ich bin der Chatbot, und ich bin ");
define("_AGE2",       " Sekunden alt.");
define("_GENDERQUEST"," m oder w");
define("_GENDER",     "Hi, ich bin der Chatbot, und ich bin <a href=\"http://de.wikipedia.org/wiki/Hermaphrodit\">Hermaphrodit.</a>");
define("_SORRY",      "<span lang=\"en\">Sorry</span>");
define("_ADMINONLY",  ", dieser Befehl steht nur dem Admin zur Verf&uuml;gung");
define("_MUZZLED",    ", du hast jetzt mal Sendepause. Bitte nutze die Zeit, um &uuml;ber dein Verhalten nachzudenken. Noch ");
define("_ERASE",      "Wenn du fl&uuml;stern willst, dann klick einen Namen in der Liste der anwesenden User (rechts oben!).<br />Um einen User direkt anzusprechen, klick auf den Namen vor einer Nachricht, oder schreib' einfach @Nickname in deinen Text. Diese Nachricht wird dann beim Angesprochenen <span style=\"font-weight:bold; background:yellow\">so hervorgehoben</span>.");
define("_APPROVE",      ", so schaltet der Moderator Beitr&auml;ge frei. Aber eben NUR der Moderator.");
define("_YTERROR",      " Hinweis: Ein YouTube-Link darf keinen zus&auml;tzlichen Text enthalten! ");




########## chat_js.php: ###########
define("_NICKNOTALLOWED",   "Dieser Nick ist nicht erlaubt!");
define("_CHARNOTALLOWED",   "Nicht erlaubte Zeichen im Nick!");
define("_CHARNOTALLOWEDMSG",   "Nicht erlaubte Zeichen in der Nachricht!");
define("_ROOMNOTALLOWED",   "Nicht erlaubte Zeichen im Raumnamen!");


if (date('m') == '06' || date('m') == '07' || date('m') == '08' || date('m') == '09' ) {
	define("_TIMEOUT",    "..... Chat disconnected (timeout) \\n\\nHey, hier ist ein Chat, und keine \u00f6ffentliche K\u00fchlbox!");
} else {
	define("_TIMEOUT",    "..... Chat disconnected (timeout) \\n\\nHey, hier ist ein Chat, und keine \u00f6ffentliche W\u00e4rmestube!");
}

define("_NOCOOKIEALERT",   "Hinweis: \\nBitte Cookies erlauben!\\nDann erscheint dein Nick auch in der Liste der online user,\\nund diese Meldung verschwindet.");
define("_JSADMINONLY",  "Dieser Befehl steht nur dem Admin zur Verf\u00fcgung!");
define("_NOHTML",  "Kein HTML hier!");
define("_JSERASE",      "Wenn du fl\u00fcstern willst, dann klick einen Namen in der Liste der anwesenden User (rechts oben!).\\n\\nUm einen User direkt anzusprechen, schreib' einfach @Nickname in deinen Text,\\noder klick den Namen vor einer Nachricht.\\nDiese Nachricht wird dann beim Angesprochenen hervorgehoben.");
define("_JSIRC",      "HIer ist kein IRC!\\nBitte schau' in der Hilfe, welche Befehle hier verf\u00fcgbar sind.");
define("_DELROOM",      "Willst du den eingegebenen Raum wirklich l\u00f6schen und entfernen?\\n\\nHinweis: den Raum, in dem du dich befindest, kannst du nicht l\u00f6schen.");
define("_WHISPERNOTALLOWED",      "Fl\u00fcstern ist nur erlaubt, wenn ein Admin beteiligt ist.");
define("_WHISPERROOMSNOTALLOWED",      "Fl\u00fcsterr\u00e4ume darf nur der Admin \u00f6ffnen.");
define("_READONLY",      "Als Gast kannst du nicht schreiben.\\n\\nUm zu schreiben, log dich bitte aus,\\nund melde dich mit deinem registrierten Nicknamen an,\\noder registriere dich (das geht ganz schnell!).");
define("_CHARREP",      "Sieht so aus, als ob deine Tastatur klemmt?\\nBitte \u00fcberpr\u00fcfe deine Eingabe.");
define("_MULTURL",      "Nur ein Link/Dateiupload pro Eingabe erlaubt!");
define("_NOBLANK",      "Keine Leerzeichen in Dateinamen erlaubt!");
define("_UPPERCASE",      "Sieht so aus, als ob deine Tastatur kaputt ist.\\nHast du nur Gro\u00dfbuchstaben?\\nSo etwas gilt im Chat als unh\u00f6flich.");
define("_AWAY",    "Du bist jetzt (vorübergehend) \"away from keyboard\", also \"nicht an der Tastatur\". \\n Im Chatfenster wird für andere User eine entsprechende Meldung angezeigt. \\n Wenn du zurück bist, und wieder aktiv am Chat teilnehmen willst, dann drücke in dieser Anzeige auf \"OK”\, dann wird dein afk-Status beendet [wieder da].");



define("_AWAY_MSG",    "ist jetzt mal \bafk");
define("_RE_MSG",    "wd");

if (date('m') == '06' || date('m') == '07' || date('m') == '08' || date('m') == '09') {
	define("_WARM_MSG",    "hat sich in die K\u00fchlbox zur\u00fcckgezogen");
} else {
	define("_WARM_MSG",    "hat sich in die W\u00e4rmestube zur\u00fcckgezogen");
}
define("_STOP_MSG",  "Du hast Autoscroll deaktiviert, um ungestört alte Meldungen nachzulesen. Gib \/go ein, oder lade die Seite neu, um wieder automatisch zur neuesten Meldungen zu scrollen.");




########## upa.php ################
if (!isset($gifsize)) {$gifsize = 64;}

define("_UPDONE",     "Upload&nbsp;abgeschlossen.<br />Klick&nbsp;hier,&nbsp;um&nbsp;deine&nbsp;Datei&nbsp;einzuf&uuml;gen.");
define("_JPGERR",     "Fehlerhaftes&nbsp;jpg-Bild");
define("_TYPEERR",    "Ung&uuml;ltiges&nbsp;Dateiformat.&nbsp;Zul&auml;ssig&nbsp;sind&nbsp;nur&nbsp;jpg,&nbsp;png&nbsp;und&nbsp;gif&nbsp;sowie&nbsp;mp3&nbsp;Dateien.");
define("_SIZEERR",    "Datei&nbsp;zu&nbsp;gro&szlig;, max.&nbsp;$maxsize&nbsp;kB&nbsp;jpg/png/mp3&nbsp;bzw.&nbsp;$gifsize&nbsp;kB&nbsp;gif&nbsp;erlaubt.");
define("_SIZEERR1",    "Datei&nbsp;zu&nbsp;gro&szlig;, max.&nbsp;");
define("_SIZEERR2",    "&nbsp;kB&nbsp;jpg/png/mp3&nbsp;bzw.&nbsp;$gifsize&nbsp;kB&nbsp;gif&nbsp;erlaubt.");
define("_UPERR",      "Fehler&nbsp;beim&nbsp;Datei-Upload.");
define("_MP3ADMINONLY",      "Hochladen&nbsp;von&nbsp;mp3&nbsp;ist&nbsp;dir&nbsp;hier&nbsp;nicht&nbsp;erlaubt.");
define("_SWFADMINONLY",      "Hochladen&nbsp;von&nbsp;Flash&nbsp;ist&nbsp;nur&nbsp;Admins&nbsp;erlaubt.");

######### usr_smileys.php #########
define("_USR_SMILEY1",      "Einfach Smileys anklicken, dann erscheinen sie im Schreibfeld.<br>Dort den Button \"Senden\" oder die Enter-Taste drücken. ");
define("_USR_SMILEY2",      "");


######## login.php ###
define("_LOGIN_H1",     "Chat Login");

define("_LOGIN_FORM",     "Melde dich an");
define("_LOGIN_FORM1",     "Gew&uuml;nschte Anmeldedaten angeben");
define("_LOGIN_FORM2",     "Passwort falsch!");
define("_LOGIN_FORM3",     "Dieser Nickname ist nicht registriert!");
define("_LOGIN_FORM4",      "Login merken (Cookie)");


define("_LOGIN_FORM_FORUM1",     "Bitte Anmeldedaten eingeben!");
define("_LOGIN_FORM_FORUM2",     "Dieser Nick ist bereits registriert!");
define("_LOGIN_FORM_FORUM3",     "Dieser Nick ist nicht erlaubt!");
define("_LOGIN_FORM_FORUM4",     "Nicht erlaubte Zeichen im Nick!");

define("_LOGIN_GUEST",     "Gastzugang ohne Registrierung");
define("_LOGIN_GUEST2",     "Nickname:");
define("_LOGIN_GUEST3",     "Passwort:");
define("_LOGIN_GUEST4",     "Mit einem Gast-Zugang kannst du sofort chatten.");
define("_LOGIN_GUEST5",     "Achtung!<br />Mit einer Gast-Anmeldung kannst du nur lesen.<br />Bitte <a href='reg.php'>registriere dich</a>, wenn du auch schreiben willst.");

define("_TO_REG",     "Registriere dich, um deinen Nicknamen zu sch&uuml;tzen");
define("_TO_REG2",     " und Zugang zu Userprofilen zu erlangen");
define("_TO_REG3",     "zur Registrierung");

define("_WHOSON",     "wer ist gerade online? (Popup)");
define("_NO_REG",	"Nicht registriert? <br />Beliebigen Nicknamen eingeben,<br>und Passwortfeld leer lassen,<br /> oder: <br />Nickname: Gast – Passwort: demo");
define("_NO_REG_NO_GUEST",	"Nicht registriert? <br />Einfach Passwortfeld leer lassen");
define("_LOG_FORM",     "Gast-Login m&ouml;glich ");
define("_SEC",     "&nbsp;Sek.");

define("_NOBODY",     "Momentan ist leider niemand online.");
define("_ONEUSER",    "Momentan ist nur 1 User online.");
define("_MOREUSERS1",     "Momentan sind ");
define("_MOREUSERS2",     " User online.");

define("_SUPPORT",     " Support im Chat ist jetzt verfügbar.");
define("_NOSUPPORT",     " Derzeit ist leider kein Support im Chat verfügbar.");



######## reg.php #####
define("_REG_H1",     "Chat Registrierung");

define("_REG_FORM",     "Kein Nickname eingegeben!");
define("_REG_FORM1",     "Nickname zu kurz!");
define("_REG_FORM2",     "Kein Passwort eingegeben!");
define("_REG_FORM3",     "Passw&ouml;rter stimmen nicht &uuml;berein!");
define("_REG_FORM4",     "Bitte g&uuml;ltige E-Mail eingeben!");
define("_REG_FORM5",     "Das folgende Feld muss leer bleiben:");
define("_REG_FORM6",     "Passwort wiederholen:");
define("_REG_FORM7",     "E-Mail (wird nicht angezeigt):");
define("_REG_FORM8",     "E-Mail (freiwillig, wird nicht angezeigt):");
define("_REG_FORM9",     "Registrieren");
define("_REG_FORM10",     "Registrierung m&ouml;glich ");
define("_REG_FORM11",     "Nickname und Passwort d&uuml;rfen nicht identisch sein ");


define("_REG_HINWEIS",     "Erlaubt sind nur Buchstaben, Ziffern und der Unterstrich ( _ ) keine Leerzeichen!");
define("_REG_HINWEIS1",     "ACHTUNG! Das Passwort kann vom User nicht ge&auml;ndert werden. Nur der Admin kann es zur&uuml;cksetzen!");
define("_REG_HINWEIS2",     "registrierte User");
define("_REG_HINWEIS3",     "Testregistrierungen sind hier in der Demo ausdr&uuml;cklich erw&uuml;nscht.");

define("_TO_LOGIN",     "zur Login Seite");

####### logout.php ####

define("_LOGOUT",     "Danke f&uuml;r deinen Besuch im Chat. Du bist jetzt ausgelogged.");
define("_LOGOUT1",     "Du kannst dieses Fenster jetzt schlie&szlig;en.");
define("_LOGOUT2",     "Zur Chat-Infoseite");
define("_LOGOUT3",     " hat sich ausgeloggt ... und schon weg!");



?>