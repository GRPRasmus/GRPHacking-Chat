<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
	html {
		padding:1em 1em 4em 1em;
		font-family:Verdana, Arial, sans-serif;
		font-size: 90%;
		color: #fff;
/*		line-height: .6em;*/
		background: #28241c url(img/stage_bg.jpg)
	}
	p {margin:3px;}
	
	#footer {
		width:100%;
		position:fixed;
		bottom: 0;
		left: 0;
		height: 2em;
		text-align: center;
		background: rgb(23,23,23,0.6);
		padding-top:1em;		
	}
	#footer a {color:#fff;}

</style>	

<title>Tetris Highscore</title>

</head>
<body onkeydown="kp()">

<h1 style="line-height: 1.4em !important;">Tetris Highscore</h1>



<?php 
error_reporting(E_ALL);

$raw = file("tetris_hs.txt");

for ($m = 0; $m < count($raw); $m++) {
	if (strpos($raw[$m],"NaN") === false ) {
		$file[] = $raw[$m];	
	}		  
}
rsort($file);


for ($i = 0; $i < count($file); $i++) {
	$nicknames[] = trim(substr($file[$i],6));
} 

$unique = array_count_values($nicknames);
$zahl = array_values($unique);

$nicknames = array_keys(array_flip($nicknames));


$names = array();
for ($i = 0; $i < count($file); $i++) {
	
	$line = trim(substr($file[$i],6));
	
	if (in_array($line,$names) !== true) {
		$nicks[] = $file[$i];		
	}
		
	$names[] = $line;

}	

// for ($i = 0; $i < count($nicks); $i++) {
// 	echo "<p>$nicks[$i] ($zahl[$i])</p>";
// }

$min = 2000;
$weitere = 0;
for ($i = 0; $i < count($nicks); $i++) {
	if (intval(substr($nicks[$i],0,5)) >= $min) {
		echo "<p>$nicks[$i] ($zahl[$i])</p>";
		$weitere = count($nicks) - $i - 1;
	}
}
if ($weitere == 1) {
	echo "<br><p>… und ein Spieler mit weniger als&nbsp;".$min."&nbsp;Punkten.</p>";
}
if ($weitere > 1) {
	echo "<br><p>… und ".$weitere." Spieler mit weniger als&nbsp;".$min."&nbsp;Punkten.</p>";
}


?>

<p id="footer">
<a style="font-size: .9em;" href="javascript:self.close()">Fenster&nbsp;schlie&szlig;en</a>
 | 
<a style="font-size: .9em;" href="tetris.php">Neues&nbsp;Spiel</a>

</p>

<script>
	function kp(e){if (!e) e=window.event;if (e.keyCode==27 && !e.shiftKey){self.close();}}window.onkeypress=kp;
</script>	


</body>
</html>
