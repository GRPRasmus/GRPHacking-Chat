<?php
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}

switch ($lang) {
	default: include("langDE_inc.php");
	break;
	case "de": include("langDE_inc.php");
	break;
	case "en": include("langEN_inc.php");
	break;
	case "es": include("langES_inc.php");
	break;
	case "lu": include("langLU_inc.php");
	break;
}

include("chat_config.php");

if (!isset($self_close) || $self_close != "" || isMobile() ) {$self_close = "self.close();";}

if (isset($stil) && $stil <> 0) {
	$s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
	$s = $default_skin;
}

function isMobile() {
	return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}


?>

<!DOCTYPE html>
<?php
switch ($lang) {
	default: echo '<html lang="de">';
	break;
	case "de": echo '<html lang="de">';
	break;
	case "en": echo '<html lang="en">';
	break;
	case "es": echo '<html lang="es">';
	break;
}
?><head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />

<title>Smileys einf&uuml;gen</title>

<link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" />

<style type="text/css">
        html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li {
        	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
        	border:0;
        	margin:0;
        	padding:0;
        }
		body {width:100%;}
        p  {
           margin: .5em 1em;
        }
        ul {list-style-type:none;}
        li {display:inline-block;margin:1em;}
        img {
            border:0;
            margin: 6px 0 0 15px;
            max-height: 120px;
        }
        
		a {text-decoration:none;}
        a.mucke:before {content:url(data:image/gif;base64,R0lGODlhDQAKAIAAAAAAAP///yH5BAEAAAEALAAAAAANAAoAAAIajI+Ap9HNoHqgToedvVdb3G1cFjGkmUELWgAAOw==)}

		<?php
		if (isset($usr_smileys_table_x) && isset($usr_smileys_table_y) && is_numeric($usr_smileys_table_x) && is_numeric($usr_smileys_table_y) ) {
		echo '
		table td {width: '.$usr_smileys_table_x.'px; height: '.$usr_smileys_table_y.'px;max-width: 27.5vw;} 
		table img {max-height: '.$usr_smileys_table_y.'px;max-width: 100%;} }
		td a {display:block; height: '.$usr_smileys_table_y.'px; width: '.$usr_smileys_table_x.'px; }
		td a {text-decoration:none;display:block;height:100%;}
		';
		}
		?>
        
        table td {
    		overflow: hidden;
    		display: inline-block;
    		white-space: nowrap;
			border: 1px solid;
			text-align:center;
			margin:2px;
			padding: 5px;
			vertical-align: middle; /* cant work, weil img height unknown */
			
			white-space: pre-wrap; /* css-3 */    
    		white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
    		white-space: -pre-wrap; /* Opera 4-6 */    
    		white-space: -o-pre-wrap; /* Opera 7 */    
    		word-wrap: break-word; /* Internet Explorer 5.5+ */
		}
		table img {margin:0;}
				
		.button {
			font-size: .9rem;
			border: 1px solid;
			padding: 0 6px;
			border-radius: 1em;
			background: #fff;
			display: inline-block;
			margin: 5px 0 0 10px;
			position: sticky;
			top: 5px;
		}

		.mucke {
			font-size: 1.2em;
			margin: .5em 1em .5em 0;
			display: inline-block;
		}


       /* http://ryanfait.com/sticky-footer/ */
       html, body {
      	height: 100%;
       }
       .wrapper {
      	min-height: 98%;
      	height: auto !important;
      	height: 98%;
      	margin: 0 0 -6em 0; /* the bottom margin is the negative value of the footer's height */
		text-align:center;
       }
       .footer, .push {
      	height: 5em; /* .push must be the same height as .footer */
       }



</style>
<script>

        function newsmile(smiley) {
        	if (window.opener.document.getElementById('line').value.indexOf('<? echo _MESSAGE; ?>') !== -1) {
        		window.opener.document.getElementById('line').value = "";
        	}
        	
                window.opener.document.getElementById('line').value += " "+smiley+" ";
                window.opener.focus();
                window.opener.document.getElementById('line').focus();
        }
		
		function kp(e){if (!e) e=window.event;if (e.keyCode==27 && !e.shiftKey){self.close();}}window.onkeypress=kp;

		var cookieWert;
		function holeCookie(keksname) {
		      var alleCookies, i;
			alleCookies=document.cookie;
			cookieArr=alleCookies.split(";");
			for(var i=0;i<cookieArr.length;i++) {
				if(cookieArr[i].split("=")[0].replace(/\s+/,"") == keksname) {
					cookieWert=cookieArr[i].split("=");
					cookieWert=decodeURIComponent(cookieWert[1].replace(/\+/g," "));
					return true;
				}
			}
		  	return false;
		}



</script>


</head>
<body onkeydown="kp()" onload="focus()">


<div class="wrapper">


      <?php
            error_reporting(E_ALL);
            // das dir durchsuchen und die Bilder anzeigen:

            $verz = 'smileys';

			if (file_exists ("smileys")  && file_exists ("usr_smileys.php") && strpos($_SERVER['PHP_SELF'],"usr_smileys.php") === false) {
				echo '<a class="button" href="usr_smileys.php">Normale Smileys</a>&nbsp;';
			}
			if (file_exists ("smileys2") && file_exists ("usr_smileys2.php")  && strpos($_SERVER['PHP_SELF'],"usr_smileys2.php") === false) {
				echo '<a class="button" href="usr_smileys2.php">Jingles</a>&nbsp;';
			}
			if (file_exists ("smileys3") && file_exists ("usr_smileys3.php")  && strpos($_SERVER['PHP_SELF'],"usr_smileys3.php") === false) {
				echo '<a class="button" href="usr_smileys3.php">Große Smileys</a>&nbsp;';
			}
			if (file_exists ("smileys4") && file_exists ("usr_smileys4.php")  && strpos($_SERVER['PHP_SELF'],"usr_smileys4.php") === false) {
				echo '<a class="button" href="usr_smileys4.php">HTML5 Videos (Beta)</a>&nbsp;';
			}

            $bilder = array();

            $dir=opendir($verz);

            while (false !== ($file = readdir($dir))) {
				// auch mp3 und swf in more smiley
            	if(strpos($file,".gif") !== false || strpos($file,".png") !== false|| strpos($file,".mp3") !== false || strpos($file,".swf") !== false) { 
                    $bilder[] = $file;
            	}
            }

            sort($bilder);


			if ( isset( $_SERVER["HTTPS"] ) && strtolower( $_SERVER["HTTPS"] ) == "on" ) {
				$prot="https://";
			} else {
				$prot="http://";
			}

			if (isset($usr_smileys_table_x) && isset($usr_smileys_table_y) && is_numeric($usr_smileys_table_x) && is_numeric($usr_smileys_table_y) ) {
	            echo '<table><tr>';
	            foreach($bilder as $wert) {
	                $smiley = '<img src="'.$verz.'/'.$wert.'" alt="" />';
					$directory = "";
					if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
	                $link = $prot.$_SERVER['SERVER_NAME'].$directory.'/'.$verz.'/'.$wert;
	                $linktext = str_replace("Audio:","",$link);
					$linktext = str_replace(".mp3","",$linktext);
					$linktext = str_replace("_"," ",$linktext);

					// auch mp3 und swf
	            	if(strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
	                  echo '<td><a href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.$smiley.'</a></td>';
					} else {
	                  echo '<td> <a class="mucke" href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.basename($linktext).'</a></td>';
					}
	            }
				echo '</tr></table>';
            
            } else {
            
	            echo '<ul>';
	            foreach($bilder as $wert) {
	                $smiley = '<img src="'.$verz.'/'.$wert.'" alt="" />';
					$directory = "";
					if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
	                $link = $prot.$_SERVER['SERVER_NAME'].$directory.'/'.$verz.'/'.$wert;
	                $linktext = str_replace("Audio:","",$link);
					$linktext = str_replace(".mp3","",$linktext);
					$linktext = str_replace("_","&nbsp;",$linktext);

					// auch mp3 und swf
	            	if(strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
	                  echo '<li><a href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.$smiley.'</a></li>';
					} else {
		                echo '<li> <a class="mucke" href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.basename($linktext).'</a></li>';
					}
	            }
	            echo '</ul>';            
            
            }

            closedir($dir);
      ?>
      <div class="push"></div>

</div>

<div class="footer">

     <?php
          echo '<p>'._USR_SMILEY1.$verz._USR_SMILEY2.'</p>';
		if ($_SERVER['SERVER_NAME'] == "webdesign.weisshart.de") {
			// echo '<p>Gemafreie Demo-mp3: <a href="http://www.MP3-GEMA-frei.de">www.MP3-GEMA-frei.de</a></p>';
		}
     ?>
</div>

</body>
</html>