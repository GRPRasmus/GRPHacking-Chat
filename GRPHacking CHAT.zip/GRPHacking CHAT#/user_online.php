<?php
// Anzeige der user online

// cachen der AJAX Daten verhindern (IE):
// Bust cache in the head
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header('Content-type: text/html; charset=utf-8');

// always modified
header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
header ("Pragma: no-cache");                          // HTTP/1.0

include("chat_config.php");

// Sprache abfragen und lang-file includen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
      $lang = $languages[0];
}
$lang_file = 'lang'.strtoupper($lang).'_inc.php';
if (file_exists($lang_file)) {
	include ($lang_file);
}



$show_dir = 'user/';
$dir=opendir($show_dir);
$count = 0;
while (false !== ($file = readdir($dir))) {
	$on = "";

	if(strpos($file,"ip_") !== false && strpos($file,"_pr") === false && time() - filemtime($show_dir.$file) < 20) {

		$userfile = $show_dir.$file;
		$lines = file($userfile);
		foreach ($lines as $line_num => $line) {
			$user = explode("++++",$line);

			if (strlen($user[1]) > 1 && strpos($user[1],"ghost") === false && trim($user[1]) != '####') {
							
				$count = $count + 1;
			}
		}
	}
}


// max. gleichzeitig online:
$ath_on = "ath_on.txt";
$fp = fopen($ath_on,"r");
$high_on = fgets($fp,10);
fclose($fp); 
if ($count > $high_on) {
	$fp = fopen($ath_on,"w");
	fputs($fp,$count);
	fclose($fp);			
} 



if ($count > 1) {
	echo _MOREUSERS1.$count._MOREUSERS2;
} elseif ($count == 1) {
	echo _ONEUSER;
} else {
	echo _NOBODY;
}
?>