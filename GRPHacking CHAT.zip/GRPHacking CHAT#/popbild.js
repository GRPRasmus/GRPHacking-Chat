/* (c) http://webdesign.weisshart.de */

// Opera 8.0+
var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;

// Firefox 1.0+
var isFirefox = typeof InstallTrigger !== 'undefined';

// Safari 3.0+ "[object HTMLElementConstructor]" 
var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || (typeof safari !== 'undefined' && safari.pushNotification));

// Internet Explorer 6-11
var isIE = /*@cc_on!@*/false || !!document.documentMode;

// Edge 20+
var isEdge = !isIE && !!window.StyleMedia;

// Chrome 1+
//var isChrome = !!window.chrome && !!window.chrome.webstore;
var isChrome = !!window.chrome;


// Blink engine detection
var isBlink = (isChrome || isOpera) && !!window.CSS;



if (isBlink || isSafari ) {var add1 = 22;} else {var add1 = 0;}

newWindow="";
function OpenNewWindow(Picture,Breit,Hoch,Alttext) {
xsize = Breit;
ysize = Hoch + add1;

ScreenWidth = screen.width;
ScreenHeight = screen.height;

xpos = (ScreenWidth/2)-(xsize/2);
ypos = (ScreenHeight/2)-((ysize+60)/2);



if (!newWindow.closed && newWindow.location) {newWindow.close();}

//html = '<img src = ' +Picture+ '>';

html = ('<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de"  onclick="self.close()"><head><title> '+Alttext+'</title><style type="text/css">html, body, p, a {margin:0; padding:0; border: 0; font-family: Verdana,Geneva,Arial,sans-serif;} html {background: url('+Picture+') no-repeat center center fixed; /* -webkit-background-size: contain;-moz-background-size: contain;-o-background-size: cover;*/ background-size: cover; cursor:zoom-out;max-width: 100%;} </style><script type="text/javascript">function kp(e){if (!e) e=window.event;if (e.keyCode==27){self.close();}}window.onkeypress=kp;</script></head><body onkeydown="kp()"><p style="position:fixed; bottom: 8px;right:8px"><a style="color:#fff;text-decoration:none;text-shadow: -1px -1px 1px #fff, 1px 1px 1px #000; font-size:2em; opacity:.3" href="javascript:self.close()">X</a></p></body></html>');



newWindow=window.open("","Picture","height="+ysize+",width="+xsize+", resizable=yes,scrollbars=0,menubar=0,toolbar=0,status=0,titlebar=0");

newWindow.document.open("text/html", "replace")
newWindow.document.write(html)
newWindow.document.close()

return false;
}
