<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

/* CSS fuer Skin 4 Black */

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, fieldset, input {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #b6a56a;
}

body {
	padding: 10px 10px 0 10px;
	background:#000; 	/* hier die Hintergrundfarbe fuer die Seite */
	max-width: 70em;
	margin: auto;
}



h1 {
	font-size:1.4em;
	line-height:125%;
	margin-left:.5em;
}
h1 span {color:#06AEFF}

h2 {
	font-size:.8em;
	line-height:125%;
}

.rooms h2 {margin-top:1em;}

/*.bg {background:#2a2a2a}*/

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #help tr, #upload input  {
	font-size:.8em;
	margin-bottom: .1em;
}

fieldset fieldset a {text-decoration:none;}

a {color:#b6a56a}
a:focus, a:hover {background:transparent;}

#addsmileys a:hover {background:none}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
}

#user_pro_room em:after {
	content:" ✔︎";
}


#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}
#addsmileys ul li a:visited span {color:transparent}
#addsmileys ul li a:hover span{color: #b6a56a; }

#topic, #topic_wdw {
margin:0 0 5px 10px;
}

ul {
	font-size:.8em;
	list-style-type: none;
}


li {
	margin: 0 1em 0 0;
}

hr {
	display:none;
}


fieldset {
	clear: right;
	margin:0 0 3px 0;
	padding: 3px;
	min-width: 8em;
}



/* Op hack: */
html:first-child>b\ody fieldset fieldset {
	 margin-left: 79%;
}


#wrapper {
         margin:20px 0 0 0;
}

#wrapper:after, #opt:after { /* der Konq braucht das 1., der Op das 2. */
	content : ".";		
	display : block; 
	height : 0; 
	clear : both; 
	visibility : hidden;
}

/* Hides from IE-mac \*/
* html #opt {height: 1%;}
/* End hide from IE-mac */
/* End Op hacks */


.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #888 !important;
}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {
	max-height: 80%;
	margin: 0 3px 2em .8em;
}

#wall {
	height: <?php echo $hoehe?>em;
	background-color: rgba(0,0,0,0.01); /* Paranoia - damit man den Scrollbutton sieht */
	
	/* -webkit-mask-image: -webkit-gradient(linear, left top, left 5%, from(rgba(0,0,0,0)), to(rgba(0,0,0,1))); */
	overflow: auto;
	margin: 10px 10px 20px 0;
	padding: .3em .3em 1em .3em;
	line-height: 1.1em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
	/* border: 3px solid transparent; */ /* wg scrollbar */
}

/* Safari not Opera */
@media screen and (min-color-index:0) and(-webkit-min-device-pixel-ratio:0) { @media {
#wall::-webkit-scrollbar { background:transparent;width:6px}
#wall::-webkit-scrollbar-thumb {background:#444;width:5px;border-radius:3px}
}}


#wall p {
        /* die beiden folgenden Zeilen bestimmen die Einrueckung */
	padding:  0 .5em 0 3.8em;
	text-indent: -3.4em;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

.av { width: 30px !important;}

#wall .whisper, #wall .at {color:red; background: yellow}

#line {
	width: 80% !important;
	min-width:80% !important;
	max-width: 80% !important;
	font-size:1em;
}
input#line {position:relative; top: -6px;}




#ton {
	width: 0;
	height: 0;
}
#uo {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
        echo "display:block; min-height: 8em; max-height: ".($hoehe - (15 - $user_hoehe))."em; overflow-y:auto; overflow-x:hidden";
	} ?>
}
#uo ul {margin-top:1em}

#uo ul, #uo ul li {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	} ?>
	font-size:100%;
}
#uo ul, #user_pro_room ul, #opt form p {
	padding: .2em 0 .25em 0;
}


#user_pro_room ul li {
        padding:0;
        line-height:1.45em;
}
* html #user_pro_room ul li {
        line-height:1.45em;
}

#addsmileys {
/*	float:left; */
	margin: 5px 0 0 15px;
}
object {margin: 3px 0 0 3px;}


dfn, .dot {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}



#f {margin-left:10px;}

#opt input[type=submit] {margin-top:3px}


/* so wills der IE */
#talk input, .rooms input {
       color:#fff;
       background:#333;
       border:1px solid #888;
       cursor:pointer;
}


#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
      border: 0;
      background: transparent;
}

#line, #handle, #room {
       border: 1px solid #888;
       padding: 2px 0 2px 3px;
       color:#fff;
       background:#000;
       cursor:text;
}

label, select {
       cursor:pointer; font-size:1em;
}
label {margin:0 3px}

.button, .away {margin-left:10px; border: 1px solid #999; background:#333; color:#b6a56a; padding: 2px 4px;}

#menu1, #menu2, #room {width:65%; clear:both;}

#menu1, #menu2 {background: black;color: #ccc;	margin: 5px 4px 0 0;}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
}
?>

.uolist {display:none;}

/* #upload {margin:8px 0 0 6px; clear:left;} */

#upload {
	clear:left;
	margin: -.2em 5px 3px 7em;
	min-height:5em !important;
}

#wrapper fieldset legend {
	font-size: .8em;
	position: relative;
	top: 1.8em;
	left: -8.7em;
}



#logout, .logout {
        text-align:center;
        margin:4px 0;
        padding:3px 8px;
        border: 2px outset #b6a56a;
        background-color: #000;
		cursor:pointer;
		/* max-width:18em; */		
}
.logout a {text-decoration:none;}


.button {padding: 3px; margin-left:3px; bottom:7px !important}
.helplinks p, .helplinks p a {background: black; color:#b6a56a}
.helplinks p a:focus,
.helplinks p a:hover,
.helplinks p a:active
 {background: #00a; text-decoration:none}

#mp3 {margin-left: .6em;}


#upload legend {color:#b6a56a}

audio {
-webkit-filter: invert(1);
filter: invert(100%);
}

a.mp3 {
text-decoration: none;
padding-left: 20px;
background-image:url(img/audio_neg.gif) !important;
background-repeat:no-repeat !important;
background-position: 0 50% !important;
}
.hello {color: #888; font-size: 80%; font-style:italic; font-weight:bold;}

a.stop {
color:#fff;
border: 1px solid;
text-decoration:none;
font-size: 80%;
padding: 0 2px;
}

#ae {margin-bottom:.5em;}

#mp3 {display:block;}
#r_player, #player  {width: 92%;margin: 15px 0 !important}

#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

#nickname {color:red;}

.yta {color:#aaa;font-weight:bold; font-family:Arial narrow; font-size: 1.2em;}
.ytb {font-family:Arial narrow; background:#aaa;color:black !important;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}
iframe {background:#aaa; max-width:92%;} 

.tr {visibility:hidden}


#background_video {
    position: fixed;
    bottom: 0;
    left: 0;
	width:150%;
    min-width: 100%;
	height:105%;
    min-height: 100%;
    z-index: -100;
/*    background: url(img/pixabay_Fireplace1971.mp4) no-repeat; */
    object-fit: cover;
}


#webradio {text-align:center;}
#audio-controls {margin-top: .5em;}
#vol-control{filter: invert(.7);}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;}
input[type="image"]:hover, input[type="image"]:focus { background: #555}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
#popout_icon {filter:invert(1);}
#wdw_logo {filter:invert(1)}

