<?php


$counter='visitors_'.date('Y-m-d').'.txt';

if (file_exists($counter)) {
	$fp = fopen($counter,"r"); 
	$heute = fgets($fp,10); 
	fclose($fp); 
	echo $heute;
}



?>