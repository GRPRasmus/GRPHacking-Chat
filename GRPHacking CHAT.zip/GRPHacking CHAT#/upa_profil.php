<?php
error_reporting(E_ALL);
include("chat_config.php");

$prof_name = "default";
if (isset($_POST["prof_name"])) {
	$prof_name = $_POST["prof_name"];
	//echo $prof_name;
}



// Abfrage, ob Admin:
$nickname = "Nickname";
$admintrue = false;
if (isset($_COOKIE["nick"])) {
	$nickname = $_COOKIE["nick"];
}
if (in_array($nickname, $admins)) $admintrue = true;


$maxsize_a = $maxsize * 1024;
$upload_max_size = (ini_get('upload_max_filesize')) * 1024;
$maxsize_b = min($maxsize_a,$upload_max_size);

$maxsize_b = 100000;
$maxsize_kb = $maxsize_b / 1000;

if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}

switch ($lang) {
	default: include("langDE_inc.php");
	break;
	case "de": include("langDE_inc.php");
	break;
	case "en": include("langEN_inc.php");
	break;
}

//http://p2p.wrox.com/topicindex/14728.htm:
if (!isset($_SERVER['REQUEST_URI'])) {
	$_SERVER['REQUEST_URI'] = $_SERVER["SCRIPT_NAME"];
}


$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
// scheint nicht zu gehen
$pfad_zum_updir = str_replace(basename($_SERVER['PHP_SELF']),"",$url).'profile/';



if (!isset($nickname)) $nickname = "Nickname";
if (isset($_COOKIE["nick"])) {
	$nickname = $_COOKIE["nick"];
}
if ($nickname == "")	$nickname = "Nickname";

// $mp3up = false;
//
// if ($admintrue !== false) {
// 	$mp3up = true;
// }
// if (isset($mp3all) && $mp3all == "alle") $mp3up = true;



// http://getid3.sourceforge.net/
// include getID3() library (can be in a different directory if full path is specified)
require_once('getid3/getid3.php');

// Initialize getID3 engine
$getID3 = new getID3;

// Analyze file and store returned data in $ThisFileInfo
$ThisFileInfo = $getID3->analyze($_FILES["file"]["tmp_name"]);

@$filetype = $ThisFileInfo['fileformat'];

// print_r ($ThisFileInfo);
// exit;

// echo $ThisFileInfo['filesize'];

if ($ThisFileInfo['filesize']>$maxsize_b) {
	echo '<p>Datei zu groß, max. '.$maxsize_kb.'kB erlaubt. </p>';
	exit;
}


if (($filetype == "gif")|| ($filetype == "jpg")) {
	$show_x = $show_y = 480;
	
	if ($_FILES["file"]["error"] > 0) {
		echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
	} else {

		$upfilename = $prof_name.'.'.$filetype;  // fuer Profilbild


		/* jetzt jpg files zum Speichern verkleinern */
		if ($filetype == "jpg") {

			$jpegqual   = 70;                          // jpg-Qualitaet

			$sourcefile = $_FILES["file"]["tmp_name"];
			$popfile = "profile/".$upfilename;

			/* Get the dimensions of the source picture */
			$picsize=getimagesize("$sourcefile");
			$source_x = $picsize[0];
			$source_y = $picsize[1];

			@$source_id = imageCreateFromJPEG("$sourcefile");
			if (!$source_id) $jpeg_error = "err";            // jpeg Fehler abfangen

			/* pop berechnen, keep ratio */
			if ($source_x > $show_x) {
				$show_y = $source_y / $source_x * $show_x;
			} else {
				$show_x = $source_x;
				$show_y = $source_y;
			}
			// und jetzt noch auf max. Höhe checken:
			if ($show_y > $max_y) {
				$show_x = $source_x / $source_y * $max_y;
				$show_y = $max_y;
			}

			
			/* Create a new image object (not neccessarily true colour) */
			$pop_id=imagecreatetruecolor($show_x, $show_y);


			/* Resize the original picture and copy it into the just created image object.*/

			@$pop_pic=imagecopyresampled($pop_id,$source_id,0,0,0,0,$show_x,$show_y,$source_x,$source_y);

			/* Create a jpeg with the quality of "$jpegqual" out of the image object "$pop_pic".
			This will be saved as $popfile */
			imagejpeg ($pop_id,"$popfile",$jpegqual);



			// wenn jpg: gif loeschen:
			$giffilename = $prof_name.'.gif';
			if(file_exists('profile/'.$giffilename)) {
				unlink('profile/'.$giffilename);
			}


		} elseif ($filetype == "gif") {   // mit phpThumb wird verkleinert und animated gif nur still gezeigt


			$sourcefile = $_FILES["file"]["tmp_name"];
			$popfile = "profile/".$upfilename;

			/* Get the dimensions of the source picture */
			$picsize=getimagesize("$sourcefile");
			$source_x = $picsize[0];
			$source_y = $picsize[1];

			@$source_id = imagecreatefromgif("$sourcefile");
			// if (!$source_id) $jpeg_error = "err";            // jpeg Fehler abfangen

			/* pop berechnen, keep ratio */
			if ($source_x > $show_x) {
				$show_y = $source_y / $source_x * $show_x;
			} else {
				$show_x = $source_x;
				$show_y = $source_y;
			}
			// und jetzt noch auf max. Höhe checken:
			if ($show_y > $max_y) {
				$show_x = $source_x / $source_y * $max_y;
				$show_y = $max_y;
			}

			if ($source_x > $show_x) {
			
				$pop_id=imagecreatetruecolor($show_x, $show_y);
				// setTransparency($pop_id,$source_id);

				/* Resize the original picture and copy it into the just created image object.*/
			
				$pop_pic=imagecopyresampled($pop_id,$source_id,0,0,0,0,$show_x,$show_y,$source_x,$source_y);
				imageGIF ($pop_id,"$popfile");
			
			} else { // GIFs < $show_x nicht bearbeiten, wg. animated gif
				move_uploaded_file($_FILES["file"]["tmp_name"],"profile/" . $upfilename);
				chmod ("profile/".$upfilename, 0644);           // manche Server setzen sonst 600
			}	

			// wenn gif: jpg loeschen:
			$jpgfilename = $prof_name.'.jpg';
			if(file_exists('profile/'.$jpgfilename)) {
				unlink('profile/'.$jpgfilename);
			}

		}

		if (isset($jpeg_error)) {
			echo '<p>'._JPGERR.' (err 1)</p>';
		} else {
			echo '<p style="color: green; font-weight:bold;line-height:1em ">Upload abgeschlossen.</p> <p style="color: red; font-weight:bold;">Achtung!<br>Zuerst Profilbild speichern, und dann ➠ Profil speichern (unten).</p>';
			// echo '<input class="logout right"  style="font-weight:bold;" type="button" value="Profilbild speichern" onclick="location.reload(true)">';

			echo '<input class="logout right"  style="font-weight:bold;" type="button" value="Profilbild speichern" onclick="javascript:location.href=\'profil.php?action=save\'">';
		}

	}

} else {


	if ($filetype != "gif" && $filetype != "jpg" ) {
		echo '<p>Ung&uuml;ltiger Dateityp. Zul&auml;ssig sind nur .jpg oder .gif.(1)</p>';
	} elseif ($_FILES["file"]["size"] > $maxsize_b
		|| $_FILES["file"]["size"] == 0
	) {
		echo '<p>'._SIZEERR1.$maxsize_b._SIZEERR2.' (2)</p>';

	} else {
		echo '<p>'._UPERR.' (3)</p>';
	}
}
// bei zu großen files gibt PHP anscheinend kein filesize zurück
?>