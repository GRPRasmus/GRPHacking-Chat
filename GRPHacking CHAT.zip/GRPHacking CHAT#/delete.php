<?php

$to_delete = $_GET['file'];

/* Einladungs-File in /profile löschen */

if (file_exists('profile/'.$to_delete)) {unlink('profile/'.$to_delete);}


/* _pr-File in /rooms löschen */

$tmp2 = $to_delete;
$tmp2 = explode("___",$tmp2);
$tmp21 = explode("__",$tmp2[0]);

$sender = $tmp21[1];
$receiver = $tmp21[0];
$zufall = str_replace('_inv.txt','',$tmp2[1]);


if (file_exists('rooms/P'.$zufall.'_pr')) {unlink('rooms/P'.$zufall.'_pr');}


/* zum Flirtraum weiterleiten */

$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra1 = '?room=Flirtchat';

header("Location: //$host$uri/$extra1");
exit();

?>