<?php
header('Content-type: text/html; charset=utf-8');

session_start();


if (phpversion() < '4.3.0') {
	echo "<p>Dieses Script erfordert PHP Version 4.3.0 oder h&ouml;her!<br />";
	echo "auf Deinem Server l&auml;uft aber PHP Version ".phpversion().".</p>";
	exit();
}

include("chat_config.php");

// if (isset ($show_sb) && $show_sb === true) {
// 	$shoutbox = true; // schreibt das (sb) in die Nachricht
// }

// Sprache abfragen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}


switch ($lang) {
        default: include("langDE_inc.php");
        break;
        case "de": include("langDE_inc.php");
        break;
        case "en": include("langEN_inc.php");
        break;
}


require("Sajax.php");
include("chat_inc.php");
include_once("cleanup.php");


$wo = trim(substr($room,6));

if (isset($_COOKIE["color"])) {
	$color = $_COOKIE["color"];
} else {
	$color = "";
}

if (isset($_COOKIE["Style"])) {
	$style = $_COOKIE["Style"];
} else {
	$style = "";
}




// Letzer Login von registrierten Usern in die user.txt schreiben:
if ( $in_regdb === true) { // Admin nicht
      $angemeldet = "user/user.txt";
      $lines = file($angemeldet);
      $reg_user = array();

      foreach ($lines as $line_num => $line) {
       if(strpos($line,"****") !== false) {
          $reguser = explode("****",$line);
          $regged = trim($reguser[1]);

          if (trim($reguser[0]) != "") {
                if (trim($reguser[0]) == $nickname) {
                if (strpos($reguser[2],"@") === false) { $reguser[2] = "mail_not_set";}
                   $last_visit= $reguser[0].'****'.$regged.'****'.$reguser[2].'****'.date("d.m.Y H:i:s")."\n";
                   $reg_user[] .= $last_visit;
                } else {
                   // die User Datenbank neu schreiben: nicht geänderte Zeilen:
                   $reg_user[] .= $line;
                }
          }
        }
     }

     // jetzt user.txt neu schreiben:
     $open5 = fopen($angemeldet, "w");
     flock($open5,LOCK_EX);
     foreach($reg_user as $values) fputs($open5, $values);
     flock($open5,LOCK_UN);
     fclose($open5);
}




?>
<!DOCTYPE html>
<?php
switch ($lang) {
        default: echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">';
        break;
        case "de": echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">';
        break;
        case "en": echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';
        break;
}
?>


<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" /> 
<title>Chat Privatraum</title>
<link rel="shortcut icon" href="/favicon.ico" />

<base target="_blank" /> 


<?php
$s = 1;
$hilfetexte = "off";
?>

<link rel="stylesheet" type="text/css" media="screen" href="chatcss0.php?<?php echo time(); ?>" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />

<?php
if ($style == 4 || $style == 5 || $style == 9 || $style == 11 ) {
	echo '<style>
		html,#wall,#line,#upload,a,a:focus,a:hover,input, span {background:#222;color:#fff !important}
	</style>';
}
	
	
?>
   
<script type="text/javascript" src="chat_js.php"></script>

<script type="text/javascript" src="popbild.js"></script>

</head>
<body>
<!-- ########## oberhalb dieser Zeile nur aendern, wenn Du weisst, was Du tust! ######## -->
<!-- ######## hier kannst Du eigene Inhalte einfuegen, z.B. eine Kopfzeile, Navigation o.ae. ###### -->


<!-- ######## die naechsten Abschnitte nicht aendern! ######## -->
<!-- <h1><?php echo $titel ?></h1> -->

<?php

$NCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQNCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQ="ZWNobyAnPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiPic7DWVjaG8gJy8qIDwhW0NEQVRBWyAqLyc7DXNhamF4X3Nob3dfamF2YXNjcmlwdCgpOw1lY2hvICcvKiBdXT4gKi8nOw1lY2hvICc8L3NjcmlwdD4nOw1pZiAoaXNzZXQoJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10pICYmIGlzc2V0KCRwd2QpKSB7DQkkc2VydmVyID0gc3RyX3JlcGxhY2UgKCJ3d3cuIiwiIiwgJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10gKTsNCSRzZXJ2ZXIgPSBzdHJfcmVwbGFjZSAoIisiLCIiLCAkc2VydmVyKTsNCSRzZXJ2ZXIgPSBzdHJfcmVwbGFjZSAoIi0iLCIiLCAkc2VydmVyKTsNCSRjaGF2ZSA9ICRwd2QgLyBhYnMoY3JjMzIoJHNlcnZlcikpOw19DWlmIChpc3NldCgkdmVyc2lvbikpIHsNCSR2ZXJzID0gIjxzcGFuIHN0eWxlPVwiZGlzcGxheTpub25lXCI+PGFiYnIgdGl0bGU9XCJWZXJzaW9uXCI+dmVycy48L2FiYnI+ICR2ZXJzaW9uPC9zcGFuPiI7DX0gZWxzZSB7DQkkdmVycyA9IiI7DX0NDWlmICghaXNzZXQoJGNoYXZlKSB8fCAkY2hhdmUgPD4gIjEyNCIpIHsNCWVjaG8gJzxwIHN0eWxlPSJmb250LXNpemU6MTFweDsgY29sb3I6ICMzNDM7IGJhY2tncm91bmQ6ICNmZmY7IG1pbi13aWR0aDogMTYwcHggIj4gc2NyaXB0IGJ5IDxhIHN0eWxlPSJmb250LXNpemU6MTFweDsgY29sb3I6ICMzNDM7IGJhY2tncm91bmQ6ICNmZmY7IHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lOyIgaHJlZj0iaHR0cDovL3dlYmRlc2lnbi53ZWlzc2hhcnQuZGUvY2hhdC5waHAiPndlYmRlc2lnbiB3ZWlzc2hhcnQ8L2E+IGtvc3RlbmxvcyBmJnV1bWw7ciBuaWNodCBrb21tZXJ6aWVsbGUgU2VpdGVuLicuJHZlcnMuJzwvcD4nOw19IGVsc2Ugew0JZWNobyAnPHAgc3R5bGU9ImZvbnQtc2l6ZToxMXB4Ij4nLiR2ZXJzLic8L3A+JzsNfQ0=";eval(base64_decode($NCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQNCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQ));?>


<fieldset id="wrapper">


<div id ="talk">
<div id="wall"></div>


<?php
if(isset($nickname)) {

	echo '
	<form  accept-charset="utf-8" id="f" method="post" action="#" onsubmit="add(); return false;" >

	<p>
	<label class="dot" for="line">'._MESSAGE.':</label>

	<input type="text" name="line" id="line"  size="67" maxlength='.$max_length.'
	title="'._MESSAGE.'" placeholder="'._MESSAGE.'" autofocus/>



	<button class="button" type="submit" title="Senden" onclick="closepopup()" >
			▷
	</button>


	</form>
	';

    echo '<input type="hidden" name="handle" id="handle" value="'.$nickname.'" />';

} else {
 // Paranoia - damit popbild.js tut ein input
echo '
<span style = "color:red">Nur im <a href="login.php">Hauptchat</a> angemeldete User d&uuml;rfen hier schreiben!</span>
<input type="hidden" id="line" />
';
}

?>



<?php
// if(!isset($nickname)) {
// echo '<!--';
// }
?>

<div id ="addsmileys">
<p><label class="dot" for="addsmileys"><?php echo _SMIL; ?>:</label></p>
<ul>
	<li><a href="#" onclick="ads(':-)'); return false; "><img src="img/smile.gif" title=":)" alt="lacht" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads(';-)'); return false; "><img src="img/smile_zwinker.gif" title=";-)" alt="zwinkert" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads(':-('); return false; "><img src="img/sad.gif" title=":-(" alt="traurig" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads(':evil'); return false; "><img src="img/evil.gif" title=":evil" alt="b&ouml;se" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads(':?'); return false; "><img src="img/confused.gif" title=":?" alt="verdutzt" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads(':p'); return false; "><img src="img/zunge.gif" title=":p" alt="verschmitzt" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads('8-)'); return false; "><img lang="en" src="img/cool.gif" title="8)" alt="cool" width="15" height="15" /></a></li>
	<li><a href="#" onclick="ads(':=)'); return false;"><img src="img/mrgreen.gif" title=":=)" alt="bleckt die Z&auml;hne" width="15" height="15" /></a></li>
</ul>

</div>
<?php
// if(!isset($nickname)) {
// echo '-->';
// }
?>



</div>


</fieldset>


<script src="micoxUpload2.js" defer></script>

<script>

  function end_upload2(data){
			document.getElementById('upload_2').innerHTML =  data;
  }
  function clear_upload2(){
			document.getElementById('upload_2').innerHTML =  '';
  }
    
</script>


<?php
$img = true;

if (strpos($wo,"_pr") !== false && $imginclude_pr != "yes") $img = false;

if ($mp3allow == "alle" || ($mp3allow=="clean" && (strpos($wo,"_pr") !== false || $blankrooms == "yes" || in_array($wo,$blankroom) || $admintrue !== false)) || ($mp3allow=="admins" && $admintrue !== false)) {
	$mp3upallow=1;
} else {
	$mp3upallow=0;
}; // fuer die Uebergabe an micoxUpload2 ist diese Umwandlung erforderlich


if (@$vidallow == "alle" || (@$vidallow=="clean" && (strpos($wo,"_pr") !== false || $blankrooms == "yes" || in_array($wo,$blankroom) || $admintrue !== false)) || ($vidallow=="admins" && $admintrue !== false)) {
	$vidallow=1;
} else {
	$vidallow=0;
}; // fuer die Uebergabe an micoxUpload2 ist diese Umwandlung erforderlich


// if (phpversion() > '5.6.39' && $gd === true) {
// if (($img == true && isset($imginclude) && $imginclude=="yes" && $wo != "Info" && $wo != "Buglist"   && !file_exists("rooms/Offline")) || $admintrue !== false) {
echo '
<fieldset style="float:left;" id="upload">
<legend style="font-size: .8em;">&nbsp;'._UPLOADLEGEND.'&nbsp;</legend>
  <form action="upa.php?rm='.$wo.'" >
    <div>
       <label class="dot" for="file">'._UPLOADLABEL.':&nbsp;</label> 
       <input type="file" style="color:transparent;" id="file" name="file" onchange="micoxUpload2(this.form,0,\'Loading \',end_upload2,'.$maxsize.','.$mp3upallow.','.$vidallow.')"/>    </div>
    <div id="upload_2"></div>
  </form>
';


echo '</fieldset>';
// }
// }

?>

<script>
	var timeOutFunctionId;
	function workAfterResizeIsDone() {
		var pw = window.innerWidth;
		var ph = window.innerHeight;
		var pl = window.screenLeft;
		var pt = window.screenTop;
		
		localStorage.setItem("prbox_width", pw);		
		localStorage.setItem("prbox_height", ph);		
		localStorage.setItem("prbox_left", pl);		
		localStorage.setItem("prbox_top", pt);							
					
	}
	window.addEventListener("resize", function() {
		clearTimeout(timeOutFunctionId);			
		timeOutFunctionId = setTimeout(workAfterResizeIsDone, 500);
	});
	
</script>	

<noscript>
	<p><?php echo _NOJS; ?>.</p>
</noscript>
<!-- 
<p style="margin-left:.2em;">... <a href="/chat/" target="_top"> zum <span lang="en">Chat</span> <span class="dot">auf einer eigenen Seite</span></a></p>
-->


</body>
</html>
